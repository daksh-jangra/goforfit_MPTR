Modified Pull-Up (test id: pull_up)
===================================
Files from the GoForFit NEP FMS app, taken from main at the commit below.
Keep the folder layout: each file goes to the same path in the app folder.

CHANGED BY THIS WORK
--------------------
  tests/pullup.py          the counter, the rep rules and the on-screen HUD
  tests/web_engines.py     PullUpEngine only (the browser-camera engine)
  templates/screen4.html   the pull_up live panel: status lines and website sync

CARRIES THE TEST BUT NOT CHANGED BY THIS WORK
---------------------------------------------
  app.py                   registry entry, the four /api/pull_up routes, staging
  db.py                    the pull_up table and save_pull_up
  templates/screen3.html   the review and save screen
  templates/results.html   the results dashboard listing

Both groups are included so the test runs from this folder alone. If the server
is already up to date, only the first three are needed.

WARNING: tests/web_engines.py, app.py, db.py and the templates are SHARED by
every test in the app. Copying them over replaces other tests' code with the
state it was in at this commit. If the server has newer work from another test,
apply modified_pull_up.patch instead of copying those files.

WHAT CHANGED
------------
1. A rep now needs two things to agree, not one. The chin is not a landmark;
   it is estimated below the mouth, so on its own a tilted head could buy a
   short rep. The shoulders must now also rise past the elbows.
2. Losing the face no longer wrecks the test. The arm keeps being tracked, so
   a blackout costs at most the rep it lands on. No rep is credited while the
   chin cannot be seen.
3. No more phantom rep after letting go of the bar. The grip is re-checked
   every frame, and a rep can only start with the body lying under the bar.
4. The two-second pause rule tolerates a noisier camera, so the test still
   ends itself instead of needing STOP.
5. The start overlay no longer says ready when the face is out of shot.
6. STOP / SAVE no longer sends the website a 0 for a test nobody started.
   A started trial with no reps still sends its real 0.

KNOWN LIMITS
------------
  - Camera roll outside about -10 to +50 degrees loses reps.
  - Overhead or oblique camera placement is untested.
  - A rep done with the face hidden the whole time scores 0.
  - The 0.40 body-lift threshold is set by judgement, not measured from a
    short rep.
  - The wrists stand in for the bar, so a slipped grip moves the target.

COMMITS (newest first)
----------------------
  93793c0  Modified Pull-Up: plain hyphens in the live status lines
  23b31ce  Modified Pull-Up: don't send the website a 0 nobody scored
  61dd1c0  Let a noisier camera end the pull-up, and stop promising a ready test
  ac4f9b1  Stop crediting a modified pull-up to someone off the bar
  0ef4c39  Keep counting modified pull-ups when the face isn't readable
  3acc51c  Make the body confirm what the chin claims, in modified pull-ups

Taken from main at d2c6a9c on 2026-11-13
