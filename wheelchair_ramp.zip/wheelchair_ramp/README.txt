Wheelchair Ramp Test - package contents

Exercise implementation:
  tests/wheelchair_ramp.py
Automated camera-free test:
  tests/test_wheelchair_ramp.py
  Run from the project root: python3 tests/test_wheelchair_ramp.py
Shared integration files: app.py, db.py, tests/web_engines.py,
templates/screen3.html, templates/screen4.html, templates/results.html.

The automated test uses synthetic frames and requires opencv-python and numpy.
The patch contains the Wheelchair Ramp feature and its follow-up fix.
