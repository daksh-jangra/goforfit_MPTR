Bench Press - changed files

Only used by this test:
  tests/bench_press.py       side-on press counter and protocol logic
  tests/test_bench_press.py  camera-free checks
                             run: python3 tests/test_bench_press.py

Shared files (full CURRENT copies):
  tests/web_engines.py       BenchPressEngine
  app.py                     test entry, routes, launch, save
  db.py                      bench_press table and save
  templates/screen3.html     result and sex selection handling
  templates/screen4.html     live screen, boy/girl picker, RESET controls
  templates/results.html     results listing

Patch
  bench_press.patch          relevant Bench Press commit diff

Protocol
  Side-on Bench Press counter: straight arms, chest touch, and hand height
  must be reached to count a rep. Maximum is 50 for boys or 30 for girls.
  The test ends after 15 seconds without a first rep or 4 seconds of rest.

The current screen4 also includes the updated BMI/wingspan behavior:
  no popup for no measurement; return to the review screen instead.
