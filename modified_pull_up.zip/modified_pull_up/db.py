"""
GoForFit NEP FMS — Database Layer
===================================
SQLite-backed storage with one table per fitness test.
All tables share a common `sessions` parent via session_id (FK).

Usage (standalone):
    python db.py          # creates goforfit.db and prints schema info

Usage (from app.py):
    from db import db
    sid = db.new_session(student_name="Riya", age=14, gender="F", school="DPS")
    db.save_bmi(sid, height_cm=163.2, weight_kg=52.0)
    db.save_wingspan(sid, wingspan_cm=162.5)
    rows = db.get_all("bmi")
"""

import sqlite3
import datetime
import json
from pathlib import Path
from contextlib import contextmanager

DB_PATH = Path(__file__).parent / "goforfit.db"


# ─────────────────────────────────────────────────────────────────────────────
# Connection helper
# ─────────────────────────────────────────────────────────────────────────────

@contextmanager
def _conn():
    con = sqlite3.connect(DB_PATH)
    con.row_factory = sqlite3.Row          # dict-like rows
    con.execute("PRAGMA foreign_keys = ON")
    try:
        yield con
        con.commit()
    except Exception:
        con.rollback()
        raise
    finally:
        con.close()


# ─────────────────────────────────────────────────────────────────────────────
# Schema
# ─────────────────────────────────────────────────────────────────────────────

_SCHEMA = """
-- ── Shared session / student info ─────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sessions (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    student_name TEXT,
    age          INTEGER,
    gender       TEXT CHECK(gender IN ('M','F','Other',NULL)),
    school       TEXT,
    grade        TEXT,
    notes        TEXT,
    created_at   TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Student roster (the list screen3 picks from) ──────────────────────────
-- A class roster belongs to the school, so it is deliberately NOT scoped per
-- coach: two coaches testing the same class must see the same children.
CREATE TABLE IF NOT EXISTS students (
    id         INTEGER PRIMARY KEY AUTOINCREMENT,
    name       TEXT NOT NULL,
    grade      TEXT NOT NULL,          -- the "class", e.g. "Class 4-A"
    roll_no    TEXT,
    reg_no     TEXT,
    school     TEXT,
    created_at TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime')),
    -- Two children in one class can share a name; the roll number is what the
    -- school uses to tell them apart, so that pair is what must be unique.
    UNIQUE (grade, roll_no)
);

-- ── BMI / Height Estimator ────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS bmi (
    id               INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id       INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    height_cm        REAL,
    weight_kg        REAL,
    bmi_value        REAL,
    bmi_category     TEXT,          -- Underweight / Normal / Overweight / Obese
    calibration_used INTEGER DEFAULT 0,   -- 1 = calibrated, 0 = uncalibrated
    recorded_at      TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Wingspan Measurement ──────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS wingspan (
    id                      INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id              INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    wingspan_cm             REAL,
    height_cm               REAL,         -- snapshot height for ratio
    wingspan_ratio          REAL,         -- wingspan / height  (NULL if height missing)
    calibration_distance_cm REAL,
    recorded_at             TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Partial Curl-Up Counter ───────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS curl_up (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    reps         INTEGER,        -- total curl-ups in 30 seconds
    duration_sec INTEGER DEFAULT 30,
    rating       TEXT,           -- Excellent / Good / Average / Poor (optional)
    recorded_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Modified Pull-Up Counter ──────────────────────────────────────────────
-- One untimed trial that ends on a two-second pause; duration_sec is how long
-- the attempt took, recorded for context only (the protocol scores reps alone).
CREATE TABLE IF NOT EXISTS pull_up (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    reps         INTEGER,        -- total correct modified pull-ups
    duration_sec REAL,
    rating       TEXT,
    recorded_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Pull-Up Counter ───────────────────────────────────────────────────────
-- Full-hang pull-ups, one untimed trial; duration_sec is context only.
CREATE TABLE IF NOT EXISTS full_pull_up (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    reps         INTEGER,        -- total correct pull-ups
    duration_sec REAL,
    rating       TEXT,
    recorded_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Wall Toss Coordination Test ───────────────────────────────────────────
CREATE TABLE IF NOT EXISTS wall_toss (
    id             INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id     INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    catches        INTEGER,      -- alternating catches in 30 seconds
    duration_sec   INTEGER DEFAULT 30,
    ball_colour    TEXT,         -- colour preset used (e.g. "orange")
    rating         TEXT,
    recorded_at    TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── 4×10 m Shuttle Run Timer ──────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS shuttle_run (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    lane         INTEGER DEFAULT 1,  -- lane number 1–4
    time_sec     REAL,               -- total elapsed time for 4×10 m
    rating       TEXT,
    recorded_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── 50 m Dash Timer ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS dash_50m (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    lane         INTEGER DEFAULT 1,
    time_sec     REAL,
    start_mode   TEXT DEFAULT 'whistle',  -- 'whistle' | 'manual'
    rating       TEXT,
    recorded_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Sit and Reach Test ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS sit_reach (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    reach_cm        REAL,        -- forward reach (positive = past feet)
    leg_cm          REAL,        -- hip-to-ankle length used for calibration
    rating          TEXT,
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Trunk Lift Test ───────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS trunk_lift (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    lift_cm         REAL,        -- best trial, chin to floor, capped at 30.5 cm (12 in)
    trial1_cm       REAL,        -- the two trials the protocol allows, kept for review
    trial2_cm       REAL,
    stick_cm        REAL,        -- measuring-stick length used to set the scale
    rating          TEXT,
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Reverse Curl Test ─────────────────────────────────────────────────────
-- Pass/fail on a single trial (Brockport p.84), so there is no score to
-- record — `passed` IS the result. peak_angle_deg and hold_s are kept so the
-- coach can see how close a failed trial came.
CREATE TABLE IF NOT EXISTS reverse_curl (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    passed          INTEGER,     -- 1 = one correct reverse curl, 0 = not completed
    arm             TEXT,        -- 'left' / 'right' — the preferred arm used
    peak_angle_deg  REAL,        -- deepest interior elbow angle reached (target <= 45)
    hold_s          REAL,        -- longest hold at the target (protocol: 2 s)
    rating          TEXT,        -- 'Pass' / 'Fail'
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Shoulder Stretch Test ─────────────────────────────────────────────────
-- Pass/fail on a single trial (Brockport figure 5.27), scored on BOTH sides:
-- the student passes only if the fingertips touch with the right arm over AND
-- with the left arm over, inside one 15 s trial. `passed` IS that result.
-- best_gap_ratio is the closest the fingertips came during the trial, as a
-- fraction of the participant's own palm length (self-calibrating, so it is
-- comparable across students and camera distances). It is recorded on every
-- row so the 0.20 pass threshold can be retuned from real student data later.
CREATE TABLE IF NOT EXISTS shoulder_stretch (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    passed          INTEGER,     -- 1 = BOTH sides touched, 0 = not
    left_passed     INTEGER,     -- 1 = fingertips touched, left arm over
    right_passed    INTEGER,     -- 1 = fingertips touched, right arm over
    side            TEXT,        -- legacy (single-side trials); unused now
    best_gap_ratio  REAL,        -- smallest fingertip gap / palm length seen (pass <= 0.20)
    best_gap_left   REAL,        -- same, for the left-arm-over attempt
    best_gap_right  REAL,        -- same, for the right-arm-over attempt
    rating          TEXT,        -- 'Pass' / 'Fail'
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Isometric Push-Up Test ────────────────────────────────────────────────
-- One trial (Brockport fig. 5.14): the up position of a push-up held as long
-- as possible, max 40 s. hold_sec is the score, to the nearest second.
CREATE TABLE IF NOT EXISTS isometric_push_up (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    hold_sec        INTEGER,     -- seconds held, 0-40 (the score)
    held_exact_s    REAL,        -- the camera's unrounded time, for review
    end_reason      TEXT,        -- why the clock stopped, e.g. 'elbows bent'
    rating          TEXT,
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Seated Push-Up Test ───────────────────────────────────────────────────
-- One trial (Brockport fig. 5.21): the body held off the seat on extended
-- arms as long as possible, max 20 s. hold_sec is the score, to the nearest
-- second.
CREATE TABLE IF NOT EXISTS seated_push_up (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    hold_sec        INTEGER,     -- seconds held, 0-20 (the score)
    held_exact_s    REAL,        -- the camera's unrounded time, for review
    end_reason      TEXT,        -- why the clock stopped, e.g. 'elbows bent'
    rating          TEXT,
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Target Stretch Test ───────────────────────────────────────────────────
-- Range of motion at ONE joint per row (Brockport form 5.1), measured on the
-- left and then the right side. *_deg is the angle held for 1 s, rounded to
-- the nearest 15 degrees ("half hour" on the clock); *_score is 0/1/2 from
-- table 5.3. Elbow and knee extension read 0 when straight and minus when
-- short of straight. A side that was not measured is NULL.
CREATE TABLE IF NOT EXISTS target_stretch (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    joint           TEXT NOT NULL,   -- e.g. 'shoulder_abduction'
    left_deg        INTEGER,         -- clock degrees, nearest 15
    left_score      INTEGER,         -- 0, 1 or 2
    left_exact      REAL,            -- the camera's unrounded angle, for review
    right_deg       INTEGER,
    right_score     INTEGER,
    right_exact     REAL,
    rating          TEXT,            -- the joint's name
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Dumbbell Press ───────────────────────────────────────────────────────
-- One trial (Brockport fig. 5.9): a 15 lb dumbbell pressed overhead from the
-- shoulder as many times as possible, max 50. reps is the score; the trial
-- ends at 50, after a 4 s rest, or when the coach stops it.
CREATE TABLE IF NOT EXISTS dumbbell_press (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    reps            INTEGER,     -- correct presses, 0-50 (the score)
    arm             TEXT,        -- 'left' / 'right', the arm that pressed
    duration_sec    REAL,        -- START to the end, for context only
    end_reason      TEXT,        -- '50 reps', 'rested 4 s', 'stopped by coach'
    rating          TEXT,
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Push-Up ──────────────────────────────────────────────────────────────
-- One trial (Brockport fig. 5.17): push-ups on the toes at about 1 every
-- 3 s, as many as possible. reps is the score (correct push-ups only); the
-- trial ends after 6 s with no push-up or when the coach stops it.
CREATE TABLE IF NOT EXISTS push_up (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    reps            INTEGER,     -- correct push-ups (the score)
    duration_sec    REAL,        -- START to the end, for context only
    end_reason      TEXT,        -- 'no push-up for 6 s', 'stopped by coach'
    rating          TEXT,
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Modified Curl-Up ─────────────────────────────────────────────────────
-- One trial (Brockport fig. 5.8): curl-ups with the hands sliding up the
-- thighs to the kneecaps, about 1 every 3 s, up to 75. reps is the score
-- (correct curl-ups only); the trial ends at 75, after 6 s with no curl-up,
-- or when the coach stops it.
CREATE TABLE IF NOT EXISTS modified_curl_up (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    reps            INTEGER,     -- correct curl-ups, 0-75 (the score)
    duration_sec    REAL,        -- START to the end, for context only
    end_reason      TEXT,        -- 'reached 75', 'no curl-up for 6 s', 'stopped by coach'
    rating          TEXT,
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Bench Press ──────────────────────────────────────────────────────────
-- One trial (Brockport fig. 5.6): a 35 lb barbell pressed from the chest to
-- straight arms, lying on a bench, as many times as possible - max 50 for
-- boys, 30 for girls. reps is the score; the trial ends at the max, after a
-- 4 s rest, with 0 if no rep in 15 s, or when the coach stops it.
CREATE TABLE IF NOT EXISTS bench_press (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    reps            INTEGER,     -- correct presses, 0-50 / 0-30 (the score)
    sex             TEXT,        -- 'boy' / 'girl', which max applied
    duration_sec    REAL,        -- START to the end, for context only
    end_reason      TEXT,        -- 'max reps', 'rested 4 s', 'no rep in 15 s', 'stopped by coach'
    rating          TEXT,
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Modified Push-Up tracker (live site page) ─────────────────────────────
-- The in-browser tracker at /modified_pushup_tracker counts on the phone and
-- syncs to the website itself; it also posts its count here. Same columns as
-- the table already on the live server.
CREATE TABLE IF NOT EXISTS modified_pushup (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER NOT NULL REFERENCES sessions(id) ON DELETE CASCADE,
    reps         INTEGER NOT NULL,
    duration_sec INTEGER,
    notes        TEXT,
    rating       TEXT,
    created_at   DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- ── Modified Thomas Test ──────────────────────────────────────────────────
-- One trial per leg (Brockport fig. 5.28): lying on the back, hip 28 cm from
-- the table edge, the other knee pulled to the chest. The coach scores each
-- thigh 0-3 by its height above the table edge (3 = touching, 2 = under
-- 7.6 cm, 1 = 7.6-15.2 cm, 0 = over 15.2 cm). No camera. A leg that was not
-- tested is NULL; score is the lower of the two, which the website gets.
CREATE TABLE IF NOT EXISTS modified_thomas (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    left_score      INTEGER,     -- 0-3, left hip
    right_score     INTEGER,     -- 0-3, right hip
    score           INTEGER,     -- the lower of the two
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Modified Apley Test ───────────────────────────────────────────────────
-- One trial per arm (Brockport fig. 5.24), scored by the camera from behind:
-- 3 = touches the top inner corner of the opposite shoulder blade, 2 = the
-- top of the head, 1 = the mouth, 0 = can't reach the mouth, each held 1 s.
-- An arm that was not tested is NULL; score is the lower of the two, which
-- the website gets.
CREATE TABLE IF NOT EXISTS modified_apley (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    left_score      INTEGER,     -- 0-3, left arm
    right_score     INTEGER,     -- 0-3, right arm
    score           INTEGER,     -- the lower of the two
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Wheelchair Ramp Test ──────────────────────────────────────────────────
-- The student pushes their wheelchair up a 1:12 ramp (Brockport p. 87),
-- scored by the camera side-on: 2 = the rear wheels got past the 15 ft line,
-- 1 = past the 8 ft line, 0 = not past the 8 ft line. reached_m is how far
-- up the ramp the back of the rear wheel got. The website gets the score.
CREATE TABLE IF NOT EXISTS wheelchair_ramp (
    id              INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id      INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    score           INTEGER NOT NULL,   -- 0-2
    reached_m       REAL,
    recorded_at     TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Vertical Jump Test ────────────────────────────────────────────────────
CREATE TABLE IF NOT EXISTS vertical_jump (
    id                INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id        INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    jump_cm           REAL,        -- best (max) jump height across attempts
    average_jump_cm   REAL,
    standing_reach_cm REAL,
    attempts_json     TEXT,        -- JSON array of per-attempt jump heights (cm)
    rating            TEXT,
    recorded_at       TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── 600 m Run (multi-lane colour tracking) ────────────────────────────────
CREATE TABLE IF NOT EXISTS run_600m (
    id           INTEGER PRIMARY KEY AUTOINCREMENT,
    session_id   INTEGER REFERENCES sessions(id) ON DELETE CASCADE,
    lane         INTEGER DEFAULT 1,   -- lane number 1–5
    time_sec     REAL,                -- total elapsed time to complete 600 m
    lap_count    INTEGER,             -- number of finish-line crossings recorded
    rating       TEXT,
    recorded_at  TEXT NOT NULL DEFAULT (strftime('%Y-%m-%dT%H:%M:%S','now','localtime'))
);

-- ── Convenience view: all results flat ────────────────────────────────────
DROP VIEW IF EXISTS all_results;
CREATE VIEW IF NOT EXISTS all_results AS
    SELECT 'bmi' AS test, b.id AS row_id, b.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           b.height_cm, b.weight_kg, b.bmi_value AS primary_result, b.bmi_category AS rating, b.recorded_at
    FROM bmi b LEFT JOIN sessions s ON b.session_id = s.id
UNION ALL
    SELECT 'wingspan', w.id, w.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, w.wingspan_cm, NULL, w.recorded_at
    FROM wingspan w LEFT JOIN sessions s ON w.session_id = s.id
UNION ALL
    SELECT 'curl_up', c.id, c.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, c.reps, c.rating, c.recorded_at
    FROM curl_up c LEFT JOIN sessions s ON c.session_id = s.id
UNION ALL
    SELECT 'pull_up', p.id, p.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, p.reps, p.rating, p.recorded_at
    FROM pull_up p LEFT JOIN sessions s ON p.session_id = s.id
UNION ALL
    SELECT 'full_pull_up', f.id, f.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, f.reps, f.rating, f.recorded_at
    FROM full_pull_up f LEFT JOIN sessions s ON f.session_id = s.id
UNION ALL
    SELECT 'wall_toss', t.id, t.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, t.catches, t.rating, t.recorded_at
    FROM wall_toss t LEFT JOIN sessions s ON t.session_id = s.id
UNION ALL
    SELECT 'shuttle_run', r.id, r.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, r.time_sec, r.rating, r.recorded_at
    FROM shuttle_run r LEFT JOIN sessions s ON r.session_id = s.id
UNION ALL
    SELECT 'dash_50m', d.id, d.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, d.time_sec, d.rating, d.recorded_at
    FROM dash_50m d LEFT JOIN sessions s ON d.session_id = s.id
UNION ALL
    SELECT 'sit_reach', sr.id, sr.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, sr.reach_cm, sr.rating, sr.recorded_at
    FROM sit_reach sr LEFT JOIN sessions s ON sr.session_id = s.id
UNION ALL
    SELECT 'trunk_lift', tl.id, tl.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, tl.lift_cm, tl.rating, tl.recorded_at
    FROM trunk_lift tl LEFT JOIN sessions s ON tl.session_id = s.id
UNION ALL
    SELECT 'vertical_jump', vj.id, vj.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, vj.jump_cm, vj.rating, vj.recorded_at
    FROM vertical_jump vj LEFT JOIN sessions s ON vj.session_id = s.id
UNION ALL
    SELECT 'run_600m', rm.id, rm.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, rm.time_sec, rm.rating, rm.recorded_at
    FROM run_600m rm LEFT JOIN sessions s ON rm.session_id = s.id
UNION ALL
    SELECT 'reverse_curl', rc.id, rc.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, rc.passed, rc.rating, rc.recorded_at
    FROM reverse_curl rc LEFT JOIN sessions s ON rc.session_id = s.id
UNION ALL
    SELECT 'shoulder_stretch', ss.id, ss.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, ss.passed, ss.rating, ss.recorded_at
    FROM shoulder_stretch ss LEFT JOIN sessions s ON ss.session_id = s.id
UNION ALL
    SELECT 'isometric_push_up', ip.id, ip.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, ip.hold_sec, ip.rating, ip.recorded_at
    FROM isometric_push_up ip LEFT JOIN sessions s ON ip.session_id = s.id
UNION ALL
    SELECT 'seated_push_up', sp.id, sp.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, sp.hold_sec, sp.rating, sp.recorded_at
    FROM seated_push_up sp LEFT JOIN sessions s ON sp.session_id = s.id
UNION ALL
    SELECT 'target_stretch', tst.id, tst.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL,
           'L ' || COALESCE(tst.left_score, '-') || ' / R ' || COALESCE(tst.right_score, '-'),
           tst.rating, tst.recorded_at
    FROM target_stretch tst LEFT JOIN sessions s ON tst.session_id = s.id
UNION ALL
    SELECT 'dumbbell_press', dbp.id, dbp.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, dbp.reps, dbp.rating, dbp.recorded_at
    FROM dumbbell_press dbp LEFT JOIN sessions s ON dbp.session_id = s.id
UNION ALL
    SELECT 'push_up', pu.id, pu.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, pu.reps, pu.rating, pu.recorded_at
    FROM push_up pu LEFT JOIN sessions s ON pu.session_id = s.id
UNION ALL
    SELECT 'modified_curl_up', mcu.id, mcu.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, mcu.reps, mcu.rating, mcu.recorded_at
    FROM modified_curl_up mcu LEFT JOIN sessions s ON mcu.session_id = s.id
UNION ALL
    SELECT 'bench_press', bpr.id, bpr.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, bpr.reps, bpr.rating, bpr.recorded_at
    FROM bench_press bpr LEFT JOIN sessions s ON bpr.session_id = s.id
UNION ALL
    SELECT 'modified_thomas', mtt.id, mtt.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL,
           'L ' || COALESCE(mtt.left_score, '-') || ' / R ' || COALESCE(mtt.right_score, '-'),
           NULL, mtt.recorded_at
    FROM modified_thomas mtt LEFT JOIN sessions s ON mtt.session_id = s.id
UNION ALL
    SELECT 'modified_apley', mat.id, mat.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL,
           'L ' || COALESCE(mat.left_score, '-') || ' / R ' || COALESCE(mat.right_score, '-'),
           NULL, mat.recorded_at
    FROM modified_apley mat LEFT JOIN sessions s ON mat.session_id = s.id
UNION ALL
    SELECT 'wheelchair_ramp', wrt.id, wrt.session_id, s.student_name, s.age, s.gender, s.school, s.grade,
           NULL, NULL, wrt.score, NULL, wrt.recorded_at
    FROM wheelchair_ramp wrt LEFT JOIN sessions s ON wrt.session_id = s.id;
"""


def _bmi_category(bmi: float) -> str:
    if bmi < 18.5:   return "Underweight"
    elif bmi < 25.0: return "Normal"
    elif bmi < 30.0: return "Overweight"
    else:            return "Obese"


# Columns added to tables that already exist on machines which ran an earlier
# version. CREATE TABLE IF NOT EXISTS never alters an existing table, so a
# column added later has to be applied by hand — ALTER TABLE ADD COLUMN is
# cheap and keeps the rows already recorded.
_ADDED_COLUMNS = {
    "shoulder_stretch": [
        ("left_passed",    "INTEGER"),
        ("right_passed",   "INTEGER"),
        ("best_gap_left",  "REAL"),
        ("best_gap_right", "REAL"),
    ],
}


def init_db():
    """Create tables if they don't exist, then add any newer columns."""
    with _conn() as con:
        con.executescript(_SCHEMA)
        for table, columns in _ADDED_COLUMNS.items():
            have = {r[1] for r in con.execute(f"PRAGMA table_info({table})")}
            for name, decl in columns:
                if name not in have:
                    con.execute(f"ALTER TABLE {table} ADD COLUMN {name} {decl}")


# ─────────────────────────────────────────────────────────────────────────────
# Public API class
# ─────────────────────────────────────────────────────────────────────────────

class GoForFitDB:
    def __init__(self):
        init_db()

    # ── Sessions ─────────────────────────────────────────────────────────

    def new_session(
        self,
        student_name: str = None,
        age: int = None,
        gender: str = None,
        school: str = None,
        grade: str = None,
        notes: str = None,
    ) -> int:
        """Create a new session row and return its id."""
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO sessions (student_name, age, gender, school, grade, notes)
                   VALUES (?,?,?,?,?,?)""",
                (student_name, age, gender, school, grade, notes),
            )
            return cur.lastrowid

    def get_session(self, session_id: int) -> dict:
        with _conn() as con:
            row = con.execute("SELECT * FROM sessions WHERE id=?", (session_id,)).fetchone()
            return dict(row) if row else None

    def list_sessions(self) -> list[dict]:
        with _conn() as con:
            rows = con.execute("SELECT * FROM sessions ORDER BY created_at DESC").fetchall()
            return [dict(r) for r in rows]

    # ── Students (roster) ────────────────────────────────────────────────

    def list_classes(self) -> list[str]:
        with _conn() as con:
            return [r["grade"] for r in con.execute(
                "SELECT DISTINCT grade FROM students ORDER BY grade")]

    def list_students(self, grade: str = None) -> list[dict]:
        q = "SELECT * FROM students"
        params = ()
        if grade is not None:
            q += " WHERE grade=?"
            params = (grade,)
        # Roll numbers are strings but read as numbers, so "10" must not sort
        # before "9". CAST puts the numeric ones in human order and leaves
        # anything non-numeric (e.g. "12B") to fall back on the text sort.
        q += " ORDER BY CAST(roll_no AS INTEGER), roll_no, name"
        with _conn() as con:
            return [dict(r) for r in con.execute(q, params)]

    def get_student(self, student_id: int) -> dict:
        with _conn() as con:
            row = con.execute("SELECT * FROM students WHERE id=?", (student_id,)).fetchone()
            return dict(row) if row else None

    def add_student(self, name: str, grade: str, roll_no: str = None,
                    reg_no: str = None, school: str = None) -> int:
        """Returns the new id, or raises sqlite3.IntegrityError if that class
        already has a student with this roll number."""
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO students (name, grade, roll_no, reg_no, school)
                   VALUES (?,?,?,?,?)""",
                (name, grade, roll_no, reg_no, school),
            )
            return cur.lastrowid

    def delete_student(self, student_id: int) -> bool:
        """Removes a student from the roster. Their past results are NOT
        touched — those live in sessions keyed by name, and deleting a child
        from the register must never quietly erase measurements already taken.
        """
        with _conn() as con:
            return con.execute("DELETE FROM students WHERE id=?", (student_id,)).rowcount > 0

    # ── BMI ──────────────────────────────────────────────────────────────

    def save_bmi(
        self,
        session_id: int,
        height_cm: float,
        weight_kg: float = None,
        calibration_used: bool = False,
    ) -> int:
        bmi_val  = None
        category = None
        if weight_kg and height_cm:
            bmi_val  = round(weight_kg / ((height_cm / 100) ** 2), 2)
            category = _bmi_category(bmi_val)

        with _conn() as con:
            cur = con.execute(
                """INSERT INTO bmi (session_id, height_cm, weight_kg, bmi_value, bmi_category, calibration_used)
                   VALUES (?,?,?,?,?,?)""",
                (session_id, height_cm, weight_kg, bmi_val, category, int(calibration_used)),
            )
            return cur.lastrowid

    # ── Wingspan ─────────────────────────────────────────────────────────

    def save_wingspan(
        self,
        session_id: int,
        wingspan_cm: float,
        height_cm: float = None,
        calibration_distance_cm: float = None,
    ) -> int:
        ratio = round(wingspan_cm / height_cm, 3) if height_cm else None
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO wingspan (session_id, wingspan_cm, height_cm, wingspan_ratio, calibration_distance_cm)
                   VALUES (?,?,?,?,?)""",
                (session_id, wingspan_cm, height_cm, ratio, calibration_distance_cm),
            )
            return cur.lastrowid

    # ── Curl-Up ──────────────────────────────────────────────────────────

    def save_curl_up(
        self,
        session_id: int,
        reps: int,
        duration_sec: int = 30,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO curl_up (session_id, reps, duration_sec, rating)
                   VALUES (?,?,?,?)""",
                (session_id, reps, duration_sec, rating),
            )
            return cur.lastrowid

    # ── Modified Pull-Up ─────────────────────────────────────────────────

    def save_pull_up(
        self,
        session_id: int,
        reps: int,
        duration_sec: float = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO pull_up (session_id, reps, duration_sec, rating)
                   VALUES (?,?,?,?)""",
                (session_id, reps, duration_sec, rating),
            )
            return cur.lastrowid

    # ── Pull-Up ──────────────────────────────────────────────────────────

    def save_full_pull_up(
        self,
        session_id: int,
        reps: int,
        duration_sec: float = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO full_pull_up (session_id, reps, duration_sec, rating)
                   VALUES (?,?,?,?)""",
                (session_id, reps, duration_sec, rating),
            )
            return cur.lastrowid

    # ── Wall Toss ────────────────────────────────────────────────────────

    def save_wall_toss(
        self,
        session_id: int,
        catches: int,
        duration_sec: int = 30,
        ball_colour: str = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO wall_toss (session_id, catches, duration_sec, ball_colour, rating)
                   VALUES (?,?,?,?,?)""",
                (session_id, catches, duration_sec, ball_colour, rating),
            )
            return cur.lastrowid

    # ── Shuttle Run ──────────────────────────────────────────────────────

    def save_shuttle_run(
        self,
        session_id: int,
        time_sec: float,
        lane: int = 1,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO shuttle_run (session_id, lane, time_sec, rating)
                   VALUES (?,?,?,?)""",
                (session_id, lane, time_sec, rating),
            )
            return cur.lastrowid

    # ── 50 m Dash ────────────────────────────────────────────────────────

    def save_dash_50m(
        self,
        session_id: int,
        time_sec: float,
        lane: int = 1,
        start_mode: str = "whistle",
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO dash_50m (session_id, lane, time_sec, start_mode, rating)
                   VALUES (?,?,?,?,?)""",
                (session_id, lane, time_sec, start_mode, rating),
            )
            return cur.lastrowid

    # ── Sit and Reach ────────────────────────────────────────────────────

    def save_sit_reach(
        self,
        session_id: int,
        reach_cm: float,
        leg_cm: float = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO sit_reach (session_id, reach_cm, leg_cm, rating)
                   VALUES (?,?,?,?)""",
                (session_id, reach_cm, leg_cm, rating),
            )
            return cur.lastrowid
        
    # ── Trunk Lift ───────────────────────────────────────────────────────

    def save_trunk_lift(
        self,
        session_id: int,
        lift_cm: float,
        trial1_cm: float = None,
        trial2_cm: float = None,
        stick_cm: float = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO trunk_lift (session_id, lift_cm, trial1_cm, trial2_cm,
                                           stick_cm, rating)
                   VALUES (?,?,?,?,?,?)""",
                (session_id, lift_cm, trial1_cm, trial2_cm, stick_cm, rating),
            )
            return cur.lastrowid

    # ── Reverse Curl ─────────────────────────────────────────────────────

    def save_reverse_curl(
        self,
        session_id: int,
        passed: bool,
        arm: str = None,
        peak_angle_deg: float = None,
        hold_s: float = None,
        rating: str = None,
    ) -> int:
        """One trial, pass/fail. `rating` defaults to Pass/Fail so the results
        view shows a word rather than a bare 1/0."""
        if rating is None:
            rating = "Pass" if passed else "Fail"
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO reverse_curl (session_id, passed, arm,
                                             peak_angle_deg, hold_s, rating)
                   VALUES (?,?,?,?,?,?)""",
                (session_id, 1 if passed else 0, arm, peak_angle_deg, hold_s, rating),
            )
            return cur.lastrowid

    # ── Shoulder Stretch ─────────────────────────────────────────────────

    def save_shoulder_stretch(
        self,
        session_id: int,
        passed: bool,
        left_passed: bool = None,
        right_passed: bool = None,
        best_gap_ratio: float = None,
        best_gap_left: float = None,
        best_gap_right: float = None,
        rating: str = None,
    ) -> int:
        """One trial, pass/fail, scored on BOTH sides: `passed` is true only
        when both arms banked a touch. The per-side flags and closest gaps are
        kept on every row so the pass threshold can be retuned from real data
        and so a coach can see which side let the student down."""
        if rating is None:
            rating = "Pass" if passed else "Fail"
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO shoulder_stretch (session_id, passed,
                        left_passed, right_passed, best_gap_ratio,
                        best_gap_left, best_gap_right, rating)
                   VALUES (?,?,?,?,?,?,?,?)""",
                (session_id, 1 if passed else 0,
                 None if left_passed is None else int(bool(left_passed)),
                 None if right_passed is None else int(bool(right_passed)),
                 best_gap_ratio, best_gap_left, best_gap_right, rating),
            )
            return cur.lastrowid

    # ── Isometric Push-Up ────────────────────────────────────────────────

    def save_isometric_push_up(
        self,
        session_id: int,
        hold_sec: int,
        held_exact_s: float = None,
        end_reason: str = None,
        rating: str = None,
    ) -> int:
        """One trial: seconds the up position was held, 0-40."""
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO isometric_push_up (session_id, hold_sec,
                                                  held_exact_s, end_reason, rating)
                   VALUES (?,?,?,?,?)""",
                (session_id, hold_sec, held_exact_s, end_reason, rating),
            )
            return cur.lastrowid

    # ── Seated Push-Up ───────────────────────────────────────────────────

    def save_seated_push_up(
        self,
        session_id: int,
        hold_sec: int,
        held_exact_s: float = None,
        end_reason: str = None,
        rating: str = None,
    ) -> int:
        """One trial: seconds the body was held off the seat, 0-20."""
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO seated_push_up (session_id, hold_sec,
                                               held_exact_s, end_reason, rating)
                   VALUES (?,?,?,?,?)""",
                (session_id, hold_sec, held_exact_s, end_reason, rating),
            )
            return cur.lastrowid

    # ── Target Stretch ───────────────────────────────────────────────────

    def save_target_stretch(
        self,
        session_id: int,
        joint: str,
        left_deg: int = None,
        left_score: int = None,
        left_exact: float = None,
        right_deg: int = None,
        right_score: int = None,
        right_exact: float = None,
        rating: str = None,
    ) -> int:
        """One joint, both sides: clock degrees and a 0-2 score per side."""
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO target_stretch (session_id, joint,
                        left_deg, left_score, left_exact,
                        right_deg, right_score, right_exact, rating)
                   VALUES (?,?,?,?,?,?,?,?,?)""",
                (session_id, joint, left_deg, left_score, left_exact,
                 right_deg, right_score, right_exact, rating),
            )
            return cur.lastrowid

    # ── Dumbbell Press ───────────────────────────────────────────────────

    def save_dumbbell_press(
        self,
        session_id: int,
        reps: int,
        arm: str = None,
        duration_sec: float = None,
        end_reason: str = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO dumbbell_press (session_id, reps, arm,
                        duration_sec, end_reason, rating)
                   VALUES (?,?,?,?,?,?)""",
                (session_id, reps, arm, duration_sec, end_reason, rating),
            )
            return cur.lastrowid

    # ── Push-Up ──────────────────────────────────────────────────────────

    def save_push_up(
        self,
        session_id: int,
        reps: int,
        duration_sec: float = None,
        end_reason: str = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO push_up (session_id, reps,
                        duration_sec, end_reason, rating)
                   VALUES (?,?,?,?,?)""",
                (session_id, reps, duration_sec, end_reason, rating),
            )
            return cur.lastrowid

    # ── Modified Curl-Up ─────────────────────────────────────────────────

    def save_modified_curl_up(
        self,
        session_id: int,
        reps: int,
        duration_sec: float = None,
        end_reason: str = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO modified_curl_up (session_id, reps,
                        duration_sec, end_reason, rating)
                   VALUES (?,?,?,?,?)""",
                (session_id, reps, duration_sec, end_reason, rating),
            )
            return cur.lastrowid

    # ── Bench Press ──────────────────────────────────────────────────────

    def save_bench_press(
        self,
        session_id: int,
        reps: int,
        sex: str = None,
        duration_sec: float = None,
        end_reason: str = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO bench_press (session_id, reps, sex,
                        duration_sec, end_reason, rating)
                   VALUES (?,?,?,?,?,?)""",
                (session_id, reps, sex, duration_sec, end_reason, rating),
            )
            return cur.lastrowid

    # ── Modified Push-Up tracker ─────────────────────────────────────────

    def save_modified_pushup(
        self,
        session_id: int,
        reps: int,
        duration_sec: int = None,
        notes: str = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO modified_pushup (session_id, reps, duration_sec,
                        notes, rating)
                   VALUES (?,?,?,?,?)""",
                (session_id, reps, duration_sec, notes, rating),
            )
            return cur.lastrowid

    # ── Modified Thomas Test ─────────────────────────────────────────────

    def save_modified_thomas(
        self,
        session_id: int,
        left_score: int = None,
        right_score: int = None,
    ) -> int:
        """Both legs' 0-3 scores; a leg not tested is None."""
        score = min(s for s in (left_score, right_score) if s is not None)
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO modified_thomas (session_id, left_score,
                        right_score, score)
                   VALUES (?,?,?,?)""",
                (session_id, left_score, right_score, score),
            )
            return cur.lastrowid

    # ── Modified Apley Test ──────────────────────────────────────────────

    def save_modified_apley(
        self,
        session_id: int,
        left_score: int = None,
        right_score: int = None,
    ) -> int:
        """Both arms' 0-3 scores; an arm not tested is None."""
        score = min(s for s in (left_score, right_score) if s is not None)
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO modified_apley (session_id, left_score,
                        right_score, score)
                   VALUES (?,?,?,?)""",
                (session_id, left_score, right_score, score),
            )
            return cur.lastrowid

    # ── Wheelchair Ramp Test ─────────────────────────────────────────────

    def save_wheelchair_ramp(
        self,
        session_id: int,
        score: int,
        reached_m: float = None,
    ) -> int:
        """The 0-2 score and how far up the back of the rear wheel got."""
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO wheelchair_ramp (session_id, score, reached_m)
                   VALUES (?,?,?)""",
                (session_id, score, reached_m),
            )
            return cur.lastrowid

    # ── Vertical Jump ────────────────────────────────────────────────────

    def save_vertical_jump(
        self,
        session_id: int,
        jump_cm: float,
        average_jump_cm: float = None,
        standing_reach_cm: float = None,
        attempts: list = None,
        rating: str = None,
    ) -> int:
        attempts_json = json.dumps(attempts) if attempts else None
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO vertical_jump
                       (session_id, jump_cm, average_jump_cm, standing_reach_cm, attempts_json, rating)
                   VALUES (?,?,?,?,?,?)""",
                (session_id, jump_cm, average_jump_cm, standing_reach_cm, attempts_json, rating),
            )
            return cur.lastrowid

    # ── 600 m Run ────────────────────────────────────────────────────────

    def save_run_600m(
        self,
        session_id: int,
        time_sec: float,
        lane: int = 1,
        lap_count: int = None,
        rating: str = None,
    ) -> int:
        with _conn() as con:
            cur = con.execute(
                """INSERT INTO run_600m (session_id, lane, time_sec, lap_count, rating)
                   VALUES (?,?,?,?,?)""",
                (session_id, lane, time_sec, lap_count, rating),
            )
            return cur.lastrowid

    # ── Generic fetch helpers ────────────────────────────────────────────

    VALID_TABLES = {
        "bmi", "wingspan", "curl_up", "pull_up", "full_pull_up", "wall_toss",
        "shuttle_run", "dash_50m", "sit_reach", "trunk_lift", "run_600m",
        "vertical_jump", "reverse_curl", "shoulder_stretch", "isometric_push_up",
        "seated_push_up", "target_stretch", "dumbbell_press", "push_up",
        "modified_curl_up", "bench_press", "modified_thomas", "modified_apley",
        "wheelchair_ramp",
    }

    def get_all(self, table: str, session_id: int = None) -> list[dict]:
        """Fetch all rows from a test table, optionally filtered by session."""
        if table not in self.VALID_TABLES:
            raise ValueError(f"Unknown table '{table}'")
        q = f"SELECT * FROM {table}"
        params = ()
        if session_id is not None:
            q += " WHERE session_id=?"
            params = (session_id,)
        q += " ORDER BY recorded_at DESC"
        with _conn() as con:
            return [dict(r) for r in con.execute(q, params).fetchall()]

    def get_all_results(self) -> list[dict]:
        """Flat view across all tests — useful for dashboards."""
        with _conn() as con:
            return [dict(r) for r in con.execute(
                "SELECT * FROM all_results ORDER BY recorded_at DESC"
            ).fetchall()]

    def get_student_summary(self, student_name: str) -> list[dict]:
        """All results for a particular student name."""
        with _conn() as con:
            return [dict(r) for r in con.execute(
                "SELECT * FROM all_results WHERE student_name=? ORDER BY recorded_at DESC",
                (student_name,),
            ).fetchall()]

    def delete_result(self, test: str, row_id: int) -> bool:
        """Delete a single test result row by its id. Returns True if a row was deleted."""
        if test not in self.VALID_TABLES:
            raise ValueError(f"Unknown table '{test}'")
        with _conn() as con:
            cur = con.execute(f"DELETE FROM {test} WHERE id=?", (row_id,))
            return cur.rowcount > 0

    def delete_session(self, session_id: int) -> bool:
        """Delete a session and all its test rows (CASCADE). Returns True if deleted."""
        with _conn() as con:
            cur = con.execute("DELETE FROM sessions WHERE id=?", (session_id,))
            return cur.rowcount > 0

    def export_csv(self, table: str, out_path: str = None) -> str:
        """Export a table to CSV. Returns the file path written."""
        import csv
        rows = self.get_all(table)
        if not rows:
            return None
        out_path = out_path or str(Path(__file__).parent / f"{table}_export.csv")
        with open(out_path, "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=rows[0].keys())
            w.writeheader()
            w.writerows(rows)
        return out_path


# ─────────────────────────────────────────────────────────────────────────────
# Module-level singleton (import and use directly)
# ─────────────────────────────────────────────────────────────────────────────
db = GoForFitDB()


# ─────────────────────────────────────────────────────────────────────────────
# Quick smoke test
# ─────────────────────────────────────────────────────────────────────────────
if __name__ == "__main__":
    print(f"Database : {DB_PATH}")

    # Create a demo session
    sid = db.new_session(
        student_name="Demo Student",
        age=15,
        gender="M",
        school="GoForFit Academy",
        grade="10",
    )
    print(f"Session  : {sid}")

    # Insert one row into every test table
    db.save_bmi(sid, height_cm=170.0, weight_kg=60.0, calibration_used=True)
    db.save_wingspan(sid, wingspan_cm=172.5, height_cm=170.0, calibration_distance_cm=200.0)
    db.save_curl_up(sid, reps=22, rating="Good")
    db.save_wall_toss(sid, catches=18, ball_colour="orange", rating="Average")
    db.save_shuttle_run(sid, time_sec=12.4, lane=1, rating="Good")
    db.save_dash_50m(sid, time_sec=8.1, lane=1, start_mode="whistle", rating="Excellent")
    db.save_sit_reach(sid, reach_cm=5.3, leg_cm=87.0, rating="Average")
    db.save_trunk_lift(sid, lift_cm=23, trial1_cm=21.4, trial2_cm=22.8, stick_cm=30.0)

    print("\n── BMI ──────────────────────────────────────")
    for r in db.get_all("bmi"):
        print(r)

    print("\n── All Results (flat view) ──────────────────")
    for r in db.get_all_results():
        print(r)

    print("\nDone. Tables created and demo data inserted.")