"""
AI-Powered Modified Pull-Up Counter
====================================
FMS protocol ("SR 10 Upper Body Modified Pull-ups"): the bar is set at a
height just reachable by the participant lying on their back. They grip it
with an overgrasp and, on "GO", raise the body by flexing the arms until
THE CHIN REACHES THE LEVEL OF THE BAR, then lower back to the start without
the shoulders touching the ground, repeating as many times as possible.
Knees stay straight. The test ends when the participant pauses for two or
more seconds. Score = number of correctly completed pull-ups.

Note this is NOT the Brockport variant, which uses an elastic band 7-8 in
below the bar as the chin target — there is no band here, the bar itself is
the target, which is also what makes the rep checkable from pose alone
(the hands are ON the bar, so the wrists mark its height).

Compatible with mediapipe >= 0.10.30 using the Tasks API

pip install mediapipe==0.10.35 opencv-python numpy pandas
"""

import cv2
import numpy as np
import pandas as pd
import time
import argparse
from collections import deque

import mediapipe as mp
from mediapipe.tasks import python as mp_python
from mediapipe.tasks.python import vision as mp_vision

# ──────────────────────────────────────────────
# CONFIGURATION
# ──────────────────────────────────────────────
# A rep is an elbow flex-and-extend cycle in which the chin reached the bar.
# The bar's height doesn't have to be guessed: the participant is gripping it,
# so the wrists ARE the bar line. That makes the protocol's own criterion
# ("chin pulled up to the level of horizontal bar") directly checkable, and it
# holds at any camera distance or framing since both points come from the
# same pose.
# Measured off the FMS demo footage (three reps, pose landmarks): the elbow
# sweeps to 12-29 deg at the top and only back to 126-139 deg at the bottom.
# It does NOT straighten out again between reps — the protocol has them lower
# "with shoulders not touching the ground", so the arm keeps some bend and the
# obvious-looking 150+ "arm is straight" return threshold is never reached.
ELBOW_FLEX_ANGLE    = 75     # elbow angle must drop TO/BELOW -> "pulled up"
ELBOW_EXTEND_ANGLE  = 112    # elbow angle must rise TO/ABOVE -> "returned"
CHIN_MARGIN_FRAC    = 0.01   # chin may finish this far below the bar and still count
                             # (absorbs landmark noise in the chin estimate)
# The chin isn't a pose landmark. It sits roughly this many nose->mouth spans
# below the mouth — a facial proportion, so it scales with the person and with
# how close they are to the camera.
CHIN_BELOW_MOUTH_K  = 1.3

# The chin is a guess, so it doesn't decide a rep on its own: the shoulders
# must also have come up past the elbows. Measured on the FMS demo footage
# (three reps), the shoulder sits 0.88 upper-arm lengths ABOVE the elbow at the
# top and 0.89 BELOW it at the bottom, so the signal swings right through zero
# every rep and there is no honest reading anywhere near the middle.
# Measured in upper arms rather than fractions of the frame so it holds at any
# camera distance, the same way the chin-to-bar comparison does.
# 0.40 is set at roughly half the lift every good rep in the footage shows.
# Be straight about it: that footage contains no SHORT rep, so this line is
# placed by judgement between two measured extremes, not measured itself.
# It exists to stop the chin estimate being the only thing standing between a
# tilted head and a rep — a head can tilt, but it cannot lift the shoulders.
SHOULDER_LIFT_MIN   = 0.40

# A rep can only begin from the hanging position: hands on the bar, which puts
# the wrists this far above the shoulders. Measured on the demo footage, the
# gap at the bottom of a rep runs 0.12-0.18 of frame height, so 0.05 passes
# every real rep with room to spare while rejecting someone who simply lifts a
# hand towards their face.
POSTURE_MARGIN      = 0.05
# ...and the grip is re-checked for as long as the rep lasts. Hands that fall
# clearly BELOW the shoulders mean the bar has been let go of. Measured on the
# FMS demo footage, during a real rep the hands never drop more than 0.055 of
# frame height below the shoulders — the top of a pull brings them almost level
# — so a line at 0.10 fired on 0 of 157 real-rep frames while still catching
# someone who has sat up off the bar. Deliberately not the same number as
# POSTURE_MARGIN: starting a rep demands hands clearly above the shoulders,
# abandoning one demands them clearly below, and in between nothing changes.
LET_GO_MARGIN       = 0.10
# Hands above the shoulders isn't enough on its own: sitting upright with a hand
# raised to the face looks the same. What can't be faked upright is the BODY's
# position — lying under the bar, the shoulders are below the elbows. Measured
# inside the three demo rep cycles, 42 of the 43 arm-extended frames read at or
# below -0.30 upper arms (median -0.74, floor -0.89), while an upright person
# never drops below +0.72. Only one qualifying frame per rep is needed, so the
# single outlier costs nothing.
LYING_LIFT_MAX      = -0.30

# "The test will stop when the participant pauses for two or more seconds."
PAUSE_SEC           = 2.0
# A pause only counts if we actually watched them hold still. Frames where the
# pose is lost (spotter crossing the camera, subject drifting out of shot, a
# patch of glare) don't reach the counter at all, so a gap longer than this
# means we stopped looking rather than that they stopped moving.
SAMPLE_GAP_SEC      = 0.5
PAUSE_ANGLE_TOL     = 10.0   # degrees of elbow movement within the window
# Shoulder travel within the window (fraction of frame height). This sets how
# noisy a camera may be and still let the test end itself: too tight and the
# landmark's own wander keeps resetting the clock, so the pause never fires and
# the coach has to reach over and press STOP.
# Measured on the FMS demo footage, a shoulder holding still wanders 0.0064 of
# frame height over half a second, against 0.717 of travel across a rep — four
# orders of magnitude apart, so there is no reason to sit close to the noise.
# 0.012 left under 2x of headroom on clean footage, which a phone in a gym
# would not have. 0.025 gives 3.9x and is still ~28x below a single rep's
# travel, so genuine movement cannot hide inside it.
# Smoothing was tried first and rejected: a 3-frame median of the shoulder only
# moves the margin to 2.0x and 7 frames to 2.1x, because the wander is slow
# drift rather than single-frame jitter.
PAUSE_POS_TOL       = 0.025

# 3-frame medians, not the 5 curl-ups uses: they still drop single-frame
# landmark outliers, but with half the lag, so a brisk rep still reaches both
# angle thresholds when the processing rate drops to ~10 fps on a weak phone.
ANGLE_BUFFER_LEN    = 3     # rolling median smoothing window (elbow angle)
NOSE_BUFFER_LEN     = 3     # rolling median smoothing window (head position)
LIFT_BUFFER_LEN     = 3     # rolling median smoothing window (shoulder lift)
GRIP_BUFFER_LEN     = 3     # rolling median smoothing window (hands vs shoulders)

# MediaPipe Pose landmark indices (same numbering across all API versions)
IDX = {
    "NOSE": 0,
    "MOUTH_L": 9,     "MOUTH_R": 10,
    "L_SHOULDER": 11, "R_SHOULDER": 12,
    "L_ELBOW": 13,    "R_ELBOW": 14,
    "L_WRIST": 15,    "R_WRIST": 16,
}

# Colours BGR
C_GREEN  = (50, 220, 80)
C_ORANGE = (0, 165, 255)
C_RED    = (60, 60, 240)
C_WHITE  = (255, 255, 255)
C_DARK   = (20, 20, 20)
C_YELLOW = (0, 215, 255)

# ──────────────────────────────────────────────
# GEOMETRY
# ──────────────────────────────────────────────

def calc_angle(a, b, c):
    """Angle at B formed by A-B-C vectors (2-D, degrees)."""
    ba = a[:2] - b[:2]
    bc = c[:2] - b[:2]
    cos = np.dot(ba, bc) / (np.linalg.norm(ba) * np.linalg.norm(bc) + 1e-6)
    return float(np.degrees(np.arccos(np.clip(cos, -1.0, 1.0))))


def lm_px(lms, idx, w, h):
    lm = lms[idx]
    return np.array([lm.x * w, lm.y * h], dtype=np.float32)


def near_arm(lms):
    """(shoulder, elbow, wrist) indices of whichever arm the camera sees best,
    plus that arm's visibility. Filmed from the side the far arm is occluded,
    so requiring both would never pass; filmed head-on either arm works."""
    left = (IDX["L_SHOULDER"], IDX["L_ELBOW"], IDX["L_WRIST"])
    right = (IDX["R_SHOULDER"], IDX["R_ELBOW"], IDX["R_WRIST"])
    l_vis = min(lms[i].visibility for i in left)
    r_vis = min(lms[i].visibility for i in right)
    return (left if l_vis >= r_vis else right), max(l_vis, r_vis)


def chin_y(lms):
    """Estimated chin height, 0..1 of frame height (bigger = lower on screen).

    MediaPipe Pose has no chin landmark, so it's projected down from the face:
    the chin sits about CHIN_BELOW_MOUTH_K nose->mouth spans below the mouth."""
    nose = lms[IDX["NOSE"]].y
    mouth = (lms[IDX["MOUTH_L"]].y + lms[IDX["MOUTH_R"]].y) * 0.5
    return mouth + CHIN_BELOW_MOUTH_K * (mouth - nose)


def shoulder_lift(shoulder_px, elbow_px):
    """How far the shoulder has risen above the elbow, in upper-arm lengths
    (+ = shoulder above elbow, - = below).

    Divided by the shoulder->elbow distance, which IS the upper arm and doesn't
    change as the elbow bends, so the reading means the same whether the camera
    is two metres away or five. Unlike the chin this comes from two real
    landmarks, so a head tilt or an invented face can't move it."""
    arm = float(np.linalg.norm(elbow_px[:2] - shoulder_px[:2]))
    if arm < 1e-3:
        return 0.0
    return float((elbow_px[1] - shoulder_px[1]) / arm)


def bar_y(lms, wrist_idx):
    """Height of the bar, 0..1 of frame height. The participant grips the bar,
    so the wrists mark it — both when they're both visible, otherwise the one
    on the arm the camera sees best."""
    lw, rw = lms[IDX["L_WRIST"]], lms[IDX["R_WRIST"]]
    if lw.visibility > 0.5 and rw.visibility > 0.5:
        return (lw.y + rw.y) * 0.5
    return lms[wrist_idx].y


# ──────────────────────────────────────────────
# REP STATE MACHINE
# ──────────────────────────────────────────────

class PullUpCounter:
    """Counts modified pull-ups from a stream of (elbow angle, chin height,
    bar height) samples. Shared by the desktop script and the browser engine
    so both score a rep identically.

    A rep is one elbow flex-and-extend cycle, begun from the position the test
    is performed in — lying under the bar, hands on it — and held there
    throughout,
    in which the chin reached the bar — the protocol's own criterion — AND the
    shoulders came up past the elbows. Both have to happen in the same cycle.
    The chin is only ever an estimate projected from the face, so on its own it
    can be moved by a tilted head; the shoulder lift is two real landmarks and
    takes an actual pull to produce.
    `stopped` goes True once the participant holds still for PAUSE_SEC, which
    is how the test is meant to end.
    """

    def __init__(self):
        self.reset()

    def reset(self):
        self.count = 0
        self.phase = "extended"
        self.angle = 0.0
        self.gap = None          # how far the chin still is below the bar (+ = below),
                                 # or None while the face can't be read
        self.reached = False     # chin has reached the bar during the rep in progress
        self.lift_arms = 0.0     # shoulder height above the elbow, in upper arms
        self.lifted = False      # shoulders have cleared the elbows during this rep
        self.hung = False        # hands seen above the shoulders — on the bar
        self.stopped = False     # ended by the two-second pause rule
        self.idle_sec = 0.0
        self.angle_buf = deque(maxlen=ANGLE_BUFFER_LEN)
        self.chin_buf = deque(maxlen=NOSE_BUFFER_LEN)
        self.lift_buf = deque(maxlen=LIFT_BUFFER_LEN)
        self.grip_buf = deque(maxlen=GRIP_BUFFER_LEN)
        self._ref = None         # last pose the participant actually moved away from
        self._last_move = None   # when that happened
        self._last_seen = None   # when a frame last reached the counter
        self._armed = False      # pause rule only applies once they've begun

    def update(self, elbow_angle, chin, bar, shoulder, lift,
               now=None, counting=True):
        """Feed one frame. `chin`, `bar` and `shoulder` are heights in 0..1 of
        frame height (bigger = lower on screen); `lift` is the shoulder's
        height above the elbow in upper-arm lengths, from shoulder_lift().
        `chin` is None when the face can't be read. Returns True iff this
        frame completed a rep."""
        now = time.time() if now is None else now

        self.angle_buf.append(elbow_angle)
        self.angle = float(np.median(self.angle_buf))
        if chin is None:
            # Face out of view. The arm is still tracked, so the test carries
            # on and the rest of the frame is worth having — but the buffer is
            # dropped rather than held, because a stale median would report a
            # gap measured from wherever the head was last seen. No rep can be
            # credited while this lasts, the chin being half the rule.
            self.chin_buf.clear()
            self.gap = None
        else:
            self.chin_buf.append(chin)
            self.gap = float(np.median(self.chin_buf)) - bar
        self.lift_buf.append(lift)
        self.lift_arms = float(np.median(self.lift_buf))

        if not counting or self.stopped:
            self.reached = False
            self.lifted = False
            return False

        # ── two-second pause rule ──────────────────────────────────────────
        # Movement is measured against the last pose they actually moved away
        # from, not against the previous frame — otherwise a slow-but-steady
        # rep, where each individual frame barely changes, would read as a
        # pause. Armed only after the first pull begins: the participant lies
        # still under the bar waiting for "GO", and that must not end the test.
        # Frames the pose was lost never arrive here, so a gap in the samples is
        # time we spent not looking. Without this the counter would come back
        # from a dropout, see that its last recorded movement was seconds ago,
        # and end a test the participant is still performing.
        blind = (self._last_seen is not None
                 and now - self._last_seen > SAMPLE_GAP_SEC)
        self._last_seen = now
        if blind:
            self._ref = None
            # A rep that was mid-flight is also void: we didn't see how it
            # ended, and "chin reached the bar" earlier in the cycle is not
            # evidence they lowered again rather than dropping off. Scrapping
            # it can cost a real rep, which the coach can add back on the
            # review screen; crediting an unwatched one inflates the score
            # with nothing to show the coach it happened.
            self.phase = "extended"
            self.reached = False
            self.lifted = False
            self.hung = False

        # Stillness is judged on the elbow angle and the SHOULDER height. The
        # shoulder is a tracked landmark rather than a point projected from the
        # face, it travels the full sweep of a rep, and — the reason it changed
        # — it keeps reading when the face doesn't, so a student holding still
        # with their head turned away still ends the test on time.
        if self._ref is None:
            self._ref, self._last_move = (self.angle, shoulder), now
        if (abs(self.angle - self._ref[0]) > PAUSE_ANGLE_TOL
                or abs(shoulder - self._ref[1]) > PAUSE_POS_TOL):
            self._ref, self._last_move = (self.angle, shoulder), now
        self.idle_sec = now - self._last_move
        if self._armed and self.idle_sec >= PAUSE_SEC:
            self.stopped = True
            return False

        # ── still on the bar? ──────────────────────────────────────────────
        # Checked every frame, where the hanging position used to be confirmed
        # once and then trusted for the rest of the rep. That let a student who
        # had let go, sat up and raised a hand to their face be credited one
        # rep: the chin landed at hand height and, sitting upright, the
        # shoulders are above the elbows anyway, so both rep checks passed.
        # Medianed like the others so a single mistracked wrist can't void a
        # real rep.
        self.grip_buf.append(bar - shoulder)
        if float(np.median(self.grip_buf)) > LET_GO_MARGIN:
            self.hung = False
            if self.phase == "flexed":
                # Same treatment as a blind gap: a rep we watched being
                # abandoned is not a rep, whatever the chin did on the way up.
                self.phase = "extended"
                self.reached = False
                self.lifted = False

        # ── rep state machine ──────────────────────────────────────────────
        if self.phase == "extended":
            # Only a participant hanging under the bar can start a rep. Lying
            # under it with arms up, the hands sit well above the shoulders;
            # someone sitting at a desk with a hand near their face does not,
            # so idle movement can't be scored as pull-ups. Checked only while
            # extended — at the TOP of a real rep the shoulders come up almost
            # level with the hands (measured: within 0.01 of frame height), so
            # testing this every frame would reject the very frames that
            # validate the rep.
            # Both: hands on the bar AND the body lying under it. Upright, the
            # first can be mimicked by raising a hand to the face, but the
            # second can't be — standing or sitting puts the shoulders above the
            # elbows, not below them.
            if bar < shoulder - POSTURE_MARGIN and self.lift_arms <= LYING_LIFT_MAX:
                self.hung = True
            if self.hung and self.angle <= ELBOW_FLEX_ANGLE:
                self.phase = "flexed"
                self.reached = False
                self.lifted = False
                self._armed = True
            return False

        # phase == "flexed": did the chin make it up to the bar this rep, and
        # did the shoulders clear the elbows? Both are medians of 3, so each has
        # to hold for two frames (~0.1 s) before it registers — a single
        # glitched landmark frame can't award a rep, while a real turnaround at
        # the top dwells there for longer than that.
        if self.gap is not None and self.gap <= CHIN_MARGIN_FRAC:
            self.reached = True
        if self.lift_arms >= SHOULDER_LIFT_MIN:
            self.lifted = True
        if self.angle >= ELBOW_EXTEND_ANGLE:
            self.phase = "extended"
            # The next rep has to prove the hanging position for itself.
            self.hung = False
            # Both signals, in the same cycle. They fail in different ways —
            # the chin drifts with the head, the lift needs the shoulder and
            # elbow tracked — so requiring both means one of them being fooled
            # can cost a real rep (which the coach can add back on the review
            # screen) but can never invent one.
            if self.reached and self.lifted:
                self.count += 1
                return True
        return False


# ──────────────────────────────────────────────
# UI
# ──────────────────────────────────────────────

def draw_panel(img, x1, y1, x2, y2, r=12, colour=C_DARK, alpha=0.65):
    ov = img.copy()
    cv2.rectangle(ov, (x1+r, y1), (x2-r, y2), colour, -1)
    cv2.rectangle(ov, (x1, y1+r), (x2, y2-r), colour, -1)
    for cx, cy in [(x1+r,y1+r),(x2-r,y1+r),(x1+r,y2-r),(x2-r,y2-r)]:
        cv2.circle(ov, (cx, cy), r, colour, -1)
    cv2.addWeighted(ov, alpha, img, 1-alpha, 0, img)


def draw_ui(frame, count, phase, angle, elapsed, gap, reached, visible, test_started,
            stopped=False, browser_mode=False, hung=True, lifted=False):
    h, w = frame.shape[:2]

    # Count
    draw_panel(frame, 10, 14, 200, 110)
    cv2.putText(frame, "COUNT", (22,38), cv2.FONT_HERSHEY_SIMPLEX, 0.55, C_WHITE, 1, cv2.LINE_AA)
    cv2.putText(frame, f"{count:02d}", (22,100), cv2.FONT_HERSHEY_SIMPLEX, 2.4, C_GREEN, 4, cv2.LINE_AA)

    # Elapsed (count-up — this test has no time limit)
    draw_panel(frame, w-195, 14, w-10, 110)
    cv2.putText(frame, "ELAPSED", (w-183,38), cv2.FONT_HERSHEY_SIMPLEX, 0.55, C_WHITE, 1, cv2.LINE_AA)
    mm, ss = divmod(int(elapsed), 60)
    cv2.putText(frame, f"{mm:02d}:{ss:02d}", (w-185,100), cv2.FONT_HERSHEY_SIMPLEX, 1.5, C_GREEN, 3, cv2.LINE_AA)

    # Bottom info
    draw_panel(frame, 10, h-75, 470, h-10)
    if visible:
        cv2.putText(frame, f"Elbow Angle: {angle:.1f} deg", (20,h-48),
                    cv2.FONT_HERSHEY_SIMPLEX, 0.65, C_WHITE, 1, cv2.LINE_AA)
        if not hung and phase == "extended":
            # Nothing can be scored until they're hanging under the bar — say
            # so, rather than showing a chin reading that can't count.
            cv2.putText(frame, "Grip the bar - hands above shoulders",
                        (20,h-20), cv2.FONT_HERSHEY_SIMPLEX, 0.65, C_YELLOW, 2, cv2.LINE_AA)
        elif gap is None:
            # The arm is tracked and the test is running, but the face isn't
            # readable, so the chin can't be checked and this rep can't be
            # credited. Say that plainly instead of printing a number we don't
            # have — the coach can move the phone or the student's head.
            cv2.putText(frame, "Chin not visible - turn the face to the camera",
                        (20,h-20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, C_YELLOW, 2, cv2.LINE_AA)
        else:
            arrow = "^ PULL UP" if phase == "extended" else "v RETURN"
            # Both checks have to pass in one cycle, so the line says which of
            # them is still missing — a coach watching a rep that didn't count
            # can see whether the chin came short or the body never came up.
            if reached and lifted:
                chin_txt, cc = "CHIN AT BAR + SHOULDERS UP", C_GREEN
            elif reached:
                chin_txt, cc = "Chin at bar - pull the body higher", C_ORANGE
            elif lifted:
                chin_txt, cc = "Shoulders up - chin not at bar yet", C_ORANGE
            else:
                chin_txt, cc = f"Chin {gap*100:.1f}% below bar", C_ORANGE
            cv2.putText(frame, f"{chin_txt}  {arrow}",
                        (20,h-20), cv2.FONT_HERSHEY_SIMPLEX, 0.6, cc, 2, cv2.LINE_AA)
    else:
        # The bar itself is never detected — the wrists stand in for it — so
        # the message names what actually has to be visible. The face is no
        # longer part of this: without it the test still runs, it just can't
        # credit reps, and that gets its own message above.
        cv2.putText(frame, "One full arm (shoulder to hand) must be visible",
                    (20,h-30), cv2.FONT_HERSHEY_SIMPLEX, 0.62, C_YELLOW, 2, cv2.LINE_AA)

    # Ended by the two-second pause rule
    if stopped:
        ov = frame.copy()
        cv2.rectangle(ov, (0,0), (w,h), (0,0,0), -1)
        cv2.addWeighted(ov, 0.55, frame, 0.45, 0, frame)
        cv2.putText(frame, "TEST ENDED", (w//2-220, h//2-40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.8, C_RED, 5, cv2.LINE_AA)
        cv2.putText(frame, f"Paused 2s - Final Count: {count}", (w//2-300, h//2+40),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.2, C_GREEN, 3, cv2.LINE_AA)
        return

    # Waiting for SPACE
    if not test_started:
        ov = frame.copy()
        cv2.rectangle(ov, (0,0), (w,h), (0,0,0), -1)
        cv2.addWeighted(ov, 0.5, frame, 0.5, 0, frame)
        # Three states, not two. The arm alone is enough to RUN the test, but a
        # green "ready" with the face out of shot promises a score the test
        # can't deliver: with no chin reading, no rep can be credited, and the
        # coach would find that out at the end.
        if not visible:
            ready_col, ready_txt = C_YELLOW, "Get one full arm in frame"
        elif gap is None:
            ready_col, ready_txt = C_YELLOW, "Arm ready - turn the face to the camera"
        else:
            ready_col, ready_txt = C_GREEN, "Body detected! "
        cv2.putText(frame, ready_txt, (w//2 - 300, h//2 - 50),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.0, ready_col, 2, cv2.LINE_AA)
        start_txt = ("Tap START to begin" if browser_mode
                     else "Press SPACE to start")
        cv2.putText(frame, start_txt,
                    (w//2 - 300, h//2 + 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.1, C_WHITE, 3, cv2.LINE_AA)
        cv2.putText(frame, start_txt,
                    (w//2 - 300, h//2 + 20),
                    cv2.FONT_HERSHEY_SIMPLEX, 1.1, C_GREEN, 2, cv2.LINE_AA)


# ──────────────────────────────────────────────
# POSE DRAWING (manual — no mp.solutions needed)
# ──────────────────────────────────────────────

CONNECTIONS = [
    (11,12),(11,13),(13,15),(12,14),(14,16),  # arms + shoulders
    (11,23),(12,24),(23,24),                   # torso
]

def draw_pose(frame, lms, w, h):
    for a, b in CONNECTIONS:
        if lms[a].visibility > 0.4 and lms[b].visibility > 0.4:
            p1 = (int(lms[a].x * w), int(lms[a].y * h))
            p2 = (int(lms[b].x * w), int(lms[b].y * h))
            cv2.line(frame, p1, p2, (0, 200, 255), 2, cv2.LINE_AA)
    for i in range(33):
        if lms[i].visibility > 0.4:
            cx = int(lms[i].x * w)
            cy = int(lms[i].y * h)
            cv2.circle(frame, (cx, cy), 4, C_GREEN, -1, cv2.LINE_AA)


# ──────────────────────────────────────────────
# MAIN
# ──────────────────────────────────────────────

def _autosave_pull_up(session_id, reps, duration_sec):
    """Stages the result on the server for human review/save on screen3 —
    does NOT write to the database directly.

    app.py serves on 8080; the older test scripts still post to 5000 and their
    staging has been silently failing. Override with GOFORFIT_URL if the server
    is somewhere else."""
    import os
    base = os.environ.get("GOFORFIT_URL", "http://localhost:8080").rstrip("/")
    try:
        import requests
        requests.post(
            f"{base}/api/stage/pull_up",
            json={"session_id": session_id, "reps": reps, "duration_sec": duration_sec},
            timeout=2,
        ).raise_for_status()
        print(f"  [DB] pull_up staged for review -> reps={reps}  session={session_id}")
    except Exception as e:
        print(f"  [DB] Stage failed: {e}")


def run(source):
    import urllib.request, os
    MODEL_PATH = "pose_landmarker_full.task"
    MODEL_URL  = (
        "https://storage.googleapis.com/mediapipe-models/"
        "pose_landmarker/pose_landmarker_full/float16/latest/"
        "pose_landmarker_full.task"
    )
    if not os.path.exists(MODEL_PATH):
        print("Downloading MediaPipe pose model (~10 MB)...")
        urllib.request.urlretrieve(MODEL_URL, MODEL_PATH)
        print("Model downloaded.")

    base_opts = mp_python.BaseOptions(model_asset_path=MODEL_PATH)
    opts = mp_vision.PoseLandmarkerOptions(
        base_options=base_opts,
        running_mode=mp_vision.RunningMode.VIDEO,
        num_poses=1,
        min_pose_detection_confidence=0.55,
        min_pose_presence_confidence=0.55,
        min_tracking_confidence=0.55,
        output_segmentation_masks=False,
    )
    landmarker = mp_vision.PoseLandmarker.create_from_options(opts)

    import sys as _sys, os as _os
    _session_id = None
    for _i, _a in enumerate(_sys.argv[1:], 1):
        if _a == "--session-id" and _i + 1 < len(_sys.argv):
            try: _session_id = int(_sys.argv[_i + 1])
            except ValueError: pass
    if _session_id is None:
        try: _session_id = int(_os.environ.get("SESSION_ID", ""))
        except (ValueError, TypeError): pass

    cap = cv2.VideoCapture(source)
    if not cap.isOpened():
        raise RuntimeError(f"Cannot open: {source}")

    fps = cap.get(cv2.CAP_PROP_FPS) or 30.0

    counter      = PullUpCounter()
    start_time   = None
    test_started = False
    rep_log      = []
    frame_idx    = 0

    WIN = "Modified Pull-Up Counter - GoForFit NEP FMS"
    cv2.namedWindow(WIN, cv2.WINDOW_NORMAL)
    cv2.setWindowProperty(WIN, cv2.WND_PROP_FULLSCREEN, cv2.WINDOW_FULLSCREEN)

    import tkinter as tk
    root = tk.Tk(); root.withdraw()
    SCREEN_W = root.winfo_screenwidth()
    SCREEN_H = root.winfo_screenheight()
    root.destroy()

    print("Press SPACE to start | R to reset | F to toggle fullscreen | Q to quit.")

    fullscreen = True

    while cap.isOpened():
        ret, frame = cap.read()
        if not ret:
            break

        frame = cv2.resize(frame, (SCREEN_W, SCREEN_H), interpolation=cv2.INTER_LINEAR)

        h, w = frame.shape[:2]
        frame_idx += 1
        timestamp_ms = int(frame_idx * 1000 / fps)

        rgb = cv2.cvtColor(frame, cv2.COLOR_BGR2RGB)
        mp_image = mp.Image(image_format=mp.ImageFormat.SRGB, data=rgb)
        result = landmarker.detect_for_video(mp_image, timestamp_ms)

        body_visible = False
        elapsed      = (time.time() - start_time) if test_started else 0.0

        if result.pose_landmarks:
            lms = result.pose_landmarks[0]

            (s_i, e_i, wr_i), near_vis = near_arm(lms)
            # The arm alone decides whether a frame is worth scoring. A frame
            # without a readable face still goes in, carrying chin=None: the
            # elbow angle and the shoulder lift keep flowing, so a blackout
            # costs at most the rep it lands on instead of tripping the blind-
            # gap rule and voiding the rep, the grip and the pause reference
            # along with it.
            face_ok = all(lms[IDX[k]].visibility > 0.5
                          for k in ("NOSE", "MOUTH_L", "MOUTH_R"))
            body_visible = near_vis > 0.5

            if body_visible:
                shoulder = lm_px(lms, s_i, w, h)
                elbow    = lm_px(lms, e_i, w, h)
                wrist    = lm_px(lms, wr_i, w, h)

                scored = counter.update(
                    calc_angle(shoulder, elbow, wrist),
                    chin_y(lms) if face_ok else None,
                    bar_y(lms, wr_i),
                    lms[s_i].y,
                    shoulder_lift(shoulder, elbow),
                    counting=test_started,
                )
                if scored:
                    rep_log.append({
                        "rep"         : counter.count,
                        "elbow_deg"   : round(counter.angle, 2),
                        "chin_gap_pct": (round(counter.gap * 100, 2)
                                         if counter.gap is not None else None),
                        "lift_arms"   : round(counter.lift_arms, 2),
                        "timestamp_s" : round(elapsed, 3),
                    })
                if counter.stopped:
                    print(f"Paused {PAUSE_SEC:.0f}s - test ended. Count: {counter.count}")

            draw_pose(frame, lms, w, h)

        draw_ui(frame, counter.count, counter.phase, counter.angle, elapsed,
                counter.gap, counter.reached, body_visible, test_started,
                stopped=counter.stopped, hung=counter.hung,
                lifted=counter.lifted)
        cv2.imshow(WIN, frame)

        key = cv2.waitKey(1) & 0xFF
        if key == ord('q'):
            break
        if key == ord(' ') and not test_started:
            start_time   = time.time()
            test_started = True
            print("Timer started!")
        if key == ord('f'):
            fullscreen = not fullscreen
            prop = cv2.WINDOW_FULLSCREEN if fullscreen else cv2.WINDOW_NORMAL
            cv2.setWindowProperty(WIN, cv2.WND_PROP_FULLSCREEN, prop)
        if key == ord('r'):
            counter.reset(); start_time = None
            test_started = False; rep_log = []

    final_elapsed = (time.time() - start_time) if (test_started and start_time) else 0.0
    if _session_id is not None and counter.count > 0:
        _autosave_pull_up(_session_id, counter.count, round(final_elapsed, 1))

    cap.release()
    cv2.destroyAllWindows()
    landmarker.close()

    if rep_log:
        df = pd.DataFrame(rep_log)
        print("\n-- Session Report ------------------------------------")
        print(df.to_string(index=False))
        print(f"\nTotal Reps : {counter.count}")
        df.to_csv("pull_up_session.csv", index=False)
        print("Log saved -> pull_up_session.csv")
    else:
        print("No reps recorded.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--camera", type=int,  default=0)
    parser.add_argument("--video",  type=str,  default=None)
    args = parser.parse_args()
    run(args.video if args.video else args.camera)
