Isometric Push-Up - changed files (from main, commits 3ee9e4f..56441c3)

Only used by this test:
  tests/isometric_pushup.py        main logic
  tests/test_isometric_pushup.py   camera-free checks (python3 tests/test_isometric_pushup.py)

Shared files (full current copies - they also contain the other tests):
  tests/web_engines.py             IsometricPushUpEngine
  app.py                           test entry, routes, launch, save
  db.py                            isometric_push_up table + save
  templates/screen4.html           live screen, RESET, beeps, website sync
  templates/screen3.html           result field (seconds, 0-40)

isometric_push_up.patch
  Only the Isometric Push-Up lines, as the 5 commits.
  Apply to another copy with: git am isometric_push_up.patch
