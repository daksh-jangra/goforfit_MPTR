Target Stretch Test - package contents

Exercise implementation:
  tests/target_stretch.py
Automated camera-free test:
  tests/test_target_stretch.py
  Run from the project root: python3 tests/test_target_stretch.py
Shared integration files: app.py, db.py, tests/web_engines.py,
templates/screen3.html, templates/screen4.html, templates/results.html.
MediaPipe model assets used by the exercise are included under tests/.

The test requires opencv-python, mediapipe>=0.10.21, and numpy.
The patch contains the Target Stretch feature and its follow-up changes.
