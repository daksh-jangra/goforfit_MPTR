"""
GoForFit NEP FMS — FastAPI Launcher  (with DB storage)
======================================================
Each test is an independent OpenCV/MediaPipe script that opens its own window.
This server acts as a launchpad: it starts them as subprocesses so they run
exactly as written (no code changes to the originals needed).

Converted from Flask to FastAPI. Behavior, routes, and JSON response shapes
are preserved 1:1 with the original app. The Jinja templates (index.html,
screen2.html, screen3.html, screen4.html, results.html) are used unmodified —
a small `url_for` compatibility shim below lets them keep using Flask-style
calls like `url_for('screen2', category='All Tests')`.

Usage:
    pip install -r requirements.txt
    python app.py
    Then open  http://localhost:5000  in your browser.

Interactive API docs (new, courtesy of FastAPI): http://localhost:5000/docs
"""

import os
# ── Force OpenCV into headless mode BEFORE cv2 is imported anywhere ────────
# Without this, OpenCV's Qt/GTK backend opens a blank window the moment
# VideoCapture is created, even when imshow() is never called.
os.environ.setdefault("DISPLAY", "")          # no X11 display → offscreen
os.environ["QT_QPA_PLATFORM"] = "offscreen"   # Qt backend → offscreen
os.environ["OPENCV_VIDEOIO_PRIORITY_MSMF"] = "0"  # skip Windows Media Foundation GUI

import subprocess
import sys
import csv
import io
import time
import asyncio
import re
import concurrent.futures
from pathlib import Path
import sqlite3
from typing import Any, Optional
from urllib.parse import urlencode

import cv2
import jinja2
from fastapi import FastAPI, Request, Query
from fastapi.responses import JSONResponse, RedirectResponse, StreamingResponse
from starlette.templating import Jinja2Templates
from pydantic import BaseModel

from db import db  # unchanged database module

app = FastAPI(title="GoForFit NEP FMS")

# ── Paths ──────────────────────────────────────────────────────────────────
BASE_DIR  = Path(__file__).parent
TESTS_DIR = BASE_DIR / "tests"
TEMPLATES_DIR = BASE_DIR / "templates"

# ── Wingspan: browser-controlled live feed (no desktop OpenCV window) ──────
# Every other test still opens its own OpenCV window via subprocess, as
# before. Wingspan is the one test that needed several distinct in-test
# actions (calibrate / measure / snapshot / save) which don't work from a
# phone with no keyboard, so it now runs in-process and streams MJPEG
# frames to <img> in screen4 instead, controlled by on-screen buttons.
sys.path.insert(0, str(TESTS_DIR))

# These hold the *actual* exception text when an engine module fails to
# import, so we can surface it to the browser instead of only ever
# printing it to a server console nobody is watching.
import traceback as _traceback

WEB_ENGINES_IMPORT_ERROR: Optional[str] = None
DUAL_FEED_IMPORT_ERROR: Optional[str] = None

try:
    from web_engines import (
        BmiEngine, CurlUpEngine, PullUpEngine, FullPullUpEngine, WallTossEngine,
        SitReachEngine, TrunkLiftEngine, ReverseCurlEngine,
        ShoulderStretchEngine, IsometricPushUpEngine,
        SeatedPushUpEngine, TargetStretchEngine, DumbbellPressEngine,
        PushUpEngine, ModifiedCurlUpEngine, BenchPressEngine,
        ModifiedApleyEngine, WheelchairRampEngine,
        WingspanEngine, VerticalJumpEngine,
    )
except Exception as _e:  # pragma: no cover — surfaced to the browser, see below
    BmiEngine = CurlUpEngine = PullUpEngine = FullPullUpEngine = None
    WallTossEngine = SitReachEngine = TrunkLiftEngine = None
    ReverseCurlEngine = None
    ShoulderStretchEngine = None
    IsometricPushUpEngine = None
    SeatedPushUpEngine = None
    TargetStretchEngine = None
    DumbbellPressEngine = None
    PushUpEngine = None
    ModifiedCurlUpEngine = None
    BenchPressEngine = None
    ModifiedApleyEngine = None
    WheelchairRampEngine = None
    WingspanEngine = VerticalJumpEngine = None
    WEB_ENGINES_IMPORT_ERROR = f"{_e.__class__.__name__}: {_e}"
    print("=" * 70)
    print("[FATAL] Live-feed camera engines failed to import — EVERY AI test")
    print("        (including wingspan) will be UNAVAILABLE in the browser")
    print("        until this is fixed. Root cause:")
    print("-" * 70)
    _traceback.print_exc()
    print("=" * 70)

try:
    from dual_feed_engines import ShuttleRunEngine, Dash50mEngine, Run600mEngine
except Exception as _e:  # pragma: no cover — surfaced to the browser, see below
    ShuttleRunEngine = Dash50mEngine = Run600mEngine = None
    DUAL_FEED_IMPORT_ERROR = f"{_e.__class__.__name__}: {_e}"
    print("=" * 70)
    print("[FATAL] Dual-camera engines failed to import — shuttle_run/dash_50m/")
    print("        run_600m will be UNAVAILABLE in the browser until fixed.")
    print("        Root cause:")
    print("-" * 70)
    _traceback.print_exc()
    print("=" * 70)

_wingspan_engine = None      
_vertical_jump_engine = None
_shuttle_engine = None
_dash50m_engine = None
_run600m_engine = None
_bmi_engine = None           
_curl_up_engine = None
_pull_up_engine = None
_full_pull_up_engine = None
_wall_toss_engine = None
_sit_reach_engine = None     
_trunk_lift_engine = None
_reverse_curl_engine = None
_shoulder_stretch_engine = None
_isometric_push_up_engine = None
_seated_push_up_engine = None
_target_stretch_engine = None
_dumbbell_press_engine = None
_push_up_engine = None
_modified_curl_up_engine = None
_bench_press_engine = None
_modified_apley_engine = None
_wheelchair_ramp_engine = None


# ── Jinja templates, with a Flask-style url_for shim ─────────────────────────
# Starlette's built-in `url_for` only understands *path* params (e.g. /x/{id}),
# not Flask-style "extra kwargs become a query string" calls such as
# `url_for('screen2', category='All Tests')`. The templates use that pattern
# extensively, so we replace the default `url_for` global with one that
# replicates Flask's behavior — this means the .html files don't need to change.

@jinja2.pass_context
def _flask_style_url_for(context, name: str, **params):
    request: Request = context["request"]
    route = None
    for r in request.app.routes:
        if getattr(r, "name", None) == name:
            route = r
            break
    if route is None:
        raise ValueError(f"No route named '{name}'")

    path_param_names = set(getattr(route, "param_convertors", {}).keys())
    path_params  = {k: v for k, v in params.items() if k in path_param_names}
    query_params = {k: v for k, v in params.items() if k not in path_param_names}

    path = request.url_for(name, **path_params).path
    if query_params:
        path = f"{path}?{urlencode(query_params)}"
    return path


_jinja_env = jinja2.Environment(
    loader=jinja2.FileSystemLoader(str(TEMPLATES_DIR)),
    autoescape=jinja2.select_autoescape(),
)
_jinja_env.globals["url_for"] = _flask_style_url_for  # setdefault() inside Jinja2Templates keeps this
templates = Jinja2Templates(env=_jinja_env)


async def _json_body(request: Request) -> dict:
    """Mirror Flask's `request.get_json(silent=True, force=True) or {}` — never raises."""
    try:
        body = await request.json()
        return body if isinstance(body, dict) else {}
    except Exception:
        return {}


# ── Test registry ──────────────────────────────────────────────────────────
# Target Stretch joints, in the order the AI screen's picker lists them.
# Keys must match target_stretch.JOINTS (form 5.1 / table 5.3).
TARGET_STRETCH_JOINTS = {
    "wrist_extension":            "Wrist extension",
    "elbow_extension":            "Elbow extension",
    "shoulder_extension":         "Shoulder extension",
    "shoulder_abduction":         "Shoulder abduction",
    "shoulder_external_rotation": "Shoulder external rotation",
    "forearm_supination":         "Forearm supination",
    "forearm_pronation":          "Forearm pronation",
    "knee_extension":             "Knee extension",
}

TESTS = {
    "bmi": {
        "id":          "bmi",
        "title":       "BMI / Height Estimator",
        "subtitle":    "MediaPipe pose-based height measurement + BMI calculation",
        "icon":        "📏",
        "category":    "Anthropometry",
        "script":      "bmi__3_.py",
        "description": [
            "Calibrate once with a person of known height.",
            "After that, anyone can be measured straight away.",
            "The app estimates height from the camera and shows it in cm.",
            "Enter the weight to get BMI as well.",
        ],
        "controls": [
            ("SPACE", "Start 5-second scan"),
            ("C",     "Calibrate with known-height person"),
            ("R",     "Reset calibration"),
            ("S",     "Save readings to CSV"),
            ("Q",     "Quit"),
        ],
        "tip":    [
            "Mount the camera level, pointing straight ahead.",
            "Stand with the whole body in frame.",
            "Calibrate once with a known height. No distance measurement is needed.",
        ],
        "params": [],
        "unit":   "cm",
        "live_feed":   True,
    },
    "wingspan": {
        "id":          "wingspan",
        "title":       "Wingspan Measurement",
        "subtitle":    "Middle-fingertip to middle-fingertip in real cm",
        "icon":        "🦅",
        "category":    "Anthropometry",
        "script":      "wingspan2.py",
        "description": [
            "Measures arm span from middle fingertip to middle fingertip, in cm.",
            "The first run downloads the model files by itself.",
            "Calibrate for the spot where the student will stand.",
            "Capture a 3-second snapshot. The app uses the middle reading from those 3 "
            "seconds.",
        ],
        "controls": [
            ("C",     "Enter calibration mode"),
            ("M",     "Switch to measure mode"),
            ("SPACE", "Take 3-second median snapshot"),
            ("S",     "Save result to CSV"),
            ("Q",     "Quit"),
        ],
        "tip":    [
            "Extend both arms fully, palms forward, fingers spread.",
            "Calibrate once with a known wingspan. No distance measurement is needed.",
            "Stand on the same spot used for calibration.",
        ],
        "params": [],
        "unit":   "cm",
        "live_feed":   True,
    },
    "curl_up": {
        "id":          "curl_up",
        "title":       "Partial Curl-Up Counter",
        "subtitle":    "Timed abdominal strength test: 30 seconds",
        "icon":        "🏋️",
        "category":    "Muscular Endurance",
        "script":      "parcurlup.py",
        "description": [
            "Counts partial curl-ups for 30 seconds.",
            "The app watches the hip angle and how far the shoulders rise.",
            "The screen shows a live rep count and a countdown timer.",
            "Results can be exported to a CSV file.",
        ],
        "controls": [
            ("SPACE", "Start 30-second timer"),
            ("R",     "Reset counter"),
            ("F",     "Toggle fullscreen"),
            ("Q",     "Quit"),
        ],
        "tip":    [
            "Lie flat with the knees bent about 90\u00b0.",
            "The camera should see the student from the side.",
        ],
        "params": [],
        "unit":   "reps",
        "live_feed":   True,
    },
    "pull_up": {
        "id":          "pull_up",
        "title":       "Modified Pull-Up",
        "subtitle":    "Shoulder strength and endurance: max reps, one trial",
        "icon":        "💪",
        "category":    "Muscular Endurance",
        "script":      "pullup.py",
        "description": [
            "Uses a pull-up stand.",
            "The student lies on their back under the bar and grips it with an overhand "
            "grip.",
            "On 'GO', the student pulls the body up by bending the arms until the chin "
            "reaches the level of the bar.",
            "The student lowers back down without the shoulders touching the ground.",
            "The hands are on the bar, so the wrists show the bar's height. The app checks "
            "chin-to-bar directly instead of estimating it.",
            "The test ends by itself once the student pauses for 2 seconds or more.",
        ],
        "controls": [
            ("SPACE", "Start counting (the 'GO' signal)"),
            ("R",     "Reset counter"),
            ("F",     "Toggle fullscreen"),
            ("Q",     "Quit"),
        ],
        "tip": [
            "Set the bar just within reach of the student lying on their back on the mat.",
            "Point the camera so the face and one whole arm, hand included, are in frame.",
            "Keep the knees straight and the back straight.",
            "A steady, even pace scores best.",
        ],
        "params": [],
        "unit":   "reps",
        "live_feed":   True,
    },
    "full_pull_up": {
        "id":          "full_pull_up",
        "title":       "Pull-Up",
        "subtitle":    "Upper-body strength and endurance: max reps, one trial",
        "icon":        "🏋️",
        "category":    "Muscular Endurance",
        "script":      "pullup_full.py",
        "description": [
            "The student hangs from the bar with an overhand grip, arms straight.",
            "They pull up until the chin is above the bar, then lower back to a full hang.",
            "A rep counts only when the chin clears the bar AND the shoulders come above "
            "the elbows.",
            "The arms must straighten again before the next pull.",
            "The chin is the protocol's rule. The shoulders are a second check, because "
            "the app has to estimate the chin from the face.",
            "The test ends by itself when the student drops off the bar.",
        ],
        "controls": [
            ("SPACE", "Start counting (the 'GO' signal)"),
            ("R",     "Reset counter"),
            ("F",     "Toggle fullscreen"),
            ("Q",     "Quit"),
        ],
        "tip": [
            "Place the camera a few metres away, roughly level with the bar.",
            "Keep the head, arms and bar all in frame.",
            "The student starts from a still, straight-arm hang.",
            "No swinging, kicking or bent knees.",
        ],
        "params": [],
        "unit":   "reps",
        "live_feed":   True,
    },
    "wall_toss": {
        "id":          "wall_toss",
        "title":       "Wall Toss Coordination Test",
        "subtitle":    "Alternate-hand ball toss: 30 seconds",
        "icon":        "🎯",
        "category":    "Coordination",
        "script":      "wtt.py",
        "description": [
            "The student tosses the ball at the wall and catches it, switching hands each "
            "time.",
            "The app tracks the ball and the hands and counts the catches.",
            "Only true alternating catches are counted.",
        ],
        "controls": [
            ("S",   "Start / restart test"),
            ("R",   "Reset to zero"),
            ("C",   "Click-to-calibrate ball colour"),
            ("1–5", "Switch ball colour preset"),
            ("Q",   "Quit"),
        ],
        "tip":    [
            "Use an orange ball.",
            "Stand about 1 m from the wall.",
            "Put the camera to the student's side.",
        ],
        "params": [],
        "unit":   "catches",
        "live_feed":   True,
    },
    "shuttle_run": {
        "id":          "shuttle_run",
        "title":       "10 m Shuttle Run Timer",
        "subtitle":    "Dual camera, whistle-triggered start: up to 4 lanes",
        "icon":        "🏃",
        "category":    "Agility",
        "script":      "shuttleruntest.py",
        "description": [
            "Times a 10 m shuttle run with two cameras, one at each end of the track, "
            "facing each other.",
            "Up to 4 students run at once, each in a fixed lane.",
            "A whistle starts every lane's timer at the same moment. The app listens for "
            "it through the microphone (2.4 to 4.1 kHz).",
            "The app tracks each student's ankles to see them touch the line at each end.",
            "Each student needs the set number of line touches to finish.",
            "Results are staged for review and also saved to a timestamped CSV file and a "
            "raw JSON event log.",
        ],
        "controls": [
            ("Click", "Calibrate: mark lane boundaries + touch line on each camera"),
            ("C",     "Confirm calibration step"),
            ("R",     "Reset calibration points"),
            ("SPACE", "Manual start (if no whistle detected)"),
            ("Q",     "Quit"),
        ],
        "tip": [
            "Set the two cameras 10 m apart, one at each end of the track, facing each "
            "other.",
            "Mark 4 lanes on the ground.",
            "The laptop or USB microphone must be able to hear the whistle.",
        ],
        "params": [
            {
                "name":        "cam_a_url",
                "label":       "Camera A URL/Index (End A — start line)",
                "type":        "text",
                "placeholder": "e.g. http://192.168.1.74:4747/video or 0",
                "arg":         "--cam-a",
                "camera":      True,
            },
            {
                "name":        "cam_b_url",
                "label":       "Camera B URL/Index (End B — 10 m end)",
                "type":        "text",
                "placeholder": "e.g. http://192.168.1.75:4747/video or 1",
                "arg":         "--cam-b",
                "camera":      True,
            },
            {
                "name":        "touches",
                "label":       "Line touches required to finish",
                "type":        "number",
                "min":         2,
                "max":         12,
                "placeholder": "e.g. 4",
                "arg":         "--touches",
            },
        ],
        "timed":  True,
        "live_feed": True,
    },
    "dash_50m": {
        "id":          "dash_50m",
        "title":       "50 m Dash Timer",
        "subtitle":    "Two-camera sprint timing with automatic finish detection",
        "icon":        "⚡",
        "category":    "Speed",
        "script":      "sprint_timer.py",
        "description": [
            "Times a 50 m sprint automatically with two cameras.",
            "The FINISH camera watches the finish line and detects exactly when each "
            "runner crosses it.",
            "The OVERHEAD camera tells which runner is in which lane.",
            "A whistle can start the timing.",
            "Several lanes are timed at the same time.",
            "Laps are logged to a CSV file.",
        ],
        "controls": [
            ("SPACE", "Arrows move/resize strip during calibration"),
            ("s+N",   "Arm lane N individually"),
            ("a",     "Toggle arm-all-on-whistle"),
            ("r",     "Reset all lanes"),
            ("Q",     "Quit"),
        ],
        "tip":    [
            "FINISH camera: perpendicular to the track, level with the finish line.",
            "OVERHEAD camera: up high, looking straight down.",
        ],
        "params": [
            {
                "name":        "finish_cam_url",
                "label":       "Finish camera URL (perpendicular)",
                "type":        "text",
                "placeholder": "e.g. http://192.168.1.5:4747/video",
                "arg":         "--finish-cam",
                "camera":      True,
            },
            {
                "name":        "overhead_cam_url",
                "label":       "Overhead camera URL (lane identity)",
                "type":        "text",
                "placeholder": "e.g. http://192.168.1.6:4747/video",
                "arg":         "--overhead-cam",
                "camera":      True,
            },
            {
                "name":        "lanes",
                "label":       "Number of lanes",
                "type":        "number",
                "min":         1,
                "max":         9,
                "placeholder": "e.g. 4",
                "arg":         "--lanes",
            },
            {
                "name":        "lane_width",
                "label":       "Lane width (metres)",
                "type":        "number",
                "min":         0.5,
                "max":         3,
                "placeholder": "e.g. 1.22",
                "arg":         "--lane-width",
            },
        ],
        "timed":  True,
        "live_feed": True,
    },
    "sit_reach": {
        "id":          "sit_reach",
        "title":       "Sit and Reach Test",
        "subtitle":    "Flexibility measurement via finger tracking",
        "icon":        "🤸",
        "category":    "Flexibility",
        "script":      "snr.py",
        "description": [
            "Measures how far forward the student reaches, in cm.",
            "Enter the student's hip-to-ankle length first. The app uses it to turn the "
            "reach into accurate cm.",
            "Press MARK when the student's arms are straight out in front, fingertips "
            "together. The reach is measured from there, so hands at the hips or on the "
            "floor give a score that is far too big.",
            "The student slides the hands forward along the legs. The app keeps the "
            "furthest forward reach during the attempt.",
            "Press MARK again to lock the result.",
        ],
        "controls": [
            ("SPACE", "Set start position / lock final result"),
            ("R",     "Reset for new trial"),
            ("Q",     "Quit and print summary"),
        ],
        "tip": [
            "Sit on the floor with the legs straight.",
            "Enter the hip-to-ankle length below before launching.",
        ],
        "params": [
            {
                "name":        "leg_cm",
                "label":       "Hip-to-ankle length (cm)",
                "type":        "number",
                "min":         20,
                "max":         130,
                "placeholder": "e.g. 87",
                "arg":         "--leg-cm",
            }
        ],
        "unit":   "cm",
        "live_feed":   True,
    },
    "trunk_lift": {
        "id":          "trunk_lift",
        "title":       "Trunk Lift",
        "subtitle":    "Chin-to-floor height, best of two trials",
        "icon":        "🧎",
        "category":    "Musculoskeletal",
        "script":      "trunk_lift.py",
        "description": [
            "Measures trunk extension.",
            "The student lies face down and lifts the upper body.",
            "The chin height above the mat is measured at the held peak.",
            "Before starting, tap both ends of the measuring stick on the video once. This "
            "sets the scale and the floor line.",
            "Two trials. The better one is kept.",
            "The score is capped at 12 in (30 cm).",
        ],
        "controls": [
            ("TAP x2", "Tap both ends of the measuring stick"),
            ("MARK",   "Capture the current height as a trial"),
            ("UNDO",   "Remove the last trial"),
            ("RESET",  "Start the trials over"),
        ],
        "tip": [
            "Camera on the floor, side-on, 1.5 to 2 m away, with the whole mat in frame.",
            "Lay the measuring stick on the mat in front of the chin, where the protocol "
            "already puts it.",
            "That way the stick is the same distance from the camera as the chin.",
        ],
        "params": [
            {
                "name":        "stick_cm",
                "label":       "Measuring stick length (cm)",
                "type":        "number",
                "min":         5,
                "max":         300,
                "placeholder": "e.g. 30",
                "arg":         "--stick-cm",
            }
        ],
        "unit":   "cm",
        "live_feed":   True,
    },
    "reverse_curl": {
        "id":          "reverse_curl",
        "title":       "Reverse Curl",
        "subtitle":    "Lift a 1 lb weight to 45\u00b0 and hold 2 s: pass/fail",
        "icon":        "\U0001f4aa",
        "category":    "Musculoskeletal",
        "script":      "reverse_curl.py",
        "description": [
            "Tests hand, wrist and arm strength.",
            "The student sits with the 1 lb (0.5 kg) dumbbell resting on the middle of the "
            "thigh.",
            "They bend the elbow to 45\u00b0 or less and hold it there for 2 seconds.",
            "Then they lower it back to the thigh under control.",
            "One trial. The camera decides: a correct curl is a PASS, a real attempt that "
            "falls short is a FAIL.",
            "Let the student practise before pressing Start.",
            "The coach still checks that the lowering is slower than gravity.",
        ],
        "controls": [
            ("RESET", "Start the trial over"),
        ],
        "tip": [
            "Camera side-on to the working arm, at seated shoulder height, 1.5 to 2 m "
            "away.",
            "Keep the shoulder, elbow, wrist and thigh all in frame.",
            "Don't film straight from the front. The elbow angle looks wrong from there, "
            "and good curls will read as short.",
        ],
        # No params and no arm buttons: the camera works out which arm is
        # curling by itself. (/api/launch/reverse_curl still accepts an "arm"
        # field for scripted launches.)
        "params": [],
        "unit":   "pass/fail",
        "live_feed":   True,
    },
    "shoulder_stretch": {
        "id":          "shoulder_stretch",
        "title":       "Shoulder Stretch",
        "subtitle":    "Touch the fingertips behind the back: both sides in 15 s, pass/fail",
        "icon":        "\U0001f932",
        "category":    "Musculoskeletal",
        "script":      "shoulder_stretch.py",
        # A list here shows as numbered steps on screen3 instead of a paragraph.
        "description": [
            "This tests upper-body flexibility of the shoulders. No equipment is needed.",
            "One arm reaches over the shoulder and down the back.",
            "The other arm reaches across and up the back.",
            "The student tries to touch the fingertips together between the shoulder blades.",
            "Do BOTH sides in ONE trial: right arm over the right shoulder, then left "
            "arm over the left.",
            "The trial lasts 15 seconds. The clock starts at the first real attempt, "
            "not when the camera opens.",
            "The student PASSES only if the fingers touch on BOTH sides.",
            "The app measures the gap between the fingertips, compared with the size "
            "of the hand. It works out which arm is on top and decides pass or fail.",
            "The coach checks that each reach is a genuine attempt.",
        ],
        "controls": [
            ("RESET", "Start the trial over (clears both sides and the 15 s clock)"),
        ],
        "tip": [
            "Put the camera BEHIND the student at upper-back height, 1.5 to 2 m away.",
            "Keep the upper back, both shoulders and BOTH HANDS in frame.",
            "This is the only test filmed from behind. From the front the hands "
            "can't be seen, so no trial will score.",
            "Only the student should be in frame when the test starts. The camera "
            "locks onto one person and won't start if it sees two.",
        ],
        # No pre-launch params and no side control: both sides are scored in
        # one trial and the arm is named per frame from the hands.
        "params": [],
        "unit":   "pass/fail",
        "live_feed":   True,
    },
    "isometric_push_up": {
        "id":          "isometric_push_up",
        "title":       "Isometric Push-Up",
        "subtitle":    "Hold the top of a push-up: seconds held, up to 40 s",
        "icon":        "\u23f1\ufe0f",
        "category":    "Muscular Endurance",
        "script":      "isometric_pushup.py",
        "description": [
            "Tests upper-body strength and endurance.",
            "The student holds the UP position of a push-up: hands directly below the "
            "shoulders, arms straight, body in a straight line, toes on the mat.",
            "The clock starts by itself once the camera sees that position held still.",
            "The clock stops the moment the elbows bend, the hips sag or pike, the knees "
            "bend or the body sways.",
            "It also stops at 40 seconds, the maximum.",
            "One trial. The score is the time held, to the nearest second.",
            "The coach may help place the body in position but must not hold it up.",
        ],
        "controls": [
            ("RESET", "Start the trial over (clears the clock)"),
        ],
        "tip": [
            "Camera on the floor or just above it, SIDE-ON to the student, 1.5 to 2 m "
            "away.",
            "Keep the whole body, from the hands to the toes, in frame.",
            "Only the student should be in frame.",
        ],
        "params": [],
        "unit":   "s",
        "live_feed":   True,
    },
    "seated_push_up": {
        "id":          "seated_push_up",
        "title":       "Seated Push-Up",
        "subtitle":    "Lift off the seat on straight arms: seconds held, up to 20 s",
        "icon":        "\u23f1\ufe0f",
        "category":    "Muscular Endurance",
        "script":      "seated_pushup.py",
        "description": [
            "Tests upper-body strength and endurance.",
            "The student sits with the hands on push-up blocks, on the armrests of a "
            "wheelchair or armchair, or on the wheels of a sport wheelchair.",
            "They push down until the body is off the seat with the elbows straight.",
            "The camera first learns where the hips sit.",
            "The clock starts by itself once the hips are lifted and steady.",
            "It stops when the hips come back down onto the seat or the elbows bend, or at "
            "20 seconds, the maximum.",
            "A student who can't fully straighten the arms is timed from their own best "
            "extension.",
            "One trial. The score is the time held, to the nearest second.",
            "The feet may touch the floor but must not help.",
        ],
        "controls": [
            ("RESET", "Start the trial over (clears the clock and the seat)"),
        ],
        "tip": [
            "Camera at seat height, in front of or beside the student, 1.5 to 2 m away.",
            "Keep the head, hips and hands in frame.",
            "The student sits still for a moment first so the camera can find the seat.",
            "Only the student should be in frame.",
        ],
        "params": [],
        "unit":   "s",
        "live_feed":   True,
    },
    "dumbbell_press": {
        "id":          "dumbbell_press",
        "title":       "Dumbbell Press",
        "subtitle":    "Press a 15 lb dumbbell overhead: max reps, up to 50",
        "icon":        "\U0001f3cb\ufe0f",
        "category":    "Muscular Endurance",
        "script":      "dumbbell_press.py",
        "description": [
            "Tests arm and shoulder strength and endurance.",
            "The student sits in a wheelchair or sturdy chair, holding a 15 lb (6.8 kg) "
            "dumbbell at the shoulder in the dominant hand.",
            "They press it straight up until the elbow is straight, then bring it back to "
            "the shoulder.",
            "Keep a steady pace of 3 to 4 seconds per rep.",
            "A rep counts when the hand is pressed well above the head (1.3 upper-arm "
            "lengths above the shoulder, a nearly straight arm).",
            "The weight must come back down to the shoulder before the next rep counts.",
            "Tap START on 'GO'.",
            "The test ends by itself at 50 reps, or after a 4-second rest. A slow press "
            "still going up, or a slow lowering still coming down, is not a rest.",
            "If no rep counts within 15 seconds of START, the test ends with a score of 0.",
            "One trial. The score is the number of reps.",
        ],
        "controls": [
            ("ARM",   "Auto (the first arm to press), or pin the student's left / right hand"),
            ("START", "Start counting (the 'GO' signal)"),
            ("RESET", "Start the trial over (clears the count)"),
        ],
        "tip": [
            "If the student might lift the free hand first, pick their pressing hand "
            "before START.",
            "Camera FRONT-ON at chest height, 2 to 3 m away, with the student facing it "
            "squarely.",
            "Keep the head, both arms and plenty of room above the head in frame, for the "
            "weight overhead.",
            "The screen warns if the chair is turned or there isn't enough room.",
            "The spotter stands BEHIND the chair, not between the camera and the student, "
            "or the camera loses the student.",
        ],
        "params": [],
        "unit":   "reps",
        "live_feed":   True,
    },
    "push_up": {
        "id":          "push_up",
        "title":       "Push-Up",
        "subtitle":    "Push-ups on the toes, one every 3 s: as many as possible",
        "icon":        "\U0001f4aa",
        "category":    "Muscular Endurance",
        "script":      "push_up.py",
        "description": [
            "Tests upper-body strength and endurance.",
            "The student lies face down on a mat, hands under the shoulders, legs "
            "straight and slightly apart, weight on the tucked toes.",
            "They push up until the arms are straight. This is the starting position.",
            "They lower the body until the elbows are bent to 90\u00b0, then push back "
            "up to straight arms. That is one push-up.",
            "Keep a pace of about one push-up every 3 seconds. The screen beeps the pace.",
            "START only works once the camera sees the toes. Tap START on 'GO'.",
            "A push-up is NOT counted if the knees touch the floor, the arms don't "
            "straighten at the top, the elbows don't reach 90\u00b0, the back isn't "
            "kept reasonably straight, or the toes are out of view. The screen says why.",
            "The test ends by itself after 6 seconds with no push-up (two beats), or when "
            "the coach taps STOP.",
            "One trial. The score is the number of correct push-ups.",
            "Jerky or one-sided push-ups are the coach's call: correct the count on the "
            "results screen.",
        ],
        "controls": [
            ("START", "Start counting (the 'GO' signal) and the 3 s beep"),
            ("RESET", "Start the trial over (clears the count)"),
        ],
        "tip": [
            "Camera on the floor or just above it, SIDE-ON to the student, 1.5 to 2.5 m "
            "away.",
            "Keep the whole body, from the hands to the toes, in frame. The toes must be "
            "seen: they show whether the knees are down.",
            "Turn the phone's sound up for the beep.",
            "If the screen says the camera is too slow or dropping frames, close other "
            "apps or move closer to the Wi-Fi.",
            "Only the student should be in frame.",
        ],
        "params": [],
        "unit":   "reps",
        "live_feed":   True,
    },
    "modified_curl_up": {
        "id":          "modified_curl_up",
        "title":       "Modified Curl-Up",
        "subtitle":    "Hands slide up the thighs to the knees, one every 3 s, up to 75",
        "icon":        "\U0001f9d8",
        "category":    "Muscular Endurance",
        "script":      "modified_curl_up.py",
        "description": [
            "Tests abdominal strength and endurance.",
            "The student lies on their back on a mat, knees bent about 140\u00b0, feet flat on "
            "the floor, hands on the front of the thighs.",
            "They curl up slowly, sliding the hands up the thighs until the fingertips "
            "touch the kneecaps, then lie back down.",
            "Keep a pace of about one curl-up every 3 seconds. The screen beeps the pace.",
            "A curl-up counts when the student is back down on the mat.",
            "It does NOT count if the fingertips don't reach the knees, the student "
            "doesn't lie back down, or the feet leave the floor. The screen says why.",
            "The tester may hold their hands on the kneecaps as a target.",
            "Tap START on 'GO'.",
            "The test ends by itself at 75 curl-ups, or after 6 seconds (two beats) with "
            "no curl-up, or when the coach taps STOP.",
            "One trial. The score is the number of correct curl-ups.",
        ],
        "controls": [
            ("START", "Start counting (the 'GO' signal) and the 3 s beep"),
            ("RESET", "Start the trial over (clears the count)"),
        ],
        "tip": [
            "Camera on the floor or just above it, SIDE-ON to the student, about 1.5 to 2 "
            "m away.",
            "Keep the whole body, from the head to the FEET, in frame, with the student "
            "filling most of the picture's width. The screen says if the camera is too far "
            "back.",
            "The feet matter: the camera checks they stay on the floor.",
            "Let the student lie still for a second before START so the camera learns "
            "where the hands rest.",
            "A tester holding the kneecaps kneels on the far side, behind the legs, not "
            "between the camera and the student.",
            "Turn the phone's sound up for the beep.",
        ],
        "params": [],
        "unit":   "reps",
        "live_feed":   True,
    },
    "bench_press": {
        "id":          "bench_press",
        "title":       "Bench Press",
        "subtitle":    "Press a 35 lb bar from the chest to straight arms: up to 50 boys, 30 girls",
        "icon":        "\U0001f3cb\ufe0f",
        "category":    "Muscular Endurance",
        "script":      "bench_press.py",
        "description": [
            "Tests upper-body strength and endurance, mainly straightening the elbows.",
            "The student lies on their back on a bench, knees bent, feet on the floor or "
            "on mats beside the bench. A student who can't lie like this keeps the knees "
            "bent with the legs supported.",
            "They hold a 35 lb (15.9 kg) barbell, hands about 1.5 times shoulder width "
            "apart, thumbs wrapped around the bar.",
            "Keep the elbows tucked in, about 45\u00b0 from the body, not flared straight "
            "out to the sides. From the side, flared elbows can make a bent arm look "
            "straight to the camera.",
            "Start position: the bar at the chest, elbows bent.",
            "Pick Boy or Girl, then tap START on 'GO'.",
            "They press the bar straight up until the arms are straight, then lower it to "
            "touch the chest. Keep a steady pace of 3 to 4 seconds per rep, without "
            "resting.",
            "A rep counts when the bar has come down to the chest and the arms then "
            "straighten at the top: elbow 155\u00b0 or more, with the hands pushed all "
            "the way up above the shoulders.",
            "A press that doesn't straighten the arms, or a lowering that doesn't reach "
            "the chest, is NOT counted. The screen says why.",
            "The test ends by itself at 50 reps for a boy or 30 for a girl, or after a "
            "4-second rest. A slow press still going up, or a slow lowering still coming "
            "down, is not a rest.",
            "If no rep counts within 15 seconds of START, the test ends with a score of 0.",
            "One trial. The score is the number of correct reps.",
            "The camera checks the arm nearest it. The far arm is the coach's call: "
            "correct the count on the results screen.",
        ],
        "controls": [
            ("BOY / GIRL", "Sets the finish: 50 reps for a boy, 30 for a girl. Pick before START"),
            ("START", "Start counting (the 'GO' signal)"),
            ("RESET", "Start the trial over (clears the count)"),
        ],
        "tip": [
            "Camera SIDE-ON to the bench, at about bench height, 2 to 3 m away.",
            "Keep the head, the arm nearest the camera, the bar at the top and the hips "
            "in frame.",
            "Spotters stand on the FAR side of the bench, beside the rib cage, not between "
            "the camera and the student.",
            "If the screen draws the skeleton on a spotter instead of the student, ask the "
            "spotter to step back or crouch lower.",
        ],
        "params": [],
        "unit":   "reps",
        "live_feed":   True,
    },
    "target_stretch": {
        "id":          "target_stretch",
        "title":       "Target Stretch",
        "subtitle":    "How far one joint moves: left and right, scored 0 to 2",
        "icon":        "\U0001f9d8",
        "category":    "Musculoskeletal",
        "script":      "target_stretch.py",
        "description": [
            "Tests the range of motion at one joint.",
            "Pick the joint before pressing START: wrist extension, elbow extension, "
            "shoulder extension, shoulder abduction, shoulder external rotation, forearm "
            "supination, forearm pronation or knee extension.",
            "The student moves as far as they can and holds the end position for at least "
            "1 second.",
            "The camera reads the angle to the nearest 15\u00b0 and scores it 0, 1 or 2.",
            "The LEFT side is measured first, then the RIGHT.",
            "Each side gets 10 seconds, starting when the camera first sees the joint held "
            "steady.",
            "The coach demonstrates the full movement and helps the student find their "
            "best position. The camera decides the score.",
        ],
        "controls": [
            ("NEXT",  "End the side under way now (keeps its best hold)"),
            ("RESET", "Start the run over (both sides)"),
        ],
        "tip": [
            "Shoulder abduction, supination and pronation: camera IN FRONT, with the "
            "student FACING it, not their back.",
            "The PDF drawing for shoulder abduction shows the back. Don't copy it, or the "
            "app will measure the wrong arm.",
            "Every other joint: camera SIDE-ON with the tested side toward it. The student "
            "turns around for the second side.",
            "Place the camera 1.5 to 2 m away, at the height of the joint.",
            "Keep the whole limb in frame (and the hip, for the shoulder), and the HEAD "
            "too. The app uses the face to tell which way the student is facing.",
            "Knee: the student stands, or sits if they can't stand.",
            "Shoulder extension: no chair back behind the arm.",
            "Only the student should be in frame.",
        ],
        # The joint is picked on the AI screen, not here: the dashboard opens
        # that screen directly.
        "joints": TARGET_STRETCH_JOINTS,
        "params": [],
        "unit":   "score",
        "live_feed":   True,
    },
    "modified_thomas": {
        "id":          "modified_thomas",
        "title":       "Modified Thomas Test",
        "subtitle":    "Hip flexor length: left and right, scored 0 to 3 by the coach",
        "icon":        "\U0001f9b5",
        "category":    "Musculoskeletal",
        # No camera: the pose model can't find the thigh lying on the table
        # (it puts both legs on the knee pulled to the chest), and 3 vs 2 is
        # "touching" vs "about 1 cm up", finer than it can read. The coach
        # checks with the file cards and enters both scores.
        "script":      None,
        "description": [
            "Tests how tight the muscles at the front of the hip are. There is no camera: "
            "the coach checks the leg and enters the score.",
            "Put a strip of tape on the table 28 cm (11 in) from one short end.",
            "The student lies on their back with the hip joint level with the tape and "
            "the lower legs hanging off the end of the table.",
            "To test the RIGHT hip, the student pulls the LEFT knee to the chest with both "
            "hands until the lower back is flat on the table. The coach may help.",
            "Check the back is flat: a hand slid under the lower back should not fit.",
            "Look at the RIGHT thigh at the table edge and score it:",
            "3 - the thigh stays touching the table.",
            "2 - the thigh lifts, but the 7.6 cm side of the small card won't slide under it.",
            "1 - the 7.6 cm side slides under, but the 15.2 cm side of the large card doesn't.",
            "0 - the 15.2 cm side slides under.",
            "Then pull the RIGHT knee in and score the LEFT thigh the same way. One trial "
            "per leg.",
            "If the back won't go flat even with help, score it anyway.",
            "Both scores are saved. The website gets the lower of the two.",
        ],
        "controls": [],
        "tip": [
            "A sturdy table with the tape mark 28 cm from one short end.",
            "Two file cards: 3 x 5 in (the 7.6 cm side) and 4 x 6 in (the 15.2 cm side).",
            "Or a ruler: measure straight up from the table edge to the back of the thigh.",
            "Warm up the hips before testing.",
            "A leg that can't be tested can be marked Not tested.",
        ],
        "params": [],
        "unit":   "score",
        "live_feed":   False,
        "manual_entry": True,
    },
    "modified_apley": {
        "id":          "modified_apley",
        "title":       "Modified Apley Test",
        "subtitle":    "Upper-body flexibility: left and right arm, scored 0 to 3",
        "icon":        "\U0001f646",
        "category":    "Musculoskeletal",
        "script":      "modified_apley.py",
        "description": [
            "Tests how far each arm can reach behind the head.",
            "The student stands or sits with their BACK to the camera.",
            "LEFT arm first: reach back behind the head and touch the top inner corner "
            "of the RIGHT shoulder blade. Hold it for 1 to 2 seconds.",
            "If they can't, touch the top of the head and hold. If they can't do that, "
            "turn to face the camera and touch the mouth and hold.",
            "Score: 3 - shoulder blade, 2 - top of the head, 1 - mouth, 0 - can't reach "
            "the mouth. Every touch must be held for 1 second.",
            "The arm ends by itself on a 3. Otherwise press NEXT once the student has "
            "tried.",
            "Then the RIGHT arm, to the LEFT shoulder blade, the same way.",
            "The camera decides the score. Both arms are saved; the website gets the lower "
            "of the two.",
        ],
        "controls": [
            ("NEXT",  "End the arm under way now (keeps its best hold)"),
            ("RESET", "Start the run over (both arms)"),
        ],
        "tip": [
            "Camera BEHIND the student, at shoulder height, 1.5 to 2 m away. Use the "
            "back camera.",
            "Keep the head, both shoulders and the upper back in frame.",
            "Only the student should be in frame. Don't hold your fingertips on the "
            "shoulder blade as a target: a second hand confuses the camera.",
            "Practice first. Help is allowed in practice, not during the test.",
            "Warm up with some shoulder stretches before testing.",
            "In a wheelchair, the chair back must not hide the shoulder blades.",
        ],
        "params": [],
        "unit":   "score",
        "live_feed":   True,
    },
    "wheelchair_ramp": {
        "id":          "wheelchair_ramp",
        "title":       "Wheelchair Ramp Test",
        "subtitle":    "Push up a ramp: past the 8 ft or 15 ft line, scored 0 to 2",
        "icon":        "\u267f",
        "category":    "Muscular Endurance",
        "script":      "wheelchair_ramp.py",
        "description": [
            "Tests upper-body strength and endurance. The student pushes their wheelchair "
            "up a ramp, any way they like.",
            "The ramp rises 1 in 12 (2.5 cm up for every 30 cm along) and is at least "
            "8 ft (2.4 m) long.",
            "Mark lines across the ramp with tape: 8 ft (2.4 m) and 15 ft (4.6 m) from where "
            "the slope starts.",
            "Put the phone on a stand SIDE-ON to the ramp, then tap three points on the "
            "video: where the slope STARTS, the 8 ft line, then the 15 ft line. On a ramp "
            "shorter than 15 ft, tap only the first two.",
            "The student starts with the front wheels off the ramp. Tap START.",
            "The student pushes up as far as they can. A line counts when the BACK of the "
            "rear wheel is past it.",
            "Score: 2 - past the 15 ft line, 1 - past the 8 ft line, 0 - not past the "
            "8 ft line.",
            "Not timed, and the student can have more than one try: they can roll back "
            "down and go again. The best line counts.",
            "The test ends by itself at the last line. Otherwise tap STOP / SAVE when the "
            "student has finished.",
            "The camera decides the score.",
        ],
        "controls": [
            ("CLEAR LINES", "Tap the three lines again"),
            ("START",       "Start the test (the lines must be tapped first)"),
            ("RESET",       "Start the test over (the lines stay)"),
        ],
        "tip": [
            "Phone on a stand, side-on to the ramp, square to it, at about seat height, "
            "4 to 5 m away. Use the back camera.",
            "Keep a chair's length of floor before the start of the slope, and some ramp "
            "past the 15 ft line, in the picture.",
            "Tap each line where the near rear wheel will cross it.",
            "Don't move the phone after tapping the lines. If it moves, tap CLEAR LINES "
            "and tap them again.",
            "The spotter walks behind the chair on the FAR side, so the rear wheel nearest "
            "the camera stays in view.",
            "Make sure the chair can't roll off the side of the ramp.",
        ],
        "params": [],
        "unit":   "score",
        "live_feed":   True,
    },
    "vertical_jump": {
        "id":          "vertical_jump",
        "title":       "Vertical Jump Test",
        "subtitle":    "Standing reach + max jump height: 5 attempts",
        "icon":        "🐰",
        "category":    "Power",
        "script":      "vertical_jump.py",
        "description": [
            "Capture the student's standing reach.",
            "Calibrate it in cm.",
            "The student takes 5 jump attempts.",
            "The app tracks the reach height and reports the best jump, the average jump "
            "and each attempt's result.",
        ],
        "controls": [
            ("S",     "Capture standing reach baseline"),
            ("C",     "Enter standing reach in cm (calibrate)"),
            ("SPACE", "Start a jump attempt"),
            ("R",     "Reset calibration"),
            ("ESC",   "Exit"),
        ],
        "tip":    [
            "Stand side-on to the camera with the reaching arm fully visible.",
        ],
        "params": [],
        "unit":   "cm",
        "live_feed":   True,
    },
    "run_600m": {
        "id":          "run_600m",
        "title":       "600 m Run",
        "subtitle":    "Multi-lane endurance run: coloured T-shirt tracking, up to 5 lanes",
        "icon":        "🏃‍♂️",
        "category":    "Endurance",
        "script":      "600m_new/main.py",
        "description": [
            "Tracks up to 5 runners at once by the colour of their T-shirts.",
            "A virtual finish line in the camera picture counts each valid crossing in the "
            "right direction as one lap.",
            "A runner lingering on the line isn't counted twice.",
            "Each lane's timer runs for the whole test.",
            "The coach stops the test once every runner has covered 600 m.",
        ],
        "controls": [
            ("Click", "On the setup screen: pick 5 lane colours + enter camera distance"),
            ("SPACE", "Start / Stop / Restart the test"),
            ("ESC",   "Quit"),
        ],
        "tip": [
            "Give each runner a different T-shirt colour on the setup screen before the "
            "run starts.",
            "Position the camera so the finish line is clearly in frame.",
        ],
        "params": [
            {
                "name":        "camera_url",
                "label":       "Camera URL/Index",
                "type":        "text",
                "placeholder": "e.g. http://192.168.1.74:4747/video or 0",
                "arg":         "--camera-url",
                "camera":      True,
            },
            {
                "name":        "lane_colors",
                "label":       "Lane colours (comma-separated, e.g. Red,Blue,Green,Yellow,Orange)",
                "type":        "text",
                "placeholder": "Red,Blue,Green,Yellow,Orange",
                "arg":         "--lane-colors",
            },
            {
                "name":        "camera_distance_m",
                "label":       "Camera distance from track (m)",
                "type":        "number",
                "min":         0,
                "max":         50,
                "placeholder": "e.g. 5",
                "arg":         "--camera-distance-m",
            },
        ],
        "timed":  True,
        "unit":   "s",
        "live_feed":   True,
    },
}

# ── Track running processes ────────────────────────────────────────────────
_running: dict[str, subprocess.Popen] = {}

# ── Auto-stop for a test nobody has open ───────────────────────────────────
# screen4 polls /api/<test>/state every 0.6 s while a test is open. A window
# closed without STOP and never reopened leaves its engine running (the next
# START stops it - see launch()), holding its pose model until the server
# restarts. So a test whose page hasn't been heard from for IDLE_STOP_S is
# stopped, the same as pressing STOP. Generous on purpose: a phone browser
# slows the polling of a tab in the background to about once a minute, and a
# test someone is still running must never be cut off.
IDLE_STOP_S = 300
IDLE_CHECK_S = 30
_last_seen: dict[str, float] = {}   # test_id -> time.monotonic() of its last request
_ENGINE_PATH = re.compile(r"^/api/([a-z0-9_]+)/(state|frame|feed|action)$")


@app.middleware("http")
async def _note_test_page(request: Request, call_next):
    m = _ENGINE_PATH.match(request.url.path)
    if m:
        _last_seen[m.group(1)] = time.monotonic()
    return await call_next(request)


def _stop_idle_engines(now: Optional[float] = None) -> list[str]:
    """Stop every in-app engine whose page has gone quiet. Returns their ids."""
    now = time.monotonic() if now is None else now
    stopped = []
    for test_id, seen in list(_last_seen.items()):
        if now - seen < IDLE_STOP_S or test_id in _running:
            continue   # still open, or a desktop-window script the coach closes
        try:
            if _is_running(test_id):
                print(f"[idle] {test_id}: no page open for {IDLE_STOP_S}s - stopping it")
                # Keep a result that was already waiting (a test that ended by
                # itself), but not a half-finished one only this stop made:
                # nobody saw that trial, so it isn't a score.
                had_result = test_id in _pending
                stop(test_id)
                if not had_result:
                    _pending.pop(test_id, None)
                stopped.append(test_id)
        except Exception as exc:
            print(f"[idle] {test_id}: could not stop it: {exc}")
    return stopped


@app.on_event("startup")
async def _start_idle_watch():
    # On the event loop, like launch(): a check and its stop can't interleave
    # with a START replacing the engine, so a fresh run is never the one cut.
    async def watch():
        while True:
            await asyncio.sleep(IDLE_CHECK_S)
            _stop_idle_engines()
    asyncio.create_task(watch())


def _is_running(test_id: str) -> bool:
    if test_id == "wingspan" and _wingspan_engine is not None:
        return _wingspan_engine.is_running()
    if test_id == "vertical_jump" and _vertical_jump_engine is not None:
        return _vertical_jump_engine.is_running()
    if test_id == "bmi" and _bmi_engine is not None:
        return _bmi_engine.is_running()
    if test_id == "curl_up" and _curl_up_engine is not None:
        return _curl_up_engine.is_running()
    if test_id == "pull_up" and _pull_up_engine is not None:
        return _pull_up_engine.is_running()
    if test_id == "full_pull_up" and _full_pull_up_engine is not None:
        return _full_pull_up_engine.is_running()
    if test_id == "wall_toss" and _wall_toss_engine is not None:
        return _wall_toss_engine.is_running()
    if test_id == "sit_reach" and _sit_reach_engine is not None:
        return _sit_reach_engine.is_running()
    if test_id == "trunk_lift" and _trunk_lift_engine is not None:
        return _trunk_lift_engine.is_running()
    if test_id == "reverse_curl" and _reverse_curl_engine is not None:
        return _reverse_curl_engine.is_running()
    if test_id == "shoulder_stretch" and _shoulder_stretch_engine is not None:
        return _shoulder_stretch_engine.is_running()
    if test_id == "isometric_push_up" and _isometric_push_up_engine is not None:
        return _isometric_push_up_engine.is_running()
    if test_id == "seated_push_up" and _seated_push_up_engine is not None:
        return _seated_push_up_engine.is_running()
    if test_id == "target_stretch" and _target_stretch_engine is not None:
        return _target_stretch_engine.is_running()
    if test_id == "dumbbell_press" and _dumbbell_press_engine is not None:
        return _dumbbell_press_engine.is_running()
    if test_id == "push_up" and _push_up_engine is not None:
        return _push_up_engine.is_running()
    if test_id == "modified_curl_up" and _modified_curl_up_engine is not None:
        return _modified_curl_up_engine.is_running()
    if test_id == "bench_press" and _bench_press_engine is not None:
        return _bench_press_engine.is_running()
    if test_id == "modified_apley" and _modified_apley_engine is not None:
        return _modified_apley_engine.is_running()
    if test_id == "wheelchair_ramp" and _wheelchair_ramp_engine is not None:
        return _wheelchair_ramp_engine.is_running()
    if test_id == "shuttle_run" and _shuttle_engine is not None:
        return _shuttle_engine.is_running()
    if test_id == "dash_50m" and _dash50m_engine is not None:
        return _dash50m_engine.is_running()
    if test_id == "run_600m" and _run600m_engine is not None:
        return _run600m_engine.is_running()
    proc = _running.get(test_id)
    if proc is None:
        return False
    if proc.poll() is not None:
        del _running[test_id]
        return False
    return True

# ── Pending (staged-but-not-saved) AI results ──────────────────────────────
# AI test scripts no longer write straight to the DB. They POST their raw
# result here instead, where it sits until a human reviews it on screen3 and
# explicitly clicks "Save". Keyed by test_id, since each test's screen4/screen3
# is single-session-at-a-time in this app's UI.
_pending: dict[str, dict] = {}


# ── Pydantic models for the /api/save/* and /api/session bodies ─────────────
# Fields are optional (mirroring the original's lenient request.get_json()),
# and we manually enforce "session_id required" to keep the exact same
# {"ok": False, "error": ...} + 400 response shape the originals returned.

class SessionCreate(BaseModel):
    student_name: Optional[str] = None
    age: Optional[int] = None
    gender: Optional[str] = None
    school: Optional[str] = None
    grade: Optional[str] = None
    notes: Optional[str] = None


class BMISave(BaseModel):
    session_id: Optional[int] = None
    height_cm: Optional[float] = None
    weight_kg: Optional[float] = None
    calibration_used: Optional[bool] = False


class WingspanSave(BaseModel):
    session_id: Optional[int] = None
    wingspan_cm: Optional[float] = None
    height_cm: Optional[float] = None
    calibration_distance_cm: Optional[float] = None


class CurlUpSave(BaseModel):
    session_id: Optional[int] = None
    reps: Optional[int] = None
    duration_sec: Optional[int] = 30
    rating: Optional[str] = None


class PullUpSave(BaseModel):
    session_id: Optional[int] = None
    reps: Optional[int] = None
    duration_sec: Optional[float] = None
    rating: Optional[str] = None


class FullPullUpSave(BaseModel):
    session_id: Optional[int] = None
    reps: Optional[int] = None
    duration_sec: Optional[float] = None
    rating: Optional[str] = None


class WallTossSave(BaseModel):
    session_id: Optional[int] = None
    catches: Optional[int] = None
    duration_sec: Optional[int] = 30
    ball_colour: Optional[str] = None
    rating: Optional[str] = None


class ShuttleRunSave(BaseModel):
    session_id: Optional[int] = None
    time_sec: Optional[float] = None
    lane: Optional[int] = 1
    rating: Optional[str] = None


class Dash50mSave(BaseModel):
    session_id: Optional[int] = None
    time_sec: Optional[float] = None
    lane: Optional[int] = 1
    start_mode: Optional[str] = "whistle"
    rating: Optional[str] = None


class SitReachSave(BaseModel):
    session_id: Optional[int] = None
    reach_cm: Optional[float] = None
    leg_cm: Optional[float] = None
    rating: Optional[str] = None

class TrunkLiftSave(BaseModel):
    session_id: Optional[int] = None
    lift_cm: Optional[float] = None
    trial1_cm: Optional[float] = None
    trial2_cm: Optional[float] = None
    stick_cm: Optional[float] = None
    rating: Optional[str] = None

class ReverseCurlSave(BaseModel):
    session_id: Optional[int] = None
    passed: Optional[bool] = None
    arm: Optional[str] = None
    peak_angle_deg: Optional[float] = None
    hold_s: Optional[float] = None
    rating: Optional[str] = None

class ShoulderStretchSave(BaseModel):
    session_id: Optional[int] = None
    passed: Optional[bool] = None          # both sides touched
    left_passed: Optional[bool] = None
    right_passed: Optional[bool] = None
    best_gap_ratio: Optional[float] = None
    best_gap_left: Optional[float] = None
    best_gap_right: Optional[float] = None
    rating: Optional[str] = None

class IsometricPushUpSave(BaseModel):
    session_id: Optional[int] = None
    hold_sec: Optional[float] = None       # the score: seconds held, 0-40
    held_exact_s: Optional[float] = None
    end_reason: Optional[str] = None
    rating: Optional[str] = None

class SeatedPushUpSave(BaseModel):
    session_id: Optional[int] = None
    hold_sec: Optional[float] = None       # the score: seconds held, 0-20
    held_exact_s: Optional[float] = None
    end_reason: Optional[str] = None
    rating: Optional[str] = None

class TargetStretchSave(BaseModel):
    session_id: Optional[int] = None
    joint: Optional[str] = None
    left_deg: Optional[float] = None       # clock degrees, nearest 15
    left_score: Optional[int] = None       # 0-2, table 5.3
    left_exact: Optional[float] = None
    right_deg: Optional[float] = None
    right_score: Optional[int] = None
    right_exact: Optional[float] = None
    rating: Optional[str] = None

class DumbbellPressSave(BaseModel):
    session_id: Optional[int] = None
    reps: Optional[int] = None             # the score: 0-50
    arm: Optional[str] = None
    duration_sec: Optional[float] = None
    end_reason: Optional[str] = None
    rating: Optional[str] = None

class PushUpSave(BaseModel):
    session_id: Optional[int] = None
    reps: Optional[int] = None             # the score: correct push-ups
    duration_sec: Optional[float] = None
    end_reason: Optional[str] = None
    rating: Optional[str] = None

class ModifiedCurlUpSave(BaseModel):
    session_id: Optional[int] = None
    reps: Optional[int] = None             # the score: correct curl-ups, 0-75
    duration_sec: Optional[float] = None
    end_reason: Optional[str] = None
    rating: Optional[str] = None

class BenchPressSave(BaseModel):
    session_id: Optional[int] = None
    reps: Optional[int] = None             # the score: 0-50 (boys) / 0-30 (girls)
    sex: Optional[str] = None              # "boy" / "girl" - which finish applied
    duration_sec: Optional[float] = None
    end_reason: Optional[str] = None
    rating: Optional[str] = None

class ModifiedThomasSave(BaseModel):
    session_id: Optional[int] = None
    left_score: Optional[int] = None       # 0-3, None = leg not tested
    right_score: Optional[int] = None

class ModifiedApleySave(BaseModel):
    session_id: Optional[int] = None
    left_score: Optional[int] = None       # 0-3, None = arm not tested
    right_score: Optional[int] = None

class WheelchairRampSave(BaseModel):
    session_id: Optional[int] = None
    score: Optional[int] = None            # 0-2: furthest line the rear wheels passed
    reached_m: Optional[float] = None      # how far up the back of the wheel got

class VerticalJumpSave(BaseModel):
    session_id: Optional[int] = None
    jump_cm: Optional[float] = None
    average_jump_cm: Optional[float] = None
    standing_reach_cm: Optional[float] = None
    attempts: Optional[list[float]] = None
class Run600mSave(BaseModel):
    session_id: Optional[int] = None
    time_sec: Optional[float] = None
    lane: Optional[int] = 1
    lap_count: Optional[int] = None
    rating: Optional[str] = None

# ── Page routes ───────────────────────────────────────────────────────────

@app.get("/", name="index")
def index(request: Request):
    return templates.TemplateResponse(request, "index.html", {"tests": list(TESTS.values())})


@app.get("/screen2", name="screen2")
def screen2(request: Request, category: Optional[str] = None):
    categories: dict[str, list] = {}
    for test in TESTS.values():
        categories.setdefault(test["category"], []).append(test)

    selected = category or "All Tests"
    visible_tests = list(TESTS.values()) if selected == "All Tests" else categories.get(selected, [])
    return templates.TemplateResponse(
        request,
        "screen2.html",
        {
            "categories": categories,
            "selected": selected,
            "tests": visible_tests,
        },
    )


# ── Laravel popup-sync config (injected into screen3.html) ───────────────────
# screen3.html posts a confirmed result back to the Laravel parent window that
# opened this app as a popup (nep.goforfit.in), then closes. Both values below
# are read by screen3.html — without them the template's {{ ...|tojson }} calls
# get Jinja Undefined and the page 500s for every test.
#   • Override the origin for staging/prod via the GOFORFIT_PARENT_ORIGIN env
#     var. "*" is safe for local testing: syncResultToLaravel() only fires when
#     window.opener exists, and direct navigation has none.
#   • LARAVEL_SYNC maps testId -> {exerciseType, scoreKey} Laravel expects. An
#     empty map is safe — screen3 falls back to {exerciseType: testId,
#     scoreKey: 'score'} per test. Add only entries confirmed against the
#     Laravel side.
GOFORFIT_PARENT_ORIGIN = os.environ.get("GOFORFIT_PARENT_ORIGIN", "*")
LARAVEL_SYNC: dict[str, dict] = {}


@app.get("/screen3", name="screen3")
def screen3(request: Request, test: Optional[str] = None):
    test_id = test or "wall_toss"
    test_cfg = TESTS.get(test_id, TESTS["wall_toss"])
    return templates.TemplateResponse(request, "screen3.html", {
        "test": test_cfg,
        "parent_origin": GOFORFIT_PARENT_ORIGIN,
        "sync_map": LARAVEL_SYNC,
    })


@app.get("/screen4", name="screen4")
def screen4(request: Request, test: Optional[str] = None):
    test_id = test or "wall_toss"
    test_cfg = TESTS.get(test_id, TESTS["wall_toss"])
    return templates.TemplateResponse(request, "screen4.html", {"test": test_cfg})


# ── Students — the roster screen3 picks from ───────────────────────────────
# A class belongs to the school, so the roster is not scoped per coach: two
# coaches testing the same class must see the same children.

class StudentCreate(BaseModel):
    name: str
    grade: str
    roll_no: Optional[str] = None
    reg_no: Optional[str] = None
    school: Optional[str] = None


@app.get("/api/classes")
def list_classes():
    return {"ok": True, "classes": db.list_classes()}


@app.get("/api/students")
def list_students(grade: Optional[str] = Query(default=None)):
    """?grade=Class%204-A for one class; omit it for the whole school."""
    return {"ok": True, "students": db.list_students(grade=grade)}


@app.post("/api/students")
def create_student(body: StudentCreate):
    name = (body.name or "").strip()
    grade = (body.grade or "").strip()
    if not name or not grade:
        return JSONResponse(
            {"ok": False, "error": "A student needs a name and a class."},
            status_code=400,
        )
    try:
        student_id = db.add_student(
            name=name, grade=grade,
            roll_no=(body.roll_no or "").strip() or None,
            reg_no=(body.reg_no or "").strip() or None,
            school=(body.school or "").strip() or None,
        )
    except sqlite3.IntegrityError:
        return JSONResponse(
            {"ok": False,
             "error": f"Roll number {body.roll_no!r} is already used in {grade}."},
            status_code=409,
        )
    return {"ok": True, "student": db.get_student(student_id)}


@app.delete("/api/students/{student_id}")
def delete_student(student_id: int):
    if not db.delete_student(student_id):
        return JSONResponse({"ok": False, "error": "No such student"}, status_code=404)
    return {"ok": True}


@app.get("/results", name="results")
def results_dashboard(request: Request):
    return templates.TemplateResponse(request, "results.html", {})


# ── Process management ───────────────────────────────────────────────────

# Small bounded pool just for connection tests — cv2.VideoCapture can block
# on an unreachable URL for a long time, and a plain call has no built-in
# timeout, so we run it in a worker thread and give up after a few seconds.
_camera_test_executor = concurrent.futures.ThreadPoolExecutor(max_workers=4)


def _probe_camera(url: str) -> dict:
    # A plain digit (e.g. "0", "1") means a local USB/built-in webcam index —
    # these must be opened WITHOUT forcing the FFMPEG backend, which is a
    # network-stream decoder and doesn't understand device indices. Forcing
    # it here caused the Test button to falsely report local cameras as
    # unreachable even when they work fine for the actual test scripts.
    #
    # Windows webcams are also inconsistent about which capture backend
    # actually works (Media Foundation vs DirectShow vs the OS default), so
    # for a local index we try a short list of backends in turn instead of
    # giving up after the first failure.
    if url.strip().isdigit():
        idx = int(url.strip())
        backend_attempts = [cv2.CAP_DSHOW, cv2.CAP_MSMF, cv2.CAP_ANY]
        cap = None
        for backend in backend_attempts:
            candidate = cv2.VideoCapture(idx, backend)
            if candidate.isOpened():
                cap = candidate
                break
            candidate.release()
        if cap is None:
            return {"ok": False, "error": (
                "Could not open this camera index with any backend. It may be in use by "
                "another app (Camera app, Zoom, Teams, a previous test run that crashed), "
                "blocked by Windows camera privacy settings, or simply not the right index — "
                "try 1 instead of 0, or vice versa."
            )}
    else:
        cap = cv2.VideoCapture(url, cv2.CAP_FFMPEG)
    try:
        if not cap.isOpened():
            return {"ok": False, "error": "Could not open stream — check the URL and that the phone/camera app is running."}
        ret, frame = cap.read()
        if not ret or frame is None:
            return {"ok": False, "error": "Stream opened but no frame was received."}
        h, w = frame.shape[:2]
        return {"ok": True, "width": w, "height": h}
    except Exception as exc:
        return {"ok": False, "error": str(exc)}
    finally:
        cap.release()


class CameraTestBody(BaseModel):
    url: str


@app.post("/api/test-camera")
def test_camera(b: CameraTestBody):
    url = (b.url or "").strip()
    if not url:
        return JSONResponse({"ok": False, "error": "No URL provided"}, status_code=400)

    future = _camera_test_executor.submit(_probe_camera, url)
    try:
        result = future.result(timeout=5.0)
    except concurrent.futures.TimeoutError:
        result = {"ok": False, "error": "Timed out after 5s — check the URL, and that the laptop and camera are on the same network."}
    return result


@app.post("/api/launch/{test_id}")
async def launch(test_id: str, request: Request):
    # Stop this test's previous run first. If screen4 was reloaded or closed
    # without STOP, its engine is still running, and replacing it below would
    # orphan it — nothing could reach it to stop it, so it would hold its pose
    # model in memory until the server restarts. Anything it stages on the
    # way out is a stale result, so drop it — even if the new launch fails.
    if _is_running(test_id):
        stop(test_id)
        _pending.pop(test_id, None)
    # A new start gets the full grace period before the idle stop can act.
    _last_seen[test_id] = time.monotonic()

    if test_id == "wingspan" and WingspanEngine is not None:
        return await _launch_wingspan(request)

    if test_id == "vertical_jump" and VerticalJumpEngine is not None:
        return await _launch_vertical_jump(request)

    if test_id == "bmi" and BmiEngine is not None:
        return await _launch_bmi(request)

    if test_id == "curl_up" and CurlUpEngine is not None:
        return await _launch_curl_up(request)

    if test_id == "pull_up" and PullUpEngine is not None:
        return await _launch_pull_up(request)

    if test_id == "full_pull_up" and FullPullUpEngine is not None:
        return await _launch_full_pull_up(request)

    if test_id == "wall_toss" and WallTossEngine is not None:
        return await _launch_wall_toss(request)

    if test_id == "sit_reach" and SitReachEngine is not None:
        return await _launch_sit_reach(request)

    if test_id == "trunk_lift" and TrunkLiftEngine is not None:
        return await _launch_trunk_lift(request)

    if test_id == "reverse_curl" and ReverseCurlEngine is not None:
        return await _launch_reverse_curl(request)

    if test_id == "shoulder_stretch" and ShoulderStretchEngine is not None:
        return await _launch_shoulder_stretch(request)

    if test_id == "isometric_push_up" and IsometricPushUpEngine is not None:
        return await _launch_isometric_push_up(request)

    if test_id == "seated_push_up" and SeatedPushUpEngine is not None:
        return await _launch_seated_push_up(request)

    if test_id == "target_stretch" and TargetStretchEngine is not None:
        return await _launch_target_stretch(request)

    if test_id == "dumbbell_press" and DumbbellPressEngine is not None:
        return await _launch_dumbbell_press(request)

    if test_id == "push_up" and PushUpEngine is not None:
        return await _launch_push_up(request)

    if test_id == "modified_curl_up" and ModifiedCurlUpEngine is not None:
        return await _launch_modified_curl_up(request)

    if test_id == "bench_press" and BenchPressEngine is not None:
        return await _launch_bench_press(request)

    if test_id == "modified_apley" and ModifiedApleyEngine is not None:
        return await _launch_modified_apley(request)
    if test_id == "wheelchair_ramp" and WheelchairRampEngine is not None:
        return await _launch_wheelchair_ramp(request)

    if test_id == "shuttle_run" and ShuttleRunEngine is not None:
        return await _launch_shuttle_run(request)

    if test_id == "dash_50m" and Dash50mEngine is not None:
        return await _launch_dash_50m(request)

    if test_id == "run_600m" and Run600mEngine is not None:
        return await _launch_run_600m(request)

    cfg = TESTS.get(test_id)
    if cfg is None:
        return JSONResponse({"ok": False, "error": f"Unknown test '{test_id}'"}, status_code=404)

    if cfg.get("manual_entry"):
        return JSONResponse(
            {"ok": False, "error": "This test has no camera. The coach enters the score."},
            status_code=400,
        )

    # This test is supposed to run as an in-browser live feed (like wingspan) —
    # if we get this far it's because its engine class is None, i.e. its engine
    # module failed to import. Previously this silently fell through to
    # spawning the *original* desktop-window script instead, which is exactly
    # the "camera opens in another window, and Laravel never gets synced"
    # bug reports we've gotten — so refuse instead of silently degrading.
    if cfg.get("live_feed"):
        is_dual = test_id in ("shuttle_run", "dash_50m", "run_600m")
        detail = DUAL_FEED_IMPORT_ERROR if is_dual else WEB_ENGINES_IMPORT_ERROR
        return JSONResponse(
            {
                "ok": False,
                "error": (
                    f"Live camera engine for '{test_id}' is unavailable "
                    f"(module failed to import: {detail or 'unknown error — check server console'}). "
                    "Refusing to fall back to a desktop OpenCV window — fix the "
                    "dependency shown above and restart the server."
                ),
            },
            status_code=503,
        )

    script = TESTS_DIR / cfg["script"]

    if not script.exists():
        return JSONResponse({"ok": False, "error": f"Script not found: {script.name}"}, status_code=500)

    cmd  = [sys.executable, str(script)]
    body = await _json_body(request)

    for param in cfg.get("params", []):
        value = body.get(param["name"])
        if value is None or str(value).strip() == "":
            return JSONResponse(
                {"ok": False, "error": f"Missing required parameter: {param['label']}"},
                status_code=400,
            )
        cmd += [param["arg"], str(value)]

    # Pass session_id to the test script so it can auto-save
    session_id = body.get("session_id")
    if session_id is not None:
        cmd += ["--session-id", str(session_id)]

    try:
        # These subprocesses open real desktop OpenCV windows the coach types
        # into — don't let them inherit the server's forced-offscreen env
        # (see top of file), or the window can't render/receive input and
        # ends up silently eating keyboard focus.
        child_env = os.environ.copy()
        child_env.pop("QT_QPA_PLATFORM", None)
        proc = subprocess.Popen(cmd, cwd=str(TESTS_DIR), stdin=subprocess.DEVNULL, env=child_env)
        _running[test_id] = proc
        _pending.pop(test_id, None)  # clear any stale unsaved result from a previous run
        return {"ok": True, "pid": proc.pid}
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)


async def _launch_wingspan(request: Request):
    """Starts the wingspan camera/processing loop in-process and streams it
    to the browser instead of opening a desktop OpenCV window."""
    global _wingspan_engine

    body = await _json_body(request)
    session_id = body.get("session_id")

    # Real distance from the camera, entered on screen3. Optional — blank means
    # "measuring at the calibration distance" (no correction). Entering the
    # venue's actual distance rescales the reading so one calibration stays
    # correct where the exact calibration distance won't fit.
    distance_cm = body.get("distance_cm")
    if distance_cm is not None and str(distance_cm).strip() != "":
        try:
            distance_cm = float(distance_cm)
        except (TypeError, ValueError):
            return JSONResponse({"ok": False, "error": "Distance from camera must be a number"}, status_code=400)
        if not (30 < distance_cm < 1000):
            return JSONResponse({"ok": False, "error": "Distance from camera must be between 30 and 1000 cm"}, status_code=400)
    else:
        distance_cm = None

    def _stage(cm: float):
        _pending["wingspan"] = {"session_id": session_id, "wingspan_cm": cm}

    try:
        engine = WingspanEngine(session_id=session_id, on_stage=_stage, distance_cm=distance_cm)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _wingspan_engine = engine
    _pending.pop("wingspan", None)  # clear any stale unsaved result from a previous run
    return {"ok": True, "pid": -1, "mode": "live_feed"}

async def _launch_bmi(request: Request):
    global _bmi_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # Real distance from the camera, entered on screen3. Optional — blank falls
    # back to the standard 215 cm. Entering the true distance decouples the
    # reading from a fixed standing spot: one calibration then works at any
    # distance (the calibration factor only has to absorb the per-camera lens
    # constant, which does not change with distance).
    distance_cm = body.get("distance_cm")
    if distance_cm is not None and str(distance_cm).strip() != "":
        try:
            distance_cm = float(distance_cm)
        except (TypeError, ValueError):
            return JSONResponse({"ok": False, "error": "Distance from camera must be a number"}, status_code=400)
        if not (50 < distance_cm < 1000):
            return JSONResponse({"ok": False, "error": "Distance from camera must be between 50 and 1000 cm"}, status_code=400)
    else:
        distance_cm = None  # engine uses its default (215)

    def _stage(height_cm, calibration_used):
        _pending["bmi"] = {
            "session_id": session_id, "height_cm": height_cm,
            "weight_kg": None, "calibration_used": calibration_used,
        }

    try:
        engine = BmiEngine(session_id=session_id, on_stage=_stage, distance_cm=distance_cm)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _bmi_engine = engine
    _pending.pop("bmi", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_curl_up(request: Request):
    global _curl_up_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    def _stage(reps):
        _pending["curl_up"] = {"session_id": session_id, "reps": reps, "duration_sec": 30}

    try:
        engine = CurlUpEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _curl_up_engine = engine
    _pending.pop("curl_up", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_pull_up(request: Request):
    global _pull_up_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    def _stage(reps, duration_sec):
        _pending["pull_up"] = {
            "session_id": session_id, "reps": reps, "duration_sec": duration_sec,
        }

    try:
        engine = PullUpEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _pull_up_engine = engine
    _pending.pop("pull_up", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_full_pull_up(request: Request):
    global _full_pull_up_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    def _stage(reps, duration_sec):
        _pending["full_pull_up"] = {
            "session_id": session_id, "reps": reps, "duration_sec": duration_sec,
        }

    try:
        engine = FullPullUpEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _full_pull_up_engine = engine
    _pending.pop("full_pull_up", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_wall_toss(request: Request):
    global _wall_toss_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    def _stage(catches, ball_colour):
        _pending["wall_toss"] = {
            "session_id": session_id, "catches": catches,
            "duration_sec": 30, "ball_colour": ball_colour,
        }

    try:
        engine = WallTossEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _wall_toss_engine = engine
    _pending.pop("wall_toss", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_sit_reach(request: Request):
    global _sit_reach_engine
    body = await _json_body(request)
    session_id = body.get("session_id")
    leg_cm = body.get("leg_cm")
    if leg_cm is None or str(leg_cm).strip() == "":
        return JSONResponse({"ok": False, "error": "Missing required parameter: Hip-to-ankle length (cm)"}, status_code=400)
    try:
        leg_cm = float(leg_cm)
    except ValueError:
        return JSONResponse({"ok": False, "error": "Hip-to-ankle length must be a number"}, status_code=400)

    def _stage(reach_cm, leg_cm_val, rating):
        _pending["sit_reach"] = {
            "session_id": session_id, "reach_cm": reach_cm,
            "leg_cm": leg_cm_val, "rating": rating,
        }

    try:
        engine = SitReachEngine(session_id=session_id, on_stage=_stage, leg_cm=leg_cm)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _sit_reach_engine = engine
    _pending.pop("sit_reach", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}

async def _launch_trunk_lift(request: Request):
    global _trunk_lift_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # Optional: the protocol's stick is 30 cm, and that default is what most
    # coaches will use. Any known length works as long as it is entered here.
    stick_cm = body.get("stick_cm")
    if stick_cm is None or str(stick_cm).strip() == "":
        stick_cm = 30.0
    else:
        try:
            stick_cm = float(stick_cm)
        except ValueError:
            return JSONResponse({"ok": False, "error": "Stick length must be a number"}, status_code=400)
        if not 5.0 <= stick_cm <= 300.0:
            return JSONResponse({"ok": False, "error": "Stick length must be between 5 and 300 cm"}, status_code=400)

    def _stage(lift_cm, trial1_cm, trial2_cm, stick_cm_val, rating):
        _pending["trunk_lift"] = {
            "session_id": session_id, "lift_cm": lift_cm,
            "trial1_cm": trial1_cm, "trial2_cm": trial2_cm,
            "stick_cm": stick_cm_val, "rating": rating,
        }

    try:
        engine = TrunkLiftEngine(session_id=session_id, on_stage=_stage, stick_cm=stick_cm)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _trunk_lift_engine = engine
    _pending.pop("trunk_lift", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_reverse_curl(request: Request):
    global _reverse_curl_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # The manual says "preferred arm", which the participant picks — so the
    # default is to work it out from who is actually curling. A coach can
    # pin it when the auto choice keeps landing on the wrong side.
    arm = (body.get("arm") or "auto")
    arm = str(arm).strip().lower() or "auto"
    if arm not in ("auto", "left", "right"):
        return JSONResponse({"ok": False, "error": "Arm must be auto, left or right"},
                            status_code=400)

    def _stage(passed, arm_val, peak_angle_deg, hold_s, rating):
        _pending["reverse_curl"] = {
            "session_id": session_id, "passed": passed, "arm": arm_val,
            "peak_angle_deg": peak_angle_deg, "hold_s": hold_s, "rating": rating,
        }

    try:
        engine = ReverseCurlEngine(session_id=session_id, on_stage=_stage, arm=arm)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _reverse_curl_engine = engine
    _pending.pop("reverse_curl", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_shoulder_stretch(request: Request):
    global _shoulder_stretch_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # Nothing to configure: BOTH sides are scored inside one trial and the
    # arm over the shoulder is named per frame from the hands, so there is no
    # side to choose or pin.
    def _stage(passed, left_passed, right_passed, best_gap_ratio,
               best_gap_left, best_gap_right, rating):
        _pending["shoulder_stretch"] = {
            "session_id": session_id, "passed": passed,
            "left_passed": left_passed, "right_passed": right_passed,
            "best_gap_ratio": best_gap_ratio,
            "best_gap_left": best_gap_left, "best_gap_right": best_gap_right,
            "rating": rating,
        }

    try:
        engine = ShoulderStretchEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _shoulder_stretch_engine = engine
    _pending.pop("shoulder_stretch", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_isometric_push_up(request: Request):
    global _isometric_push_up_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # Nothing to configure: the clock starts and stops itself from the pose.
    def _stage(hold_sec, held_exact_s, end_reason):
        _pending["isometric_push_up"] = {
            "session_id": session_id, "hold_sec": hold_sec,
            "held_exact_s": held_exact_s, "end_reason": end_reason,
        }

    try:
        engine = IsometricPushUpEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _isometric_push_up_engine = engine
    _pending.pop("isometric_push_up", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_seated_push_up(request: Request):
    global _seated_push_up_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # Nothing to configure: the seat, the start and the stop all come from
    # the pose.
    def _stage(hold_sec, held_exact_s, end_reason):
        _pending["seated_push_up"] = {
            "session_id": session_id, "hold_sec": hold_sec,
            "held_exact_s": held_exact_s, "end_reason": end_reason,
        }

    try:
        engine = SeatedPushUpEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _seated_push_up_engine = engine
    _pending.pop("seated_push_up", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_target_stretch(request: Request):
    global _target_stretch_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # The one thing to configure: which joint. Both sides are measured in
    # the one run, left then right.
    joint = str(body.get("joint") or "").strip().lower()
    if joint not in TARGET_STRETCH_JOINTS:
        return JSONResponse({"ok": False, "error": "Pick the joint to test first"},
                            status_code=400)

    def _stage(res):
        _pending["target_stretch"] = {
            "session_id": session_id, "joint": res["joint"],
            "joint_title": res["joint_title"],
            "left_deg": res["left_deg"], "left_score": res["left_score"],
            "left_exact": res["left_exact"],
            "right_deg": res["right_deg"], "right_score": res["right_score"],
            "right_exact": res["right_exact"],
            "rating": res["rating"],
        }

    try:
        engine = TargetStretchEngine(session_id=session_id, on_stage=_stage, joint=joint)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _target_stretch_engine = engine
    _pending.pop("target_stretch", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_dumbbell_press(request: Request):
    global _dumbbell_press_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # The coach may pin the student's arm (left / right); auto = the first arm
    # to press. It can also be changed later, before START, via the action.
    arm = str(body.get("arm") or "auto").strip().lower()
    if arm not in ("auto", "left", "right"):
        arm = "auto"

    def _stage(reps, arm, duration_sec, end_reason):
        _pending["dumbbell_press"] = {
            "session_id": session_id, "reps": reps, "arm": arm,
            "duration_sec": duration_sec, "end_reason": end_reason,
        }

    try:
        engine = DumbbellPressEngine(session_id=session_id, on_stage=_stage, arm=arm)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _dumbbell_press_engine = engine
    _pending.pop("dumbbell_press", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_push_up(request: Request):
    global _push_up_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # Nothing to configure: the coach taps START on "GO".
    def _stage(reps, duration_sec, end_reason):
        _pending["push_up"] = {
            "session_id": session_id, "reps": reps,
            "duration_sec": duration_sec, "end_reason": end_reason,
        }

    try:
        engine = PushUpEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _push_up_engine = engine
    _pending.pop("push_up", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_modified_curl_up(request: Request):
    global _modified_curl_up_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # Nothing to configure: the coach taps START on "GO".
    def _stage(reps, duration_sec, end_reason):
        _pending["modified_curl_up"] = {
            "session_id": session_id, "reps": reps,
            "duration_sec": duration_sec, "end_reason": end_reason,
        }

    try:
        engine = ModifiedCurlUpEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _modified_curl_up_engine = engine
    _pending.pop("modified_curl_up", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_modified_apley(request: Request):
    global _modified_apley_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    def _stage(res):
        _pending["modified_apley"] = {
            "session_id": session_id,
            "left_score": res["left_score"], "right_score": res["right_score"],
            "score": res["score"],
        }

    try:
        engine = ModifiedApleyEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _modified_apley_engine = engine
    _pending.pop("modified_apley", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_wheelchair_ramp(request: Request):
    global _wheelchair_ramp_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    def _stage(res):
        _pending["wheelchair_ramp"] = {
            "session_id": session_id,
            "score": res["score"], "reached_m": res["reached_m"],
            "max_score": res["max_score"], "end_reason": res["end_reason"],
        }

    try:
        engine = WheelchairRampEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _wheelchair_ramp_engine = engine
    _pending.pop("wheelchair_ramp", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_bench_press(request: Request):
    global _bench_press_engine
    body = await _json_body(request)
    session_id = body.get("session_id")

    # Boy (max 50) or girl (max 30) sets the finish. START waits for it; it
    # can also be picked later, before START, via the "sex" action.
    sex = str(body.get("sex") or "").strip().lower()
    if sex not in ("boy", "girl"):
        sex = None

    def _stage(reps, sex, duration_sec, end_reason):
        _pending["bench_press"] = {
            "session_id": session_id, "reps": reps, "sex": sex,
            "duration_sec": duration_sec, "end_reason": end_reason,
        }

    try:
        engine = BenchPressEngine(session_id=session_id, on_stage=_stage, sex=sex)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _bench_press_engine = engine
    _pending.pop("bench_press", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


# helper function for vertical jump.
async def _launch_vertical_jump(request: Request):
    """Runs the vertical jump camera loop in-process and streams it to the
    browser instead of opening a desktop OpenCV window."""
    global _vertical_jump_engine

    body = await _json_body(request)
    session_id = body.get("session_id")

    def _stage(jump_cm, average_jump_cm, standing_reach_cm, attempts):
        _pending["vertical_jump"] = {
            "session_id":        session_id,
            "jump_cm":           jump_cm,
            "average_jump_cm":   average_jump_cm,
            "standing_reach_cm": standing_reach_cm,
            "attempts":          attempts,
        }

    try:
        engine = VerticalJumpEngine(session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _vertical_jump_engine = engine
    _pending.pop("vertical_jump", None)  # clear stale unsaved result from a previous run
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_shuttle_run(request: Request):
    global _shuttle_engine
    if _shuttle_engine is not None and _shuttle_engine.is_running():
        _shuttle_engine.stop()

    body = await _json_body(request)
    session_id = body.get("session_id")
    cam_a = body.get("cam_a_url")
    cam_b = body.get("cam_b_url")
    touches = body.get("touches") or 4
    if not cam_a or not cam_b:
        return JSONResponse({"ok": False, "error": "cam_a_url and cam_b_url are required"}, status_code=400)

    def _stage(payload: dict):
        _pending["shuttle_run"] = payload

    try:
        engine = ShuttleRunEngine(cam_a, cam_b, touches=touches, session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _shuttle_engine = engine
    _pending.pop("shuttle_run", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_dash_50m(request: Request):
    global _dash50m_engine
    if _dash50m_engine is not None and _dash50m_engine.is_running():
        _dash50m_engine.stop()

    body = await _json_body(request)
    session_id = body.get("session_id")
    cam_a = body.get("finish_cam_url")
    cam_b = body.get("overhead_cam_url")
    lanes = body.get("lanes") or 4
    lane_width = body.get("lane_width") or 1.22
    if not cam_a or not cam_b:
        return JSONResponse({"ok": False, "error": "finish_cam_url and overhead_cam_url are required"}, status_code=400)

    def _stage(payload: dict):
        _pending["dash_50m"] = payload

    try:
        engine = Dash50mEngine(cam_a, cam_b, lanes=lanes, lane_width=lane_width,
                            session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _dash50m_engine = engine
    _pending.pop("dash_50m", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


async def _launch_run_600m(request: Request):
    global _run600m_engine
    if _run600m_engine is not None and _run600m_engine.is_running():
        _run600m_engine.stop()

    body = await _json_body(request)
    session_id = body.get("session_id")
    cam_a = body.get("camera_url") or "0"
    lane_colors = body.get("lane_colors") or []
    if isinstance(lane_colors, str):
        lane_colors = [c.strip() for c in lane_colors.split(",") if c.strip()]
    camera_distance_m = body.get("camera_distance_m") or 0.0
    if not lane_colors:
        return JSONResponse({"ok": False, "error": "lane_colors is required (comma-separated, e.g. Red,Blue,Green)"}, status_code=400)

    def _stage(payload: dict):
        _pending["run_600m"] = payload

    try:
        engine = Run600mEngine(cam_a, lane_colors=lane_colors, camera_distance_m=camera_distance_m,
                            session_id=session_id, on_stage=_stage)
        engine.start()
    except Exception as exc:
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=500)

    _run600m_engine = engine
    _pending.pop("run_600m", None)
    return {"ok": True, "pid": -1, "mode": "live_feed"}


@app.get("/api/engine-status")
def engine_status():
    """Quick browser-visible health check — hit http://localhost:5000/api/engine-status
    to see whether the live-feed (browser, no-desktop-window) engines loaded
    correctly, without having to dig through the server console."""
    return {
        "web_engines_ok": WEB_ENGINES_IMPORT_ERROR is None,
        "web_engines_error": WEB_ENGINES_IMPORT_ERROR,
        "web_engines_covers": ["wingspan", "bmi", "curl_up", "pull_up", "full_pull_up",
                               "wall_toss",
                               "sit_reach", "trunk_lift", "reverse_curl",
                               "shoulder_stretch", "isometric_push_up",
                               "seated_push_up", "target_stretch",
                               "dumbbell_press", "push_up", "modified_curl_up",
                               "bench_press", "modified_apley", "wheelchair_ramp",
                               "vertical_jump"],
        "dual_feed_engines_ok": DUAL_FEED_IMPORT_ERROR is None,
        "dual_feed_engines_error": DUAL_FEED_IMPORT_ERROR,
        "dual_feed_engines_covers": ["shuttle_run", "dash_50m", "run_600m"],
    }


@app.get("/api/status/{test_id}")
def status(test_id: str):
    if test_id not in TESTS:
        return JSONResponse({"ok": False, "error": "Unknown test"}, status_code=404)
    return {"ok": True, "running": _is_running(test_id)}


@app.get("/api/status")
def status_all():
    return {tid: _is_running(tid) for tid in TESTS}


@app.post("/api/stop/{test_id}")
def stop(test_id: str):
    if test_id == "wingspan" and _wingspan_engine is not None:
        # Auto-stage the best available reading before stopping,
        # so screen3 always has something to review even if SAVE READING was never tapped.
        if not _pending.get("wingspan"):
            state = _wingspan_engine.get_state()
            session_id = _wingspan_engine.session_id
            best_cm = None
            if state.get("snap_phase") == "DONE" and state.get("snap_final_cm"):
                best_cm = state["snap_final_cm"]
            elif state.get("result_cm") is not None:
                best_cm = state["result_cm"]
            if best_cm:
                _pending["wingspan"] = {"session_id": session_id, "wingspan_cm": best_cm}
        _wingspan_engine.stop()
        return {"ok": True}
    if test_id == "vertical_jump" and _vertical_jump_engine is not None:
        _vertical_jump_engine.stop()  # engine auto-stages best-available result internally
        return {"ok": True}
    if test_id == "bmi" and _bmi_engine is not None:
        _bmi_engine.stop()
        return {"ok": True}
    if test_id == "curl_up" and _curl_up_engine is not None:
        if not _pending.get("curl_up") and _curl_up_engine.count > 0:
            _pending["curl_up"] = {
                "session_id": _curl_up_engine.session_id,
                "reps": _curl_up_engine.count, "duration_sec": 30,
            }
        _curl_up_engine.stop()
        return {"ok": True}
    if test_id == "pull_up" and _pull_up_engine is not None:
        # The test is untimed, so STOP is how it always ends — the engine's
        # _stage_on_stop() is what stages the rep count for screen3.
        _pull_up_engine.stop()
        return {"ok": True}
    if test_id == "full_pull_up" and _full_pull_up_engine is not None:
        # Untimed, like the modified pull-up: _stage_on_stop() stages the count
        # if the coach stops before the participant drops off the bar.
        _full_pull_up_engine.stop()
        return {"ok": True}
    if test_id == "wall_toss" and _wall_toss_engine is not None:
        if not _pending.get("wall_toss") and _wall_toss_engine.counter.toss_count > 0:
            _pending["wall_toss"] = {
                "session_id": _wall_toss_engine.session_id,
                "catches": _wall_toss_engine.counter.toss_count, "duration_sec": 30,
                "ball_colour": _wall_toss_engine.counter._preset_name,
            }
        _wall_toss_engine.stop()
        return {"ok": True}
    if test_id == "sit_reach" and _sit_reach_engine is not None:
        _sit_reach_engine.stop()
        return {"ok": True}
    if test_id == "trunk_lift" and _trunk_lift_engine is not None:
        # The engine stages the best trial captured so far from its own
        # stop() hook, so a half-finished test still reaches screen3.
        _trunk_lift_engine.stop()
        return {"ok": True}
    if test_id == "reverse_curl" and _reverse_curl_engine is not None:
        # The engine stages from its own stop() hook, applying the manual's
        # one-trial rule: an attempt under way is a FAIL, a finished curl
        # already back on the thigh is a PASS. Neither -> "Not completed",
        # which screen3 shows but refuses to save, so the test is run again.
        _reverse_curl_engine.stop()
        return {"ok": True}
    if test_id == "shoulder_stretch" and _shoulder_stretch_engine is not None:
        # The engine stages from its own stop() hook, so an unresolved trial
        # still reaches screen3 as not-passed, carrying the closest gap the
        # fingers actually reached.
        _shoulder_stretch_engine.stop()
        return {"ok": True}
    if test_id == "isometric_push_up" and _isometric_push_up_engine is not None:
        # The engine stages from its own stop() hook: a hold under way ends
        # where the camera last saw the position. No hold started stages
        # nothing, so screen3 shows no reading rather than a zero.
        _isometric_push_up_engine.stop()
        return {"ok": True}
    if test_id == "seated_push_up" and _seated_push_up_engine is not None:
        # Same as the isometric push-up: the engine stages from its own
        # stop() hook, and nothing is staged if the clock never started.
        _seated_push_up_engine.stop()
        return {"ok": True}
    if test_id == "target_stretch" and _target_stretch_engine is not None:
        # The engine stages from its own stop() hook: the side under way
        # closes on its best hold, an unreached side stays unmeasured, and
        # nothing measured stages nothing.
        _target_stretch_engine.stop()
        return {"ok": True}
    if test_id == "dumbbell_press" and _dumbbell_press_engine is not None:
        # Like the pull-ups: the engine stages the count from its own stop()
        # hook if the coach stops before 50 reps or a 4 s rest ended it.
        _dumbbell_press_engine.stop()
        return {"ok": True}
    if test_id == "push_up" and _push_up_engine is not None:
        # Like the dumbbell press: the engine stages the count from its own
        # stop() hook if the coach stops before 6 s without a push-up ended it.
        _push_up_engine.stop()
        return {"ok": True}
    if test_id == "modified_curl_up" and _modified_curl_up_engine is not None:
        # Like the dumbbell press: the engine stages the count from its own
        # stop() hook if the coach stops before 75 or 6 s without a curl-up
        # ended it.
        _modified_curl_up_engine.stop()
        return {"ok": True}
    if test_id == "bench_press" and _bench_press_engine is not None:
        # Like the dumbbell press: the engine stages the count from its own
        # stop() hook if the coach stops before the max, a 4 s rest or the
        # 15 s no-rep end.
        _bench_press_engine.stop()
        return {"ok": True}
    if test_id == "modified_apley" and _modified_apley_engine is not None:
        # The engine stages from its own stop() hook: the arm under way
        # closes on its best hold, an arm not reached stays not tested, and
        # nothing measured stages nothing.
        _modified_apley_engine.stop()
        return {"ok": True}
    if test_id == "wheelchair_ramp" and _wheelchair_ramp_engine is not None:
        # The engine stages from its own stop() hook: the best line so far,
        # or nothing if the wheel was never seen behind the start line.
        _wheelchair_ramp_engine.stop()
        return {"ok": True}
    if test_id == "shuttle_run" and _shuttle_engine is not None:
        _shuttle_engine.maybe_finish()  # stage whatever's finished so far
        _shuttle_engine.stop()
        return {"ok": True}
    if test_id == "dash_50m" and _dash50m_engine is not None:
        _dash50m_engine.maybe_finish()
        _dash50m_engine.stop()
        return {"ok": True}
    if test_id == "run_600m" and _run600m_engine is not None:
        _run600m_engine.maybe_finish()
        _run600m_engine.stop()
        return {"ok": True}

    proc = _running.get(test_id)
    if proc and proc.poll() is None:
        proc.terminate()
        try:
            proc.wait(timeout=3)
        except subprocess.TimeoutExpired:
            proc.kill()
        del _running[test_id]
    return {"ok": True}


# ── Wingspan live-feed control (browser buttons replace keyboard) ─────────
#
#  GET  /api/wingspan/feed   — MJPEG stream of the live annotated camera feed
#  GET  /api/wingspan/state  — polled by screen4 to drive button/label state
#  POST /api/wingspan/action — {"action": "calibrate"|"measure"|"snapshot"|
#                                "save"|"cancel"|"enter_cm", "value": <float>}

class WingspanAction(BaseModel):
    action: str
    value: Optional[float] = None


@app.get("/api/wingspan/feed")
def wingspan_feed():
    if _wingspan_engine is None or not _wingspan_engine.is_running():
        return JSONResponse({"ok": False, "error": "Wingspan test isn't running"}, status_code=409)

    def gen():
        boundary = b"--frame"
        _FRAME_INTERVAL = 0.05   # 20 fps cap — browser can't usefully render faster
        _last_sent = None        # deduplicate: skip if engine hasn't produced a new frame
        _next_send = time.monotonic()
        while _wingspan_engine is not None and _wingspan_engine.is_running():
            now = time.monotonic()
            if now < _next_send:
                time.sleep(max(0, _next_send - now))
                continue
            jpg = _wingspan_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.005)
                continue
            _last_sent = jpg
            _next_send = now + _FRAME_INTERVAL
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"

    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/wingspan/state")
def wingspan_state():
    if _wingspan_engine is None:
        return {"ok": True, "running": False}
    state = _wingspan_engine.get_state()
    return {"ok": True, "running": _wingspan_engine.is_running(), **state}


@app.post("/api/wingspan/action")
def wingspan_action(b: WingspanAction):
    if _wingspan_engine is None or not _wingspan_engine.is_running():
        return JSONResponse({"ok": False, "error": "Wingspan test isn't running"}, status_code=409)

    act = b.action
    if act == "calibrate":
        return _wingspan_engine.action_calibrate()
    if act == "measure":
        return _wingspan_engine.action_measure()
    if act == "cancel":
        return _wingspan_engine.action_cancel()
    if act == "enter_cm":
        return _wingspan_engine.action_enter_cm(b.value)
    if act == "snapshot":
        return _wingspan_engine.action_snapshot()
    if act == "save":
        return _wingspan_engine.action_save()
    return JSONResponse({"ok": False, "error": f"Unknown action '{act}'"}, status_code=400)


@app.post("/api/wingspan/frame")
async def wingspan_frame(request: Request):
    """Receive one JPEG frame captured by the browser camera.

    The body is the raw JPEG bytes (Content-Type: image/jpeg). We hand it to
    the engine, which decodes + processes it and republishes the annotated
    result on /api/wingspan/feed. This is what replaced the server opening its
    own webcam via cv2.VideoCapture(0)."""
    if _wingspan_engine is None or not _wingspan_engine.is_running():
        return JSONResponse({"ok": False, "error": "Wingspan test isn't running"}, status_code=409)
    data = await request.body()
    facing = request.query_params.get("facing")
    ok = _wingspan_engine.push_frame(data, facing=facing)
    if not ok:
        return JSONResponse({"ok": False, "error": "Could not decode frame"}, status_code=400)
    return {"ok": True}


# ── Browser-camera frame intake for the other single-camera live tests ────
# Same model as /api/wingspan/frame: the browser captures the camera and
# POSTs JPEG frames here; the engine processes them and re-streams the
# annotated result on /api/<test>/feed. This is what replaced each engine
# opening the server's own webcam (cv2.VideoCapture(0)).
async def _receive_frame(engine, request: Request):
    if engine is None or not engine.is_running():
        return JSONResponse({"ok": False, "error": "Test isn't running"}, status_code=409)
    data = await request.body()
    # The browser appends ?facing=user|environment so the engine knows which
    # lens the frame came from. The back camera must NOT be selfie-mirrored;
    # every browser-camera engine exposes set_facing() to honour that (dual-cam
    # engines don't, so we skip them).
    facing = request.query_params.get("facing")
    if facing is not None and hasattr(engine, "set_facing"):
        engine.set_facing(facing)
    ok = engine.push_frame(data)
    if not ok:
        return JSONResponse({"ok": False, "error": "Could not decode frame"}, status_code=400)
    return {"ok": True}


@app.post("/api/bmi/frame")
async def bmi_frame(request: Request):
    return await _receive_frame(_bmi_engine, request)


@app.post("/api/curl_up/frame")
async def curl_up_frame(request: Request):
    return await _receive_frame(_curl_up_engine, request)


@app.post("/api/pull_up/frame")
async def pull_up_frame(request: Request):
    return await _receive_frame(_pull_up_engine, request)


@app.post("/api/full_pull_up/frame")
async def full_pull_up_frame(request: Request):
    return await _receive_frame(_full_pull_up_engine, request)


@app.post("/api/wall_toss/frame")
async def wall_toss_frame(request: Request):
    return await _receive_frame(_wall_toss_engine, request)


@app.post("/api/trunk_lift/frame")
async def trunk_lift_frame(request: Request):
    return await _receive_frame(_trunk_lift_engine, request)


@app.post("/api/reverse_curl/frame")
async def reverse_curl_frame(request: Request):
    return await _receive_frame(_reverse_curl_engine, request)


@app.post("/api/shoulder_stretch/frame")
async def shoulder_stretch_frame(request: Request):
    return await _receive_frame(_shoulder_stretch_engine, request)


@app.post("/api/isometric_push_up/frame")
async def isometric_push_up_frame(request: Request):
    return await _receive_frame(_isometric_push_up_engine, request)


@app.post("/api/seated_push_up/frame")
async def seated_push_up_frame(request: Request):
    return await _receive_frame(_seated_push_up_engine, request)


@app.post("/api/target_stretch/frame")
async def target_stretch_frame(request: Request):
    return await _receive_frame(_target_stretch_engine, request)


@app.post("/api/dumbbell_press/frame")
async def dumbbell_press_frame(request: Request):
    return await _receive_frame(_dumbbell_press_engine, request)


@app.post("/api/push_up/frame")
async def push_up_frame(request: Request):
    return await _receive_frame(_push_up_engine, request)


@app.post("/api/modified_curl_up/frame")
async def modified_curl_up_frame(request: Request):
    return await _receive_frame(_modified_curl_up_engine, request)


@app.post("/api/bench_press/frame")
async def bench_press_frame(request: Request):
    return await _receive_frame(_bench_press_engine, request)


@app.post("/api/modified_apley/frame")
async def modified_apley_frame(request: Request):
    return await _receive_frame(_modified_apley_engine, request)


@app.post("/api/wheelchair_ramp/frame")
async def wheelchair_ramp_frame(request: Request):
    return await _receive_frame(_wheelchair_ramp_engine, request)


@app.post("/api/sit_reach/frame")
async def sit_reach_frame(request: Request):
    return await _receive_frame(_sit_reach_engine, request)


@app.post("/api/vertical_jump/frame")
async def vertical_jump_frame(request: Request):
    return await _receive_frame(_vertical_jump_engine, request)


@app.post("/api/run_600m/frame")
async def run_600m_frame(request: Request):
    # 600m is single-camera, so it takes browser frames like the Group A
    # tests. shuttle_run/dash_50m stay on their two-IP-camera model.
    return await _receive_frame(_run600m_engine, request)



# ── Vertical jump live-feed control (browser buttons replace keyboard) ────
class VerticalJumpAction(BaseModel):
    action: str
    value: Optional[float] = None


@app.get("/api/vertical_jump/feed")
def vertical_jump_feed():
    if _vertical_jump_engine is None or not _vertical_jump_engine.is_running():
        return JSONResponse({"ok": False, "error": "Vertical jump test isn't running"}, status_code=409)

    def gen():
        boundary = b"--frame"
        _FRAME_INTERVAL = 0.05
        _last_sent = None
        _next_send = time.monotonic()
        while _vertical_jump_engine is not None and _vertical_jump_engine.is_running():
            now = time.monotonic()
            if now < _next_send:
                time.sleep(max(0, _next_send - now))
                continue
            jpg = _vertical_jump_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.005)
                continue
            _last_sent = jpg
            _next_send = now + _FRAME_INTERVAL
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"

    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/vertical_jump/state")
def vertical_jump_state():
    if _vertical_jump_engine is None:
        return {"ok": True, "running": False}
    state = _vertical_jump_engine.get_state()
    return {"ok": True, **state}


@app.post("/api/vertical_jump/action")
def vertical_jump_action(b: VerticalJumpAction):
    if _vertical_jump_engine is None or not _vertical_jump_engine.is_running():
        return JSONResponse({"ok": False, "error": "Vertical jump test isn't running"}, status_code=409)

    act = b.action
    if act == "capture_baseline":
        return _vertical_jump_engine.action_capture_baseline()
    if act == "calibrate":
        return _vertical_jump_engine.action_calibrate(b.value)
    if act == "start_attempt":
        return _vertical_jump_engine.action_start_attempt()
    if act == "cancel_attempt":
        return _vertical_jump_engine.action_cancel_attempt()
    if act == "reset":
        return _vertical_jump_engine.action_reset()
    if act == "save":
        return _vertical_jump_engine.action_save()
    return JSONResponse({"ok": False, "error": f"Unknown action '{act}'"}, status_code=400)


# ── Shared MJPEG generator for dual-feed engines (two cams -> two routes) ──
def _dual_feed_gen(get_engine, jpeg_attr: str):
    def gen():
        boundary = b"--frame"
        _FRAME_INTERVAL = 0.05
        _last_sent = None
        _next_send = time.monotonic()
        while True:
            engine = get_engine()
            if engine is None or not engine.is_running():
                break
            now = time.monotonic()
            if now < _next_send:
                time.sleep(max(0, _next_send - now))
                continue
            jpg = getattr(engine, jpeg_attr)()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.005)
                continue
            _last_sent = jpg
            _next_send = now + _FRAME_INTERVAL
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
    return gen


class DualFeedAction(BaseModel):
    action: str
    value: Optional[dict] = None


# ── Shuttle run live-feed control ──────────────────────────────────────
@app.get("/api/shuttle_run/feed_a")
def shuttle_run_feed_a():
    if _shuttle_engine is None or not _shuttle_engine.is_running():
        return JSONResponse({"ok": False, "error": "Shuttle run isn't running"}, status_code=409)
    return StreamingResponse(_dual_feed_gen(lambda: _shuttle_engine, "get_jpeg_a")(),
                              media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/shuttle_run/feed_b")
def shuttle_run_feed_b():
    if _shuttle_engine is None or not _shuttle_engine.is_running():
        return JSONResponse({"ok": False, "error": "Shuttle run isn't running"}, status_code=409)
    return StreamingResponse(_dual_feed_gen(lambda: _shuttle_engine, "get_jpeg_b")(),
                              media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/shuttle_run/state")
def shuttle_run_state():
    if _shuttle_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_shuttle_engine.get_state()}


@app.post("/api/shuttle_run/action")
def shuttle_run_action(b: DualFeedAction):
    if _shuttle_engine is None or not _shuttle_engine.is_running():
        return JSONResponse({"ok": False, "error": "Shuttle run isn't running"}, status_code=409)
    return _shuttle_engine.action(b.action, b.value)


# ── Dash 50m live-feed control ──────────────────────────────────────────
@app.get("/api/dash_50m/feed_a")
def dash_50m_feed_a():
    if _dash50m_engine is None or not _dash50m_engine.is_running():
        return JSONResponse({"ok": False, "error": "Dash 50m isn't running"}, status_code=409)
    return StreamingResponse(_dual_feed_gen(lambda: _dash50m_engine, "get_jpeg_a")(),
                              media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/dash_50m/feed_b")
def dash_50m_feed_b():
    if _dash50m_engine is None or not _dash50m_engine.is_running():
        return JSONResponse({"ok": False, "error": "Dash 50m isn't running"}, status_code=409)
    return StreamingResponse(_dual_feed_gen(lambda: _dash50m_engine, "get_jpeg_b")(),
                              media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/dash_50m/state")
def dash_50m_state():
    if _dash50m_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_dash50m_engine.get_state()}


@app.post("/api/dash_50m/action")
def dash_50m_action(b: DualFeedAction):
    if _dash50m_engine is None or not _dash50m_engine.is_running():
        return JSONResponse({"ok": False, "error": "Dash 50m isn't running"}, status_code=409)
    return _dash50m_engine.action(b.action, b.value)


# ── 600m run live-feed control (single camera; feed_b mirrors feed_a) ───
@app.get("/api/run_600m/feed_a")
def run_600m_feed_a():
    if _run600m_engine is None or not _run600m_engine.is_running():
        return JSONResponse({"ok": False, "error": "600m run isn't running"}, status_code=409)
    return StreamingResponse(_dual_feed_gen(lambda: _run600m_engine, "get_jpeg_a")(),
                              media_type="multipart/x-mixed-replace; boundary=frame")


@app.get("/api/run_600m/state")
def run_600m_state():
    if _run600m_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_run600m_engine.get_state()}


@app.post("/api/run_600m/action")
def run_600m_action(b: DualFeedAction):
    if _run600m_engine is None or not _run600m_engine.is_running():
        return JSONResponse({"ok": False, "error": "600m run isn't running"}, status_code=409)
    return _run600m_engine.action(b.action, b.value)


# ── BMI live-feed control ──────────────────────────────────────────────
class BmiAction(BaseModel):
    action: str
    value: Optional[float] = None

@app.get("/api/bmi/feed")
def bmi_feed():
    if _bmi_engine is None or not _bmi_engine.is_running():
        return JSONResponse({"ok": False, "error": "BMI test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _bmi_engine is not None and _bmi_engine.is_running():
            jpg = _bmi_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/bmi/state")
def bmi_state():
    if _bmi_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_bmi_engine.get_state()}

@app.post("/api/bmi/action")
def bmi_action(b: BmiAction):
    if _bmi_engine is None or not _bmi_engine.is_running():
        return JSONResponse({"ok": False, "error": "BMI test isn't running"}, status_code=409)
    if b.action == "scan":
        return _bmi_engine.action_scan()
    if b.action == "calibrate":
        return _bmi_engine.action_calibrate(b.value)
    if b.action == "reset":
        return _bmi_engine.action_reset()
    return JSONResponse({"ok": False, "error": f"Unknown action '{b.action}'"}, status_code=400)


# ── Curl-up live-feed control ──────────────────────────────────────────
class CurlUpAction(BaseModel):
    action: str

@app.get("/api/curl_up/feed")
def curl_up_feed():
    if _curl_up_engine is None or not _curl_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Curl-up test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _curl_up_engine is not None and _curl_up_engine.is_running():
            jpg = _curl_up_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/curl_up/state")
def curl_up_state():
    if _curl_up_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_curl_up_engine.get_state()}

@app.post("/api/curl_up/action")
def curl_up_action(b: CurlUpAction):
    if _curl_up_engine is None or not _curl_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Curl-up test isn't running"}, status_code=409)
    if b.action == "start":
        return _curl_up_engine.action_start()
    if b.action == "reset":
        # Also drop any staged result from a prior run so screen3 doesn't save a
        # stale count after the coach resets and re-attempts (see action_reset).
        _pending.pop("curl_up", None)
        return _curl_up_engine.action_reset()
    return JSONResponse({"ok": False, "error": f"Unknown action '{b.action}'"}, status_code=400)


# ── Modified pull-up live-feed control ─────────────────────────────────
class PullUpAction(BaseModel):
    action: str

@app.get("/api/pull_up/feed")
def pull_up_feed():
    if _pull_up_engine is None or not _pull_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Pull-up test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _pull_up_engine is not None and _pull_up_engine.is_running():
            jpg = _pull_up_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/pull_up/state")
def pull_up_state():
    if _pull_up_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_pull_up_engine.get_state()}

@app.post("/api/pull_up/action")
def pull_up_action(b: PullUpAction):
    if _pull_up_engine is None or not _pull_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Pull-up test isn't running"}, status_code=409)
    if b.action == "start":
        return _pull_up_engine.action_start()
    if b.action == "reset":
        # Also drop any staged result from a prior attempt so screen3 doesn't
        # save a stale count after the coach resets and re-attempts.
        _pending.pop("pull_up", None)
        return _pull_up_engine.action_reset()
    return JSONResponse({"ok": False, "error": f"Unknown action '{b.action}'"}, status_code=400)


# ── Pull-up live-feed control ──────────────────────────────────────────
class FullPullUpAction(BaseModel):
    action: str

@app.get("/api/full_pull_up/feed")
def full_pull_up_feed():
    if _full_pull_up_engine is None or not _full_pull_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Pull-up test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _full_pull_up_engine is not None and _full_pull_up_engine.is_running():
            jpg = _full_pull_up_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/full_pull_up/state")
def full_pull_up_state():
    if _full_pull_up_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_full_pull_up_engine.get_state()}

@app.post("/api/full_pull_up/action")
def full_pull_up_action(b: FullPullUpAction):
    if _full_pull_up_engine is None or not _full_pull_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Pull-up test isn't running"}, status_code=409)
    if b.action == "start":
        return _full_pull_up_engine.action_start()
    if b.action == "reset":
        _pending.pop("full_pull_up", None)
        return _full_pull_up_engine.action_reset()
    return JSONResponse({"ok": False, "error": f"Unknown action '{b.action}'"}, status_code=400)


# ── Wall-toss live-feed control ────────────────────────────────────────
class WallTossAction(BaseModel):
    action: str
    value: Optional[float] = None

@app.get("/api/wall_toss/feed")
def wall_toss_feed():
    if _wall_toss_engine is None or not _wall_toss_engine.is_running():
        return JSONResponse({"ok": False, "error": "Wall toss test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _wall_toss_engine is not None and _wall_toss_engine.is_running():
            jpg = _wall_toss_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/wall_toss/state")
def wall_toss_state():
    if _wall_toss_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_wall_toss_engine.get_state()}

@app.post("/api/wall_toss/action")
def wall_toss_action(b: WallTossAction):
    if _wall_toss_engine is None or not _wall_toss_engine.is_running():
        return JSONResponse({"ok": False, "error": "Wall toss test isn't running"}, status_code=409)
    if b.action == "start":
        return _wall_toss_engine.action_start()
    if b.action == "reset":
        return _wall_toss_engine.action_reset()
    if b.action == "set_preset":
        return _wall_toss_engine.action_set_preset(b.value)
    return JSONResponse({"ok": False, "error": f"Unknown action '{b.action}'"}, status_code=400)


# ── Trunk lift live-feed control ───────────────────────────────────────
class TrunkLiftAction(BaseModel):
    action: str
    # calib_click carries {x, y}; stick_cm carries a number. Both arrive in
    # the same `value` field screen4 already sends for every engine action.
    value: Optional[Any] = None

@app.get("/api/trunk_lift/feed")
def trunk_lift_feed():
    if _trunk_lift_engine is None or not _trunk_lift_engine.is_running():
        return JSONResponse({"ok": False, "error": "Trunk lift test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _trunk_lift_engine is not None and _trunk_lift_engine.is_running():
            jpg = _trunk_lift_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/trunk_lift/state")
def trunk_lift_state():
    if _trunk_lift_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_trunk_lift_engine.get_state()}

@app.post("/api/trunk_lift/action")
def trunk_lift_action(b: TrunkLiftAction):
    if _trunk_lift_engine is None or not _trunk_lift_engine.is_running():
        return JSONResponse({"ok": False, "error": "Trunk lift test isn't running"}, status_code=409)
    # The engine validates the action name itself and reports unknown ones.
    return _trunk_lift_engine.action(b.action, b.value)

# ── Reverse curl live-feed control ─────────────────────────────────────
class ReverseCurlAction(BaseModel):
    action: str
    # `arm` carries "auto"/"left"/"right"; pass/fail/reset carry nothing. Both
    # arrive in the same `value` field screen4 already sends for every engine.
    value: Optional[Any] = None

@app.get("/api/reverse_curl/feed")
def reverse_curl_feed():
    if _reverse_curl_engine is None or not _reverse_curl_engine.is_running():
        return JSONResponse({"ok": False, "error": "Reverse curl test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _reverse_curl_engine is not None and _reverse_curl_engine.is_running():
            jpg = _reverse_curl_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/reverse_curl/state")
def reverse_curl_state():
    if _reverse_curl_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_reverse_curl_engine.get_state()}

@app.post("/api/reverse_curl/action")
def reverse_curl_action(b: ReverseCurlAction):
    if _reverse_curl_engine is None or not _reverse_curl_engine.is_running():
        return JSONResponse({"ok": False, "error": "Reverse curl test isn't running"}, status_code=409)
    # The engine validates the action name itself and reports unknown ones.
    return _reverse_curl_engine.action(b.action, b.value)

# ── Isometric push-up live-feed control ────────────────────────────────
class IsometricPushUpAction(BaseModel):
    action: str
    value: Optional[Any] = None

@app.get("/api/isometric_push_up/feed")
def isometric_push_up_feed():
    if _isometric_push_up_engine is None or not _isometric_push_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Isometric push-up test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _isometric_push_up_engine is not None and _isometric_push_up_engine.is_running():
            jpg = _isometric_push_up_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/isometric_push_up/state")
def isometric_push_up_state():
    if _isometric_push_up_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_isometric_push_up_engine.get_state()}

@app.post("/api/isometric_push_up/action")
def isometric_push_up_action(b: IsometricPushUpAction):
    if _isometric_push_up_engine is None or not _isometric_push_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Isometric push-up test isn't running"}, status_code=409)
    res = _isometric_push_up_engine.action(b.action, b.value)
    if b.action == "reset" and res.get("ok"):
        # The trial being thrown away may already have staged its time.
        # Left in place, screen3 would show that voided score if the next
        # try never starts the clock.
        _pending.pop("isometric_push_up", None)
    return res

# ── Seated push-up live-feed control ───────────────────────────────────
class SeatedPushUpAction(BaseModel):
    action: str
    value: Optional[Any] = None

@app.get("/api/seated_push_up/feed")
def seated_push_up_feed():
    if _seated_push_up_engine is None or not _seated_push_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Seated push-up test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _seated_push_up_engine is not None and _seated_push_up_engine.is_running():
            jpg = _seated_push_up_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/seated_push_up/state")
def seated_push_up_state():
    if _seated_push_up_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_seated_push_up_engine.get_state()}

@app.post("/api/seated_push_up/action")
def seated_push_up_action(b: SeatedPushUpAction):
    if _seated_push_up_engine is None or not _seated_push_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Seated push-up test isn't running"}, status_code=409)
    res = _seated_push_up_engine.action(b.action, b.value)
    if b.action == "reset" and res.get("ok"):
        # The trial being thrown away may already have staged its time.
        # Left in place, screen3 would show that voided score if the next
        # try never starts the clock.
        _pending.pop("seated_push_up", None)
    return res

# ── Target stretch live-feed control ───────────────────────────────────
class TargetStretchAction(BaseModel):
    action: str
    value: Optional[Any] = None

@app.get("/api/target_stretch/feed")
def target_stretch_feed():
    if _target_stretch_engine is None or not _target_stretch_engine.is_running():
        return JSONResponse({"ok": False, "error": "Target stretch test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _target_stretch_engine is not None and _target_stretch_engine.is_running():
            jpg = _target_stretch_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/target_stretch/state")
def target_stretch_state():
    if _target_stretch_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_target_stretch_engine.get_state()}

@app.post("/api/target_stretch/action")
def target_stretch_action(b: TargetStretchAction):
    if _target_stretch_engine is None or not _target_stretch_engine.is_running():
        return JSONResponse({"ok": False, "error": "Target stretch test isn't running"}, status_code=409)
    res = _target_stretch_engine.action(b.action, b.value)
    if b.action == "reset" and res.get("ok"):
        # The run being thrown away may already have staged its scores.
        _pending.pop("target_stretch", None)
    return res

# ── Dumbbell press live-feed control ───────────────────────────────────
class DumbbellPressAction(BaseModel):
    action: str
    value: Optional[Any] = None

@app.get("/api/dumbbell_press/feed")
def dumbbell_press_feed():
    if _dumbbell_press_engine is None or not _dumbbell_press_engine.is_running():
        return JSONResponse({"ok": False, "error": "Dumbbell press test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _dumbbell_press_engine is not None and _dumbbell_press_engine.is_running():
            jpg = _dumbbell_press_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/dumbbell_press/state")
def dumbbell_press_state():
    if _dumbbell_press_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_dumbbell_press_engine.get_state()}

@app.post("/api/dumbbell_press/action")
def dumbbell_press_action(b: DumbbellPressAction):
    if _dumbbell_press_engine is None or not _dumbbell_press_engine.is_running():
        return JSONResponse({"ok": False, "error": "Dumbbell press test isn't running"}, status_code=409)
    res = _dumbbell_press_engine.action(b.action, b.value)
    if b.action == "reset" and res.get("ok"):
        # Drop a count staged by the attempt being thrown away.
        _pending.pop("dumbbell_press", None)
    return res

# ── Push-up live-feed control ──────────────────────────────────────────
class PushUpAction(BaseModel):
    action: str
    value: Optional[Any] = None

@app.get("/api/push_up/feed")
def push_up_feed():
    if _push_up_engine is None or not _push_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Push-up test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _push_up_engine is not None and _push_up_engine.is_running():
            jpg = _push_up_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/push_up/state")
def push_up_state():
    if _push_up_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_push_up_engine.get_state()}

@app.post("/api/push_up/action")
def push_up_action(b: PushUpAction):
    if _push_up_engine is None or not _push_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Push-up test isn't running"}, status_code=409)
    res = _push_up_engine.action(b.action, b.value)
    if b.action == "reset" and res.get("ok"):
        # Drop a count staged by the attempt being thrown away.
        _pending.pop("push_up", None)
    return res

# ── Modified curl-up live-feed control ─────────────────────────────────
class ModifiedCurlUpAction(BaseModel):
    action: str
    value: Optional[Any] = None

@app.get("/api/modified_curl_up/feed")
def modified_curl_up_feed():
    if _modified_curl_up_engine is None or not _modified_curl_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Modified curl-up test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _modified_curl_up_engine is not None and _modified_curl_up_engine.is_running():
            jpg = _modified_curl_up_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/modified_curl_up/state")
def modified_curl_up_state():
    if _modified_curl_up_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_modified_curl_up_engine.get_state()}

@app.post("/api/modified_curl_up/action")
def modified_curl_up_action(b: ModifiedCurlUpAction):
    if _modified_curl_up_engine is None or not _modified_curl_up_engine.is_running():
        return JSONResponse({"ok": False, "error": "Modified curl-up test isn't running"}, status_code=409)
    res = _modified_curl_up_engine.action(b.action, b.value)
    if b.action == "reset" and res.get("ok"):
        # Drop a count staged by the attempt being thrown away.
        _pending.pop("modified_curl_up", None)
    return res

# ── Bench press live-feed control ──────────────────────────────────────
class BenchPressAction(BaseModel):
    action: str
    # `sex` carries "boy"/"girl"; start/reset carry nothing.
    value: Optional[Any] = None

@app.get("/api/bench_press/feed")
def bench_press_feed():
    if _bench_press_engine is None or not _bench_press_engine.is_running():
        return JSONResponse({"ok": False, "error": "Bench press test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _bench_press_engine is not None and _bench_press_engine.is_running():
            jpg = _bench_press_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/bench_press/state")
def bench_press_state():
    if _bench_press_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_bench_press_engine.get_state()}

@app.post("/api/bench_press/action")
def bench_press_action(b: BenchPressAction):
    if _bench_press_engine is None or not _bench_press_engine.is_running():
        return JSONResponse({"ok": False, "error": "Bench press test isn't running"}, status_code=409)
    res = _bench_press_engine.action(b.action, b.value)
    if b.action == "reset" and res.get("ok"):
        # Drop a count staged by the attempt being thrown away.
        _pending.pop("bench_press", None)
    return res

# ── Modified Apley live-feed control ───────────────────────────────────
class ModifiedApleyAction(BaseModel):
    action: str
    value: Optional[Any] = None

@app.get("/api/modified_apley/feed")
def modified_apley_feed():
    if _modified_apley_engine is None or not _modified_apley_engine.is_running():
        return JSONResponse({"ok": False, "error": "Modified Apley test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _modified_apley_engine is not None and _modified_apley_engine.is_running():
            jpg = _modified_apley_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/modified_apley/state")
def modified_apley_state():
    if _modified_apley_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_modified_apley_engine.get_state()}

@app.post("/api/modified_apley/action")
def modified_apley_action(b: ModifiedApleyAction):
    if _modified_apley_engine is None or not _modified_apley_engine.is_running():
        return JSONResponse({"ok": False, "error": "Modified Apley test isn't running"}, status_code=409)
    res = _modified_apley_engine.action(b.action, b.value)
    if b.action == "reset" and res.get("ok"):
        # The run being thrown away may already have staged its scores.
        _pending.pop("modified_apley", None)
    return res

# ── Wheelchair ramp live-feed control ──────────────────────────────────
class WheelchairRampAction(BaseModel):
    action: str
    # calib_click carries {x, y} (a line tapped on the video).
    value: Optional[Any] = None

@app.get("/api/wheelchair_ramp/feed")
def wheelchair_ramp_feed():
    if _wheelchair_ramp_engine is None or not _wheelchair_ramp_engine.is_running():
        return JSONResponse({"ok": False, "error": "Wheelchair ramp test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _wheelchair_ramp_engine is not None and _wheelchair_ramp_engine.is_running():
            jpg = _wheelchair_ramp_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/wheelchair_ramp/state")
def wheelchair_ramp_state():
    if _wheelchair_ramp_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_wheelchair_ramp_engine.get_state()}

@app.post("/api/wheelchair_ramp/action")
def wheelchair_ramp_action(b: WheelchairRampAction):
    if _wheelchair_ramp_engine is None or not _wheelchair_ramp_engine.is_running():
        return JSONResponse({"ok": False, "error": "Wheelchair ramp test isn't running"}, status_code=409)
    res = _wheelchair_ramp_engine.action(b.action, b.value)
    if b.action in ("reset", "start") and res.get("ok"):
        # The run being thrown away may already have staged its score.
        _pending.pop("wheelchair_ramp", None)
    return res

# ── Shoulder stretch live-feed control ─────────────────────────────────
class ShoulderStretchAction(BaseModel):
    action: str
    # `side` carries "auto"/"left"/"right"; end/reset carry nothing. Both arrive
    # in the same `value` field screen4 already sends for every engine. There is
    # no PASS/FAIL action — this engine decides the verdict itself.
    value: Optional[Any] = None

@app.get("/api/shoulder_stretch/feed")
def shoulder_stretch_feed():
    if _shoulder_stretch_engine is None or not _shoulder_stretch_engine.is_running():
        return JSONResponse({"ok": False, "error": "Shoulder stretch test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _shoulder_stretch_engine is not None and _shoulder_stretch_engine.is_running():
            jpg = _shoulder_stretch_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/shoulder_stretch/state")
def shoulder_stretch_state():
    if _shoulder_stretch_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_shoulder_stretch_engine.get_state()}

@app.post("/api/shoulder_stretch/action")
def shoulder_stretch_action(b: ShoulderStretchAction):
    if _shoulder_stretch_engine is None or not _shoulder_stretch_engine.is_running():
        return JSONResponse({"ok": False, "error": "Shoulder stretch test isn't running"}, status_code=409)
    # The engine validates the action name itself and reports unknown ones.
    return _shoulder_stretch_engine.action(b.action, b.value)

# ── Sit & reach live-feed control ──────────────────────────────────────
class SitReachAction(BaseModel):
    action: str

@app.get("/api/sit_reach/feed")
def sit_reach_feed():
    if _sit_reach_engine is None or not _sit_reach_engine.is_running():
        return JSONResponse({"ok": False, "error": "Sit & reach test isn't running"}, status_code=409)
    def gen():
        boundary = b"--frame"
        _last_sent = None
        while _sit_reach_engine is not None and _sit_reach_engine.is_running():
            jpg = _sit_reach_engine.get_jpeg()
            if jpg is None or jpg is _last_sent:
                time.sleep(0.02)
                continue
            _last_sent = jpg
            yield boundary + b"\r\nContent-Type: image/jpeg\r\n\r\n" + jpg + b"\r\n"
            time.sleep(0.05)
    return StreamingResponse(gen(), media_type="multipart/x-mixed-replace; boundary=frame")

@app.get("/api/sit_reach/state")
def sit_reach_state():
    if _sit_reach_engine is None:
        return {"ok": True, "running": False}
    return {"ok": True, **_sit_reach_engine.get_state()}

@app.post("/api/sit_reach/action")
def sit_reach_action(b: SitReachAction):
    if _sit_reach_engine is None or not _sit_reach_engine.is_running():
        return JSONResponse({"ok": False, "error": "Sit & reach test isn't running"}, status_code=409)
    if b.action == "mark":
        return _sit_reach_engine.action_mark()
    if b.action == "reset":
        return _sit_reach_engine.action_reset()
    return JSONResponse({"ok": False, "error": f"Unknown action '{b.action}'"}, status_code=400)

# ── Database — session management ──────────────────────────────────────────

@app.post("/api/session")
def create_session(body: SessionCreate):
    """
    Create a student session before running tests.

    Body (JSON, all fields optional):
        student_name, age, gender ("M"/"F"/"Other"), school, grade, notes
    """
    sid = db.new_session(
        student_name = body.student_name,
        age          = body.age,
        gender       = body.gender,
        school       = body.school,
        grade        = body.grade,
        notes        = body.notes,
    )
    return {"ok": True, "session_id": sid}


@app.get("/api/session/{session_id}")
def get_session(session_id: int):
    row = db.get_session(session_id)
    if not row:
        return JSONResponse({"ok": False, "error": "Session not found"}, status_code=404)
    return {"ok": True, "session": row}


@app.get("/api/sessions")
def list_sessions():
    return {"ok": True, "sessions": db.list_sessions()}


# ── Pending results — AI scripts hand off here instead of auto-saving ───────
#
#  POST /api/stage/<test_id>   — AI script reports its raw result (not saved to DB yet)
#  GET  /api/pending/<test_id> — frontend polls/fetches the staged result for review
#  POST /api/pending/<test_id>/clear — frontend clears it after saving or discarding

@app.post("/api/stage/{test_id}")
async def stage_result(test_id: str, request: Request):
    if test_id not in TESTS:
        return JSONResponse({"ok": False, "error": f"Unknown test '{test_id}'"}, status_code=404)
    body = await _json_body(request)
    _pending[test_id] = body
    return {"ok": True}


@app.get("/api/pending/{test_id}")
def get_pending(test_id: str):
    if test_id not in TESTS:
        return JSONResponse({"ok": False, "error": f"Unknown test '{test_id}'"}, status_code=404)
    return {"ok": True, "pending": _pending.get(test_id)}


@app.post("/api/pending/{test_id}/clear")
def clear_pending(test_id: str):
    _pending.pop(test_id, None)
    return {"ok": True}


# ── Database — save results ────────────────────────────────────────────────
#
#  POST /api/save/<test_id>
#  Called by the test scripts or the frontend after a test completes.
#
#  All endpoints accept:
#    session_id  (required) — from POST /api/session
#    plus test-specific fields shown below.

@app.post("/api/save/bmi")
def save_bmi(b: BMISave):
    """Fields: session_id, height_cm, weight_kg (opt), calibration_used (opt bool)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_bmi(
        session_id       = b.session_id,
        height_cm        = b.height_cm,
        weight_kg        = b.weight_kg,
        calibration_used = bool(b.calibration_used),
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/wingspan")
def save_wingspan(b: WingspanSave):
    """Fields: session_id, wingspan_cm, height_cm (opt), calibration_distance_cm (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_wingspan(
        session_id              = b.session_id,
        wingspan_cm             = b.wingspan_cm,
        height_cm               = b.height_cm,
        calibration_distance_cm = b.calibration_distance_cm,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/curl_up")
def save_curl_up(b: CurlUpSave):
    """Fields: session_id, reps, duration_sec (opt, default 30), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_curl_up(
        session_id   = b.session_id,
        reps         = b.reps,
        duration_sec = b.duration_sec if b.duration_sec is not None else 30,
        rating       = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/pull_up")
def save_pull_up(b: PullUpSave):
    """Fields: session_id, reps, duration_sec (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_pull_up(
        session_id   = b.session_id,
        reps         = b.reps,
        duration_sec = b.duration_sec,
        rating       = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/full_pull_up")
def save_full_pull_up(b: FullPullUpSave):
    """Fields: session_id, reps, duration_sec (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_full_pull_up(
        session_id   = b.session_id,
        reps         = b.reps,
        duration_sec = b.duration_sec,
        rating       = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/wall_toss")
def save_wall_toss(b: WallTossSave):
    """Fields: session_id, catches, duration_sec (opt), ball_colour (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_wall_toss(
        session_id   = b.session_id,
        catches      = b.catches,
        duration_sec = b.duration_sec if b.duration_sec is not None else 30,
        ball_colour  = b.ball_colour,
        rating       = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/shuttle_run")
def save_shuttle_run(b: ShuttleRunSave):
    """Fields: session_id, time_sec, lane (opt, default 1), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_shuttle_run(
        session_id = b.session_id,
        time_sec   = b.time_sec,
        lane       = b.lane if b.lane is not None else 1,
        rating     = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/dash_50m")
def save_dash_50m(b: Dash50mSave):
    """Fields: session_id, time_sec, lane (opt), start_mode (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_dash_50m(
        session_id = b.session_id,
        time_sec   = b.time_sec,
        lane       = b.lane if b.lane is not None else 1,
        start_mode = b.start_mode or "whistle",
        rating     = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/sit_reach")
def save_sit_reach(b: SitReachSave):
    """Fields: session_id, reach_cm, leg_cm (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_sit_reach(
        session_id = b.session_id,
        reach_cm   = b.reach_cm,
        leg_cm     = b.leg_cm,
        rating     = b.rating,
    )
    return {"ok": True, "id": row_id}

@app.post("/api/save/trunk_lift")
def save_trunk_lift(b: TrunkLiftSave):
    """Fields: session_id, lift_cm, trial1_cm (opt), trial2_cm (opt), stick_cm (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_trunk_lift(
        session_id = b.session_id,
        lift_cm    = b.lift_cm,
        trial1_cm  = b.trial1_cm,
        trial2_cm  = b.trial2_cm,
        stick_cm   = b.stick_cm,
        rating     = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/reverse_curl")
def save_reverse_curl(b: ReverseCurlSave):
    """Fields: session_id, passed, arm (opt), peak_angle_deg (opt), hold_s (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.passed is None:
        return JSONResponse({"ok": False, "error": "passed required (pass/fail test)"}, status_code=400)
    row_id = db.save_reverse_curl(
        session_id     = b.session_id,
        passed         = b.passed,
        arm            = b.arm,
        peak_angle_deg = b.peak_angle_deg,
        hold_s         = b.hold_s,
        rating         = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/shoulder_stretch")
def save_shoulder_stretch(b: ShoulderStretchSave):
    """Fields: session_id, passed (both sides), left_passed/right_passed (opt),
    best_gap_ratio / best_gap_left / best_gap_right (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.passed is None:
        return JSONResponse({"ok": False, "error": "passed required (pass/fail test)"}, status_code=400)
    row_id = db.save_shoulder_stretch(
        session_id     = b.session_id,
        passed         = b.passed,
        left_passed    = b.left_passed,
        right_passed   = b.right_passed,
        best_gap_ratio = b.best_gap_ratio,
        best_gap_left  = b.best_gap_left,
        best_gap_right = b.best_gap_right,
        rating         = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/isometric_push_up")
def save_isometric_push_up(b: IsometricPushUpSave):
    """Fields: session_id, hold_sec (0-40, whole seconds), held_exact_s (opt),
    end_reason (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.hold_sec is None or not 0 <= b.hold_sec <= 40:
        return JSONResponse({"ok": False, "error": "Seconds held must be between 0 and 40"},
                            status_code=400)
    row_id = db.save_isometric_push_up(
        session_id   = b.session_id,
        hold_sec     = int(round(b.hold_sec)),
        held_exact_s = b.held_exact_s,
        end_reason   = b.end_reason,
        rating       = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/seated_push_up")
def save_seated_push_up(b: SeatedPushUpSave):
    """Fields: session_id, hold_sec (0-20, whole seconds), held_exact_s (opt),
    end_reason (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.hold_sec is None or not 0 <= b.hold_sec <= 20:
        return JSONResponse({"ok": False, "error": "Seconds held must be between 0 and 20"},
                            status_code=400)
    row_id = db.save_seated_push_up(
        session_id   = b.session_id,
        hold_sec     = int(round(b.hold_sec)),
        held_exact_s = b.held_exact_s,
        end_reason   = b.end_reason,
        rating       = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/target_stretch")
def save_target_stretch(b: TargetStretchSave):
    """Fields: session_id, joint, left_deg/left_score/left_exact,
    right_deg/right_score/right_exact (a side may be missing if it was not
    measured, but not both), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.joint not in TARGET_STRETCH_JOINTS:
        return JSONResponse({"ok": False, "error": "Unknown joint"}, status_code=400)
    if b.left_score is None and b.right_score is None:
        return JSONResponse({"ok": False, "error": "Neither side was measured"},
                            status_code=400)
    for sc in (b.left_score, b.right_score):
        if sc is not None and sc not in (0, 1, 2):
            return JSONResponse({"ok": False, "error": "Scores are 0, 1 or 2"},
                                status_code=400)
    row_id = db.save_target_stretch(
        session_id  = b.session_id,
        joint       = b.joint,
        left_deg    = None if b.left_deg is None else int(round(b.left_deg)),
        left_score  = b.left_score,
        left_exact  = b.left_exact,
        right_deg   = None if b.right_deg is None else int(round(b.right_deg)),
        right_score = b.right_score,
        right_exact = b.right_exact,
        rating      = b.rating or TARGET_STRETCH_JOINTS[b.joint],
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/dumbbell_press")
def save_dumbbell_press(b: DumbbellPressSave):
    """Fields: session_id, reps (0-50), arm (opt), duration_sec (opt),
    end_reason (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.reps is None or not (0 <= b.reps <= 50):
        return JSONResponse({"ok": False, "error": "Reps must be 0 to 50"}, status_code=400)
    row_id = db.save_dumbbell_press(
        session_id   = b.session_id,
        reps         = b.reps,
        arm          = b.arm,
        duration_sec = b.duration_sec,
        end_reason   = b.end_reason,
        rating       = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/push_up")
def save_push_up(b: PushUpSave):
    """Fields: session_id, reps (0 or more), duration_sec (opt),
    end_reason (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.reps is None or b.reps < 0:
        return JSONResponse({"ok": False, "error": "Push-ups must be 0 or more"}, status_code=400)
    row_id = db.save_push_up(
        session_id   = b.session_id,
        reps         = b.reps,
        duration_sec = b.duration_sec,
        end_reason   = b.end_reason,
        rating       = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/modified_curl_up")
def save_modified_curl_up(b: ModifiedCurlUpSave):
    """Fields: session_id, reps (0-75), duration_sec (opt),
    end_reason (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.reps is None or not (0 <= b.reps <= 75):
        return JSONResponse({"ok": False, "error": "Curl-ups must be 0 to 75"}, status_code=400)
    row_id = db.save_modified_curl_up(
        session_id   = b.session_id,
        reps         = b.reps,
        duration_sec = b.duration_sec,
        end_reason   = b.end_reason,
        rating       = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/bench_press")
def save_bench_press(b: BenchPressSave):
    """Fields: session_id, reps (0-50 boys / 0-30 girls), sex (opt),
    duration_sec (opt), end_reason (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    cap = 30 if b.sex == "girl" else 50
    if b.reps is None or not (0 <= b.reps <= cap):
        return JSONResponse({"ok": False, "error": f"Reps must be 0 to {cap}"}, status_code=400)
    row_id = db.save_bench_press(
        session_id   = b.session_id,
        reps         = b.reps,
        sex          = b.sex,
        duration_sec = b.duration_sec,
        end_reason   = b.end_reason,
        rating       = b.rating,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/modified_thomas")
def save_modified_thomas(b: ModifiedThomasSave):
    """Fields: session_id, left_score / right_score (0-3; one may be missing
    if that leg was not tested, but not both)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.left_score is None and b.right_score is None:
        return JSONResponse({"ok": False, "error": "Neither leg was scored"}, status_code=400)
    for sc in (b.left_score, b.right_score):
        if sc is not None and sc not in (0, 1, 2, 3):
            return JSONResponse({"ok": False, "error": "Scores are 0, 1, 2 or 3"},
                                status_code=400)
    row_id = db.save_modified_thomas(
        session_id  = b.session_id,
        left_score  = b.left_score,
        right_score = b.right_score,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/modified_apley")
def save_modified_apley(b: ModifiedApleySave):
    """Fields: session_id, left_score / right_score (0-3; one may be missing
    if that arm was not tested, but not both)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.left_score is None and b.right_score is None:
        return JSONResponse({"ok": False, "error": "Neither arm was scored"}, status_code=400)
    for sc in (b.left_score, b.right_score):
        if sc is not None and sc not in (0, 1, 2, 3):
            return JSONResponse({"ok": False, "error": "Scores are 0, 1, 2 or 3"},
                                status_code=400)
    row_id = db.save_modified_apley(
        session_id  = b.session_id,
        left_score  = b.left_score,
        right_score = b.right_score,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/wheelchair_ramp")
def save_wheelchair_ramp(b: WheelchairRampSave):
    """Fields: session_id, score (0-2), reached_m (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    if b.score not in (0, 1, 2):
        return JSONResponse({"ok": False, "error": "The score is 0, 1 or 2"}, status_code=400)
    row_id = db.save_wheelchair_ramp(
        session_id = b.session_id,
        score      = b.score,
        reached_m  = b.reached_m,
    )
    return {"ok": True, "id": row_id}


@app.post("/api/save/vertical_jump")
def save_vertical_jump(b: VerticalJumpSave):
    """Fields: session_id, jump_cm, average_jump_cm (opt), standing_reach_cm (opt), attempts (opt list)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_vertical_jump(
        session_id        = b.session_id,
        jump_cm           = b.jump_cm,
        average_jump_cm   = b.average_jump_cm,
        standing_reach_cm = b.standing_reach_cm,
        attempts          = b.attempts,
    )
    return {"ok": True, "id": row_id}

@app.post("/api/save/run_600m")
def save_run_600m(b: Run600mSave):
    """Fields: session_id, time_sec, lane (opt, default 1), lap_count (opt), rating (opt)"""
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    row_id = db.save_run_600m(
        session_id = b.session_id,
        time_sec   = b.time_sec,
        lane       = b.lane if b.lane is not None else 1,
        lap_count  = b.lap_count,
        rating     = b.rating,
    )
    return {"ok": True, "id": row_id}
# ── Database — fetch results ───────────────────────────────────────────────

@app.get("/api/results")
def results_all(student: Optional[str] = Query(default=None)):
    """Flat view across all tests. ?student=<name> to filter by student."""
    if student:
        rows = db.get_student_summary(student)
    else:
        rows = db.get_all_results()
    return {"ok": True, "results": rows}


@app.get("/api/results/{test_id}")
def results_by_test(test_id: str, session_id: Optional[int] = Query(default=None)):
    """All rows for one test table. ?session_id=<n> to filter."""
    if test_id not in db.VALID_TABLES:
        return JSONResponse({"ok": False, "error": f"Unknown test '{test_id}'"}, status_code=404)
    rows = db.get_all(test_id, session_id=session_id)
    return {"ok": True, "test": test_id, "results": rows}


@app.delete("/api/result/{test_id}/{row_id}")
def delete_result(test_id: str, row_id: int):
    """Delete a single test result row."""
    if test_id not in db.VALID_TABLES:
        return JSONResponse({"ok": False, "error": f"Unknown test '{test_id}'"}, status_code=404)
    deleted = db.delete_result(test_id, row_id)
    if not deleted:
        return JSONResponse({"ok": False, "error": "Record not found"}, status_code=404)
    return {"ok": True, "deleted": {"test": test_id, "row_id": row_id}}


@app.delete("/api/session/{session_id}")
def delete_session(session_id: int):
    """Delete a session and all its associated test results (CASCADE)."""
    deleted = db.delete_session(session_id)
    if not deleted:
        return JSONResponse({"ok": False, "error": "Session not found"}, status_code=404)
    return {"ok": True, "deleted": {"session_id": session_id}}


@app.get("/api/export/{test_id}")
def export_csv(test_id: str):
    """Export a test table to CSV and return the file."""
    if test_id not in db.VALID_TABLES:
        return JSONResponse({"ok": False, "error": f"Unknown test '{test_id}'"}, status_code=404)
    rows = db.get_all(test_id)
    if not rows:
        return JSONResponse({"ok": False, "error": "No data yet"}, status_code=404)

    output = io.StringIO()
    w = csv.DictWriter(output, fieldnames=rows[0].keys())
    w.writeheader()
    w.writerows(rows)
    output.seek(0)

    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv",
        headers={"Content-Disposition": f'attachment; filename="{test_id}_results.csv"'},
    )


# ── Modified Push-Up tracker (live site page) ─────────────────────────────
# A page that runs the pose model in the browser, counts modified push-ups and
# syncs the count to the website window that opened it. It came from the live
# server's copy of the app and is kept here so a deploy doesn't drop it. It is
# not one of TESTS, so it isn't listed on the test screens.
class ModifiedPushUpSave(BaseModel):
    session_id: Optional[int] = None
    reps: Optional[int] = None
    duration_sec: Optional[int] = None
    notes: Optional[str] = None
    rating: Optional[str] = None


MODIFIED_PUSHUP_PAGE = {
    "id":       "modified_pushup",
    "title":    "Modified Push-Up Counter",
    "subtitle": "Knee push-up muscular endurance test",
    "unit":     "reps",
}


@app.get("/modified_pushup_tracker", name="modified_pushup_tracker")
def serve_modified_pushup(request: Request):
    return templates.TemplateResponse(request, "modified_pushup.html", {
        "test": MODIFIED_PUSHUP_PAGE,
        "parent_origin": GOFORFIT_PARENT_ORIGIN,
    })


@app.post("/api/save/modified_pushup")
def save_modified_pushup(b: ModifiedPushUpSave):
    if not b.session_id:
        return JSONResponse({"ok": False, "error": "session_id required"}, status_code=400)
    try:
        row_id = db.save_modified_pushup(
            session_id=b.session_id, reps=b.reps, duration_sec=b.duration_sec,
            notes=b.notes, rating=b.rating,
        )
    except Exception as exc:
        # e.g. a session_id that doesn't exist here; the page ignores this
        # reply and syncs to the website either way.
        return JSONResponse({"ok": False, "error": str(exc)}, status_code=400)
    return {"ok": True, "id": row_id}


# ── Website links that name the test in the path ──────────────────────────
# The website opens a test as /fms/<test_id>?id=...&name=...&roll=..., but the
# camera page lives at /screen4?test=<test_id>. Send those links on to screen4,
# the page the website's other links open directly, with every query value
# kept, so the student the website picked comes along (screen3 would ask the
# coach to pick a student again from this server's own roster). The redirect
# is relative ("screen4?...") so it stays under /fms/ behind the proxy. Only
# known test ids match, and this is declared last so it never shadows another
# page.
@app.get("/{test_id}")
def test_link(test_id: str, request: Request):
    if test_id not in TESTS:
        return JSONResponse({"detail": "Not Found"}, status_code=404)
    params = [(k, v) for k, v in request.query_params.multi_items() if k != "test"]
    query = urlencode([("test", test_id)] + params)
    return RedirectResponse(f"screen4?{query}", status_code=307)


# ── Entry point ────────────────────────────────────────────────────────────

if __name__ == "__main__":
    import uvicorn

    print("\n  GoForFit NEP FMS — starting …")
    print(f"  Tests directory : {TESTS_DIR}")
    print(f"  Database        : {BASE_DIR / 'goforfit.db'}")
    print(f" Live Site URL   : https://talentid.goforfit.in/fms/")
    print(f" API Docs        : https://talentid.goforfit.in/fms/docs\n")
    
    # Match port to your Apache reverse proxy (8080)
    uvicorn.run("app:app", host="0.0.0.0", port=8080, reload=False)