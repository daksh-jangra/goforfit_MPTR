Modified Apley Test - changed files

Only used by this test:
  tests/modified_apley.py       rear-camera scoring logic
  tests/test_modified_apley.py  camera-free checks
                                 run: python3 tests/test_modified_apley.py
  tests/pose_landmarker_full.task
  tests/pose_landmarker_lite.task
  tests/hand_landmarker.task

Shared files (full CURRENT copies):
  tests/web_engines.py          ModifiedApleyEngine
  app.py                        test entry, routes, launch, save
  db.py                         modified_apley table and save
  templates/screen3.html        results and test launch page
  templates/screen4.html        live screen and RESET controls
  templates/results.html        results listing

Patch
  modified_apley.patch          add/relevant commit diff for the test

Protocol
  Camera goes BEHIND the student. The left arm is tested first, then the
  right arm. Scores are 3 for opposite shoulder blade, 2 for top of head,
  1 for mouth, and 0 for no held touch. Every score needs a 1-second hold.
