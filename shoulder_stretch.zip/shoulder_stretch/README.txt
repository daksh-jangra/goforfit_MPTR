Shoulder Stretch - changed files (from main, commits a893f0d..520b4b4)

Only used by this test:
  tests/shoulder_stretch.py        main logic
  tests/test_shoulder_stretch.py   camera-free checks
                                   run: python3 tests/test_shoulder_stretch.py

Shared files (full CURRENT copies - they also contain every other test,
including work other people did after this test was finished, so do not
drop them over an older copy without checking):
  tests/web_engines.py             ShoulderStretchEngine
  app.py                           test entry, routes, launch, save
  db.py                            shoulder_stretch table + save (per-side columns)
  templates/screen4.html           live screen, RESET, website sync
  templates/screen3.html           result shown read-only (the camera decides)

shoulder_stretch.patch
  The 7 Shoulder Stretch commits, with only this test's lines in them.
  It is a RECORD of the changes, not a clean replay: other tests changed
  the same shared files in between, so "git am" and "git am -3" both stop
  part way. Use it to read or cherry-pick the lines; to move the test,
  copy the files above.

The test: touch the fingertips behind the back, BOTH sides, inside one
15 second trial that starts at the first real attempt. Camera goes BEHIND
the student, and only the student in frame at the start.

Commits (oldest first)
  a893f0d  add the test (pass/fail, fingertips behind the back)
  36b9fee  desktop script posts results to the app's real port
  cc05aa6  both sides inside one 15 s trial
  8a61190  close a trial the camera never scored
  3ced4e6  put back the _ascii helper the HUD uses
  912092f  each side shows its own PASS or FAIL on the overlay
  520b4b4  warn when the student is too small in the picture
